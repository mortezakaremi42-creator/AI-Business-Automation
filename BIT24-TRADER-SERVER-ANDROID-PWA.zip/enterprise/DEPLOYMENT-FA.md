# Bit24 Trader Control — بستهٔ یکپارچهٔ پنج فاز

## دقیقاً چه چیزی آماده است؟
موتور Node.js/TypeScript، state machine، PostgreSQL، Redis Token Bucket، reconciliation، ریسک، BullMQ/Telegraf و پنل فارسی موبایل در `src/runtime.ts` به هم وصل شده‌اند. `npm start` اکنون فایل کامپایل‌شدهٔ همین runtime را اجرا می‌کند؛ فایل main.ts قبلی دیگر entrypoint پیش‌فرض نیست.

**این انتشار فقط Dry-Run است.** حتی با تغییر env به LIVE روشن نمی‌شود. runtime عمداً هیچ credential یا قرارداد تأییدنشدهٔ Bit24 به آداپتور نمی‌دهد. موجودی واقعی، قیمت زنده و سود ساخته نمی‌شود. فید خودکار تحلیل بازار هنوز متصل نشده؛ فرم پنل فقط سیگنال فرضی برای آزمون مسیر ارسال می‌کند. موتور روی VPS اجرا می‌شود و گوشی فقط پنل کنترل است.

این پنل سبک HTML/CSS/JS، RTL و PWA است؛ مهاجرت به Next.js هنوز انجام نشده است. APK بومی ساخته نشده؛ نصب فعلی روی اندروید از طریق مرورگر و HTTPS است. دسترسی‌های سرور، دامنه یا توکن‌های واقعی اینجا تنظیم نشده‌اند؛ هیچ VPS یا حساب خارجی از طرف شما provision نشده است.

## فایل‌های استقرار
- `Dockerfile`: سه مرحله، dependency تولیدی جدا، خروجی کامپایل‌شده، اجرای non-root.
- `docker-compose.yml`: دقیقاً app/PostgreSQL/Redis با restart: always، volume پایدار، healthcheck و چرخش لاگ.
- `compose.yml`: همان محتوا برای سازگاری با دستورهای قبلی؛ تغییر هر دو باید یکسان باشد.
- `deploy/ecosystem.config.js`: جایگزین Docker app برای PM2 روی میزبان، فقط یک instance و fork.
- `deploy/nginx.conf`: reverse proxy و WebSocket؛ TLS را Certbot اضافه می‌کند.
- `scripts/setup-env.mjs`: ایجاد کلیدهای تصادفی و رمز پنل به صورت hash، فایل با mode=0600، بدون overwrite.
- `src/migrate.ts`: migration ترتیبی با lock/checksum/ledger، جدا از شروع موتور.

## پیش‌نیاز VPS
پیشنهاد اولیه: Ubuntu به‌روز، ۲ هسته و ۴ گیگابایت RAM، دیسک پایدار و دامنهٔ متعلق به خودتان با DNS به IP سرور. این ظرفیت تضمین کارایی نیست؛ مصرف واقعی را پایش کنید. Docker Engine و Compose plugin جدید را طبق مستندات رسمی نصب کنید:
https://docs.docker.com/engine/install/ubuntu/
https://docs.docker.com/compose/install/linux/

از یک کاربر مدیریتی امن، کلید SSH، به‌روزرسانی امنیتی و فایروال استفاده کنید. فقط SSH و 80/443 لازم‌اند؛ PostgreSQL، Redis و پورت 3100 نباید عمومی باشند. Docker می‌تواند قواعد UFW را دور بزند؛ پورت‌های Compose عمداً فقط روی 127.0.0.1 منتشر شده‌اند و DB/Redis اصلاً publish نشده‌اند.

## روش پیشنهادی: Docker
فایل ZIP را روی VPS استخراج کنید و وارد پوشهٔ enterprise شوید. همهٔ دستورهای زیر از همین پوشه اجرا می‌شوند.

### ۱. تنظیم امن
برای تنظیم بدون نصب Node روی میزبان:
```sh
docker run --rm -it -u "$(id -u):$(id -g)" \
  -v "$PWD:/work" -w /work node:22-bookworm-slim node scripts/setup-env.mjs
```
اسکریپت فقط HTTPS origin را می‌پرسد، مثلاً دامنهٔ واقعی پنل شما. رمز ورود یک‌بار در ترمینال خودتان چاپ می‌شود؛ در password manager نگه دارید. رمز یا `.env` را در چت نفرستید. اگر `.env` موجود باشد اسکریپت آن را تغییر نمی‌دهد.

فایل `.env` را فقط روی سرور ویرایش کنید:
```sh
chmod 600 .env
nano .env
```
برای تلگرام، هر دو TELEGRAM_BOT_TOKEN و TELEGRAM_CHAT_ID را تنظیم کنید؛ اگر هر دو خالی باشند پنل و موتور Dry-Run کار می‌کنند و تلگرام صریحاً «تنظیم نشده» است. ابتدا در تلگرام به بات خودتان /start بزنید و chat مجاز را مشخص کنید. هیچ bot command برای معامله یا برداشت ایجاد نشده است.

Compose، DATABASE_URL و REDIS_URL برنامه را به DNS داخلی postgres/redis تغییر می‌دهد؛ مقدار localhost داخل `.env` مخصوص PM2/میزبان است. رمزهای تولیدشده hexadecimal هستند تا در URI به encoding نیاز نداشته باشند. اگر رمز را دستی با کاراکتر خاص عوض کردید، URI را متناسب اصلاح کنید.

### ۲. Build و migration کنترل‌شده
```sh
docker compose -f docker-compose.yml build app
docker compose -f docker-compose.yml up -d postgres redis
docker compose -f docker-compose.yml run --rm app node dist/migrate.js
docker compose -f docker-compose.yml up -d app
docker compose -f docker-compose.yml ps
docker compose -f docker-compose.yml logs --tail=100 app
curl -i http://127.0.0.1:3100/health/monitor
```
موتور migration را خودکار در هر restart اجرا نمی‌کند. runner اسکیماهای فاز۱،۳،۴،۵ را با جدول bit24_migrations ثبت می‌کند و تغییر checksum فایل اعمال‌شده را رد می‌کند. داده‌های اولیهٔ ساختگی تزریق نمی‌شود.

**اگر SQL فازهای قبل را دستی روی دیتابیس موجود اجرا کرده‌اید:** runner نمی‌تواند خودکار آن را به ledger جدید نسبت دهد؛ ممکن است روی CREATE SCHEMA متوقف شود. backup بگیرید و adoption اسکیما/نسخه را بررسی کنید. جدول‌ها را drop نکنید و migration را بدون بررسی applied علامت نزنید. دستورهای این بخش برای دیتابیس تازهٔ این بسته طراحی شده‌اند.

### ۳. دامنه و HTTPS
```sh
sudo apt update
sudo apt install nginx certbot python3-certbot-nginx
```
فایل deploy/nginx.conf را در `/etc/nginx/sites-available/bit24` قرار دهید و `bot.your-domain.tld` را با دامنهٔ خودتان جایگزین کنید. map باید در context http باشد (sites-enabled معمولاً از داخل http include می‌شود).
```sh
sudo ln -s /etc/nginx/sites-available/bit24 /etc/nginx/sites-enabled/bit24
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d bot.your-domain.tld
```
آخرین فرمان را با دامنهٔ واقعی اجرا کنید. PUBLIC_ORIGIN در `.env` باید دقیقاً همان origin HTTPS و بدون مسیر باشد؛ سپس `docker compose -f docker-compose.yml up -d app` را اجرا کنید. کوکی session در production Secure/HttpOnly/SameSite=Strict است. قبل از TLS، ورود از HTTP روی مرورگر کار نخواهد کرد. WebSocket پنل `/events` فقط از origin مجاز و session معتبر پذیرفته می‌شود؛ این WebSocket، فید قیمت Bit24 نیست.

### ۴. نصب روی اندروید
1. آدرس HTTPS دامنهٔ خودتان را در Chrome اندروید باز کنید.
2. با رمز تولیدشده وارد شوید.
3. روی «نصب روی اندروید» بزنید؛ اگر دکمه نمایش داده نشد از منوی مرورگر Install app / افزودن به صفحهٔ اصلی استفاده کنید.
4. گوشی را قفل کنید؛ در لاگ سرور بررسی کنید موتور همچنان اجرا می‌شود. بستن مرورگر نباید پروسهٔ سرور را ببندد.

Service worker فقط پوستهٔ عمومی را cache می‌کند؛ API، JWT، رمز، موجودی و سفارش cache نمی‌شوند. در آفلاین بودن گوشی، پنل نمی‌تواند وضعیت فعلی سرور را تأیید کند. APK جداگانه ارائه نشده است.

## روش جایگزین: PM2 روی میزبان
**PM2 و کانتینر app را همزمان اجرا نکنید.** داخل Docker، Node مستقیم PID برنامه است و Docker مسئول restart است. PM2، راه جایگزین برای اجرای مستقیم روی Ubuntu است، نه لایهٔ دوم داخل همان کانتینر.

Node.js سازگار نسخهٔ 22 یا بالاتر و PM2 را روی میزبان نصب کنید؛ سپس:
```sh
npm ci
npm run typecheck
npm run build
# کانتینر app را خاموش کنید؛ DB/Redis را فقط برای میزبان روی loopback publish کنید.
docker compose -f docker-compose.yml stop app
docker compose -f docker-compose.yml -f deploy/pm2-services.yml up -d postgres redis
# .env باید DATABASE_URL/REDIS_URL با 127.0.0.1 و رمزهای منطبق داشته باشد.
npm run migrate
pm2 start deploy/ecosystem.config.js --env production
pm2 save
pm2 startup
```
فرمان systemd که PM2 چاپ می‌کند را طبق راهنمای خودش اجرا کنید؛ مسیر Node و کاربر درست را کنترل کنید. فایل .js در deploy/package.json با type=commonjs تعریف شده تا با package اصلی ESM ناسازگار نشود. تنظیمات: یک instance، restart حدود یک ثانیه پس از crash، سقف ۲۰ crash سریع، kill timeout شصت ثانیه و restart بالاتر از 700MB RSS. این سقف جلوی crash loop بی‌پایان ناشی از تنظیم غلط را می‌گیرد. PM2 logrotate یا سیاست log retention میزبان را جدا تنظیم کنید.

## UptimeRobot — نگهبان خارج VPS
این راهنما تنظیم دستی است؛ مانیتوری در حساب شما ایجاد نشده است.

1. در حساب UptimeRobot یک HTTP(S) monitor جدید بسازید.
2. URL را روی `https://دامنه-واقعی-شما/health/monitor` قرار دهید.
3. روش GET و وضعیت موفق 200 را انتخاب کنید. اگر امکان keyword وجود داشت، عبارت `"ok":true` را هم بررسی کنید.
4. فاصله بررسی و زمان تأیید خطا را مطابق امکانات حساب خود انتخاب کنید؛ زمان‌بندی/کانال‌های قابل استفاده به پلن فعلی بستگی دارد.
5. یک alert contact بیرون همین VPS، مثلاً ایمیل و در صورت پشتیبانی حساب کانال تلگرام، فعال و تأیید کنید. Down و Recovery notification را هر دو فعال کنید.
6. به بررسی UptimeRobot دسترسی واقعی HTTPS بدهید؛ auth پنل روی health اعمال نشده ولی پاسخ شامل رمز/موجودی نیست. در صورت وجود WAF یا فایروال، مانیتور نباید بی‌دلیل مسدود شود.
7. تست کنترل‌شده در Dry-Run: `docker compose -f docker-compose.yml stop app`؛ منتظر هشدار Down شوید. سپس `docker compose -f docker-compose.yml up -d app` و Recovery notification را بررسی کنید. در PM2 از stop/start همان برنامه استفاده کنید، نه کانتینر app.

تفاوت endpointها:
- `/health/live`: فقط زنده‌بودن HTTP؛ کافی برای سلامت کل ربات نیست.
- `/health/monitor`: سلامت Postgres/Redis، پیشرفت موتور و در صورت فعال‌بودن تلگرام، running بودن Worker و نبود failed job پس از retryها. اگر موتور در بازیابی نامعلوم متوقف شده باشد 503 می‌دهد.
- `/health/trading`: عمداً 503 چون معاملات واقعی تأیید نشده‌اند؛ آن را به‌عنوان مانیتور uptime نسخهٔ Dry-Run انتخاب نکنید.

اگر کل VPS یا اینترنت آن قطع شود، خود بات نمی‌تواند پیام مرگ خود را بفرستد؛ هشدار UptimeRobot بیرون سرور این فاصله را پوشش می‌دهد. مانیتور فقط هشدار می‌دهد و در این تنظیم سرور را خودکار تعمیر/روشن نمی‌کند. زمان رسیدن پیام به برنامه بررسی و شبکه وابسته است، نه «فوری تضمینی».

## restart، watchdog و نگهداری
`restart: always` پس از خروج پردازش عمل می‌کند؛ Docker وضعیت unhealthy را به‌تنهایی restart نمی‌کند. runtime یک watchdog پیشرفت دارد: اگر حلقه بیش از ۱۲۰ ثانیه بدون پیشرفت بماند، در چک بعدی (حداکثر حدود ۳۰ ثانیه بعد) با exit=1 خارج می‌شود تا supervisor راه‌اندازی مجدد کند. وضعیت PAUSED که در backoff پیشرفت می‌کند، عمداً بی‌وقفه restart نمی‌شود؛ UptimeRobot روی 503 هشدار می‌دهد. stop دستی کانتینر هم الزاماً بلافاصله با restart خنثی نمی‌شود.

Redis AOF هرثانیه و noeviction دارد؛ در قطع سخت ممکن است آخرین حدود یک ثانیه دادهٔ Redis از دست برود. هشدار commitشده در PostgreSQL outbox مجدداً enqueue می‌شود. این ضمانت جای backup PostgreSQL را نمی‌گیرد. volumeها با `down` معمولی حفظ می‌شوند؛ **`down -v` داده‌ها را حذف می‌کند و نباید روی سرور عملیاتی استفاده شود.**

نمونه backup دیتابیس (فایل را خارج VPS هم نگه دارید):
```sh
mkdir -p backups && chmod 700 backups
docker compose -f docker-compose.yml exec -T postgres pg_dump -U trader -d trader -Fc > backups/trader.dump
chmod 600 backups/trader.dump
```
فایل backup می‌تواند اطلاعات حساس عملیاتی داشته باشد؛ رمزگذاری، انتقال خارج سرور و تست restore روی دیتابیس جدا لازم است. برنامهٔ retention، مانیتور دیسک و چرخش رمزها را مشخص کنید. role فعلی trader مالک migration و داده است؛ پیش از live باید کاربر runtime کم‌مجوز را از migration owner جدا کنید. imageها فعلاً tag دارند؛ برای محیط حساس digest تأییدشده pin و اسکن image لازم است.

در rollback فقط image قبلی با schema سازگار را برگردانید؛ migrationهای destructive را کورکورانه عقب نبرید. قبل از تغییر PUBLIC_ORIGIN/رمزها، پنل و اثر sessionهای فعلی را بررسی کنید. تغییر JWT_SECRET همهٔ sessionهای قبلی را نامعتبر می‌کند.

## تست و محدودیت نهایی
فرمان‌ها: `npm run typecheck`، `npm run build`، `npm test` و `npm audit --omit=dev`.

در این مرحله ۱۰۶ تست موفق‌اند؛ شامل SQL و trigger هر چهار migration روی PostgreSQL تعبیه‌شدهٔ PGlite، تست‌های ماشین حالت/ریسک/بازیابی/اعلان، ساختار Compose، PM2 و تولید امن env. PGlite آزمون سرور چنداتصالی PostgreSQL، advisory lock بین دو پردازش یا storage واقعی Docker نیست.

Docker daemon، VPS، Redis واقعی، TLS دامنه، delivery تلگرام، مانیتور UptimeRobot و نصب روی دستگاه Android در این محیط اجرا/تأیید نشده‌اند. build موفق TypeScript به معنی build موفق Docker یا تست واقعی صرافی نیست. فعال‌سازی LIVE تا تأیید قرارداد Bit24، permissionهای Trade-only/Withdraw-disabled، precision/fee، partial fill، reconciliation و سناریوهای crash مجاز نیست.
