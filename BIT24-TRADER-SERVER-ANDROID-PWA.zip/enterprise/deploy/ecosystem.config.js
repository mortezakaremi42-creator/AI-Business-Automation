const path = require('node:path');
module.exports = {
  apps: [{
    name: 'bit24-enterprise',
    cwd: path.resolve(__dirname, '..'),
    script: './dist/runtime.js',
    node_args: '--enable-source-maps',
    exec_mode: 'fork',
    instances: 1,
    autorestart: true,
    restart_delay: 1000,
    min_uptime: '10s',
    max_restarts: 20,
    max_memory_restart: '700M',
    kill_timeout: 60000,
    time: true,
    merge_logs: true,
    env_production: { NODE_ENV: 'production', TRADING_MODE: 'DRY_RUN', PORT: '3100' },
  }],
};
