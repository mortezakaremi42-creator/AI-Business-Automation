import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import type {Queue} from 'bullmq';
import {createNotificationProcessor,formatHeartbeat,formatCritical,notificationBackoff,
  redisNotificationConnection,NotificationDeliveryError,persistCriticalAlert,relayNotificationBatch,
  HEARTBEAT_INTERVAL_MS,DELIVERY_OPTIONS,type NotificationOutbox,type CriticalAlert,type PendingAlert} from '../src/NotificationService.js';
import {PgNotificationOutbox} from '../src/PgNotificationOutbox.js';
import type {Pool} from 'pg';
class MemoryOutbox implements NotificationOutbox {
  rows=new Map<string,PendingAlert>();delivered=new Set<string>();queued:string[]=[];
  async recordCritical(a:CriticalAlert){const id=randomUUID();this.rows.set(id,{id,tradeId:a.type==='BOUGHT_NO_OCO'?a.tradeId:null,code:a.type})}
  async listPending(_limit:number){return [...this.rows.values()].filter(x=>!this.delivered.has(x.id))}
  async getPending(id:string){return this.delivered.has(id)?null:this.rows.get(id)??null}
  async noteQueued(id:string){this.queued.push(id)}
  async markDelivered(id:string){this.delivered.add(id)}
}
const unknownStatus={getSnapshot:async()=>({mode:'DRY_RUN' as const,balances:null,openPositions:null,observedAt:null})};
const insert=async(box:MemoryOutbox)=>{await box.recordCritical({type:'BOUGHT_NO_OCO',tradeId:randomUUID()});return [...box.rows.keys()][0]};
test('heartbeat interval is 15 minutes with bounded retry configuration',()=>{
  assert.equal(HEARTBEAT_INTERVAL_MS,900000);assert.equal(DELIVERY_OPTIONS.attempts,12);assert.equal(DELIVERY_OPTIONS.removeOnFail,false);
});
test('heartbeat reports balances, positions, timestamps, process and host RAM',()=>{
  const message=formatHeartbeat({mode:'LIVE',balances:{USDT:'123.45'},openPositions:2,observedAt:new Date('2026-11-04T00:00:00Z')});
  for(const text of ['123.45','USDT','پوزیشن‌های باز: 2','RSS','Heap','RAM میزبان','2026-11-04T00:00:00.000Z'])assert.ok(message.includes(text));
});
test('missing/malformed financial status is unknown, not fabricated zero',()=>{
  const message=formatHeartbeat(null);assert.ok(message.includes('موجودی تأییدشده: نامشخص'));assert.ok(message.includes('پوزیشن‌های باز: نامشخص'));
  const invalid=formatHeartbeat({mode:'UNKNOWN',balances:{TOKEN:'NaN'},openPositions:NaN,observedAt:new Date('invalid')});assert.ok(!invalid.includes('NaN'));assert.ok(invalid.includes('نامشخص'));
});
test('heartbeat bounds assets and rejects injected asset labels/values',()=>{
  const balances=Object.fromEntries(Array.from({length:20},(_,i)=>['COIN'+i,'1']));balances['<script>']='secret';balances['PASS']='raw token';
  const message=formatHeartbeat({mode:'DRY_RUN',balances,openPositions:0,observedAt:null});assert.ok(!message.includes('COIN12'));assert.ok(!message.includes('<script>'));assert.ok(!message.includes('raw token'));
});
test('critical persistence returns without contacting Telegram or Redis',async()=>{
  const box=new MemoryOutbox();await persistCriticalAlert(box,{type:'EXCHANGE_API_DOWN'});assert.equal(box.rows.size,1);assert.equal(box.delivered.size,0);assert.equal(box.queued.length,0);
});
test('critical input validation rejects invalid IDs and arbitrary event types',async()=>{
  const box=new MemoryOutbox();await assert.rejects(persistCriticalAlert(box,{type:'BOUGHT_NO_OCO',tradeId:'bad'}));
  await assert.rejects(persistCriticalAlert(box,{type:'WITHDRAW'} as never));assert.equal(box.rows.size,0);
});
test('both required critical events have red alerts without arbitrary raw messages',()=>{
  for(const code of ['BOUGHT_NO_OCO','EXCHANGE_API_DOWN']){
    const text=formatCritical({id:randomUUID(),tradeId:null,code});assert.ok(text.startsWith('🔴'));assert.ok(text.length>50);
  }
  assert.ok(!formatCritical({id:randomUUID(),tradeId:null,code:'token-secret'}).includes('token-secret'));
});
test('relay enqueues reference-only priority job before marking queued, not delivered',async()=>{
  const box=new MemoryOutbox(),id=await insert(box);let calls=0;
  const queue={add:async(name:string,data:unknown,opts:{priority:number;jobId:string})=>{
    calls++;assert.equal(name,'critical');assert.deepEqual(data,{outboxId:id});assert.equal(opts.priority,1);assert.equal(opts.jobId,'recovery-'+id);assert.equal(box.queued.length,0);
  }} as unknown as Pick<Queue,'add'>;
  await relayNotificationBatch(box,queue);assert.equal(calls,1);assert.deepEqual(box.queued,[id]);assert.equal(box.delivered.size,0);
});
test('Redis enqueue failure leaves durable outbox untouched for retry',async()=>{
  const box=new MemoryOutbox();await insert(box);
  await assert.rejects(relayNotificationBatch(box,{add:async()=>{throw Error('offline')}} as unknown as Pick<Queue,'add'>));assert.equal(box.delivered.size,0);assert.equal(box.queued.length,0);assert.equal((await box.listPending(100)).length,1);
});
test('successful Telegram delivery precedes deliveredAt, replay does not resend',async()=>{
  const box=new MemoryOutbox(),id=await insert(box);let sends=0;
  const process=createNotificationProcessor({outbox:box,status:unknownStatus,sender:{send:async text=>{sends++;assert.equal(box.delivered.size,0);assert.ok(text.startsWith('🔴'))}}});
  await process({name:'critical',data:{outboxId:id}});await process({name:'critical',data:{outboxId:id}});assert.equal(sends,1);assert.ok(box.delivered.has(id));
});
test('Telegram failure remains pending and throws only sanitized error',async()=>{
  const box=new MemoryOutbox(),id=await insert(box);
  const process=createNotificationProcessor({outbox:box,status:unknownStatus,sender:{send:async()=>{throw Error('https://api.telegram.org/botSECRET')}}});
  await assert.rejects(process({name:'critical',data:{outboxId:id}}),(e:unknown)=>e instanceof NotificationDeliveryError&&!e.stack?.includes('SECRET'));
  assert.equal(box.delivered.size,0);
});
test('429 retry_after respected alongside exponential retry',async()=>{
  assert.equal(notificationBackoff(1),2000);assert.equal(notificationBackoff(2),4000);assert.equal(notificationBackoff(3),8000);
  const box=new MemoryOutbox(),id=await insert(box);
  const process=createNotificationProcessor({outbox:box,status:unknownStatus,sender:{send:async()=>{throw {response:{parameters:{retry_after:120}}}}}});
  await assert.rejects(process({name:'critical',data:{outboxId:id}}),(e:unknown)=>e instanceof NotificationDeliveryError && notificationBackoff(1,e)===120000);
});
test('snapshot provider failure still sends heartbeat with unknown balances',async()=>{
  let sent='';await createNotificationProcessor({outbox:new MemoryOutbox(),status:{getSnapshot:async()=>{throw Error('db failure')}},sender:{send:async text=>{sent=text}}})({name:'heartbeat',data:{}});
  assert.ok(sent.includes('نامشخص'));assert.ok(sent.includes('RSS'));
});
test('critical jobs do not wait for the heartbeat snapshot provider',async()=>{
  const box=new MemoryOutbox(),id=await insert(box);let calls=0;
  await createNotificationProcessor({outbox:box,status:{getSnapshot:async()=>{calls++;throw Error('not called')}},sender:{send:async()=>{}}})({name:'critical',data:{outboxId:id}});assert.equal(calls,0);
});
test('delivery followed by DB outage stays retryable (at-least-once, not exactly-once)',async()=>{
  const box=new MemoryOutbox(),id=await insert(box);box.markDelivered=async()=>{throw Error('db down')};let sent=0;
  const process=createNotificationProcessor({outbox:box,status:unknownStatus,sender:{send:async()=>{sent++}}});
  await assert.rejects(process({name:'critical',data:{outboxId:id}}),NotificationDeliveryError);assert.equal(sent,1);assert.equal(box.delivered.size,0);
});
test('invalid queue job fails without emitting text',async()=>{
  let sent=0;const process=createNotificationProcessor({outbox:new MemoryOutbox(),status:unknownStatus,sender:{send:async()=>{sent++}}});
  await assert.rejects(process({name:'bad',data:{}}),NotificationDeliveryError);assert.equal(sent,0);
});
test('Redis TLS, credentials and retry roles parsed safely',()=>{
  const producer=redisNotificationConnection('rediss://worker:p%40ss@redis.internal:6380/2') as {host:string;password:string;db:number;tls:unknown;maxRetriesPerRequest:unknown;commandTimeout:number};
  assert.equal(producer.host,'redis.internal');assert.equal(producer.password,'p@ss');assert.equal(producer.db,2);assert.ok(producer.tls);assert.equal(producer.maxRetriesPerRequest,1);assert.equal(producer.commandTimeout,5000);
  assert.equal((redisNotificationConnection('redis://host',true) as {maxRetriesPerRequest:null}).maxRetriesPerRequest,null);
  assert.throws(()=>redisNotificationConnection('https://host'));assert.throws(()=>redisNotificationConnection('redis://host/not-a-db'));
});
test('SQL outbox uses parameterized statements, fair pending order and deduplication',async()=>{
  const calls:{sql:string;args:unknown[]}[]=[];
  const pool={query:async(sql:string,args:unknown[])=>{calls.push({sql,args});return {rows:[]}}} as unknown as Pool;
  const outbox=new PgNotificationOutbox(pool);await outbox.recordCritical({type:'EXCHANGE_API_DOWN'});await outbox.listPending(100);
  assert.ok(calls[0].sql.includes('ON CONFLICT DO NOTHING'));assert.ok(calls[1].sql.includes('NULLS FIRST'));assert.deepEqual(calls[1].args,[100]);
  await assert.rejects(outbox.listPending(0));
});

import {PgTradingStore} from '../src/PgTradingStore.js';
import type {RecoveryTrade} from '../src/TradingContracts.js';
test('unprotected fill persists critical outbox in same transaction before commit',async()=>{
  const calls:string[]=[];
  const trade={id:randomUUID(),status:'BUY_UNKNOWN',version:0} as RecoveryTrade;
  const pool={connect:async()=>({query:async(sql:string)=>{calls.push(sql);return {rowCount:1,rows:[]}},release:()=>{}}),
    query:async()=>({rows:[trade]})} as unknown as Pool;
  await new PgTradingStore(pool).confirmBuy(trade,{kind:'UNPROTECTED',buyOrderId:'buy',amount:'1',entryPrice:'10',safeToSell:true});
  const alert=calls.findIndex(sql=>sql.includes('RecoveryAlerts'));
  assert.ok(alert>=0);assert.ok(alert<calls.indexOf('COMMIT'));assert.ok(calls[alert].includes('BOUGHT_NO_OCO'));
});
