import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { RiskManager, RiskRejectionError } from '../src/RiskManager.js';
import { Bit24Adapter, NetworkTimeoutError, UnknownSubmissionError, RedisTokenBucket, RateLimitWaitError, RateLimitUnavailableError, TOKEN_BUCKET_LUA, type VerifiedOrderContract } from '../src/Bit24Adapter.js';
const buy={baseCoin:'PEPE',quoteCoin:'USDT',amount:'1.25'};
const oco={...buy,stopLoss:'0.000000000000000001',takeProfit:'0.000000000000000002'};
const limiter={acquire:async()=>{}};
// Test codec only, not Bit24 response/OCO specification.
const contract:VerifiedOrderContract={decodeAcknowledgement:body=>({exchangeOrderId:(body as {testId:string}).testId}),encodeOCO:input=>({base_coin_symbol:input.baseCoin,quote_coin_symbol:input.quoteCoin,amount:input.amount,type:'3',side:'0',test_stop:input.stopLoss,test_take:input.takeProfit})};
const live=(fetchImpl:typeof fetch,extra={})=>new Bit24Adapter(limiter,{mode:'LIVE',apiKey:'test-api',secretKey:'test-secret',contract,fetchImpl,...extra});
test('risk accepts RSI below 75 with available capacity',async()=>{await new RiskManager({countActivePositions:async()=>2}).validateSignal({rsi:74.99})});
test('risk rejects RSI >=75 with exact code before querying positions',async()=>{
  let calls=0;const manager=new RiskManager({countActivePositions:async()=>{calls++;return 0}});
  for(const rsi of [75,75.1,100]) await assert.rejects(manager.validateSignal({rsi}),{code:'REJECTED_RSI_TOO_HIGH'});
  assert.equal(calls,0);
});
test('risk rejects full capacity and invalid RSI',async()=>{
  await assert.rejects(new RiskManager({countActivePositions:async()=>3}).validateSignal({rsi:60}),{code:'REJECTED_MAX_OPEN_POSITIONS'});
  for(const rsi of [NaN,Infinity,-1,101])await assert.rejects(new RiskManager({countActivePositions:async()=>0}).validateSignal({rsi}),{code:'REJECTED_INVALID_SIGNAL'});
});
test('risk fails closed on unavailable or malformed position state',async()=>{
  for(const count of [-1,1.5,NaN])await assert.rejects(new RiskManager({countActivePositions:async()=>count}).validateSignal({rsi:50}),RiskRejectionError);
  await assert.rejects(new RiskManager({countActivePositions:async()=>{throw Error('db')}}).validateSignal({rsi:50}),{code:'REJECTED_POSITION_STATE_UNAVAILABLE'});
});
test('dry run makes no HTTP calls, emits no exchange ID and skips live OCO encoder',async()=>{
  const adapter=new Bit24Adapter(limiter,{fetchImpl:async()=>{throw Error('MUST_NOT_FETCH')}});
  for(const result of [await adapter.placeMarketBuy(buy),await adapter.placeOCO(oco)]){
    assert.equal(result.mode,'DRY_RUN');assert.equal(result.simulated,true);assert.ok(!('exchangeOrderId' in result));
  }
});
test('invalid decimal orders and reversed OCO rejected before limiter/network',async()=>{
  let calls=0;const adapter=new Bit24Adapter({acquire:async()=>{calls++}});
  for(const amount of ['0','NaN','1e3','-1','0.0000000000000000001'])await assert.rejects(adapter.placeMarketBuy({...buy,amount}));
  await assert.rejects(adapter.placeOCO({...oco,stopLoss:'3',takeProfit:'2'}));assert.equal(calls,0);
});
test('live gate forbids HTTP without verified codec',async()=>{
  let calls=0;const adapter=new Bit24Adapter(limiter,{mode:'LIVE',apiKey:'test',secretKey:'test',fetchImpl:async()=>{calls++;return new Response('{}')}});
  await assert.rejects(adapter.placeMarketBuy(buy),/LIVE_CONTRACT_NOT_VERIFIED/);assert.equal(calls,0);
});
test('live OCO without certified encoder is blocked',async()=>{
  const adapter=new Bit24Adapter(limiter,{mode:'LIVE',apiKey:'test',secretKey:'test',contract:{decodeAcknowledgement:contract.decodeAcknowledgement}});
  await assert.rejects(adapter.placeOCO(oco),/OCO_CONTRACT_NOT_VERIFIED/);
});
test('signed market uses fixed documented endpoint and POST is sent once',async()=>{
  let count=0;
  const adapter=live(async(url,options)=>{
    count++;assert.equal(url,'https://rest.bit24.cash/pro/capi/v2/spot-orders/submit');assert.equal(options!.redirect,'error');
    const form=new URLSearchParams(String(options!.body)),signature=form.get('signature');form.delete('signature');
    assert.equal(form.get('type'),'1');assert.equal(form.get('side'),'1');assert.equal(form.get('amount'),'1.25');
    assert.equal(signature,createHmac('sha256','test-secret').update(form.toString()).digest('hex'));
    return Response.json({testId:'test-order'});
  });
  const result=await adapter.placeMarketBuy(buy);assert.equal(result.mode,'LIVE');assert.ok('status' in result && result.status==='ACKNOWLEDGED_NOT_VERIFIED');assert.equal(count,1);
});
test('timeout after dispatch is typed and is never retried',async()=>{
  let calls=0;const adapter=live(async(_url,options)=>{calls++;return new Promise((_ok,reject)=>options!.signal!.addEventListener('abort',()=>reject(new DOMException('aborted','AbortError'))))},{timeoutMs:5});
  await assert.rejects(adapter.placeMarketBuy(buy),(error:unknown)=>error instanceof NetworkTimeoutError && error.operation==='MARKET_BUY');assert.equal(calls,1);
});
test('OCO timeout remains operation OCO, not a new uncertain buy',async()=>{
  const adapter=live(async()=>{throw new DOMException('timeout','TimeoutError')});
  await assert.rejects(adapter.placeOCO(oco),(error:unknown)=>error instanceof NetworkTimeoutError && error.operation==='OCO');
});
test('HTTP errors, bad JSON, malformed ack and socket errors remain unknown',async()=>{
  for(const response of [()=>new Response('{}',{status:429}),()=>new Response('{}',{status:500}),()=>new Response('bad json'),()=>Response.json({}),()=>{throw Error('socket reset')}]){
    let calls=0;await assert.rejects(live(async()=>{calls++;return response()}).placeMarketBuy(buy),UnknownSubmissionError);assert.equal(calls,1);
  }
});
test('bucket uses Redis script and shared key; waits then consumes',async()=>{
  let n=0;const waits:number[]=[];const key=Bit24Adapter.bucketKey('test-key');assert.ok(!key.includes('test-key'));
  const bucket=new RedisTokenBucket({eval:async(script,options)=>{
    assert.equal(script,TOKEN_BUCKET_LUA);assert.deepEqual(options.keys,[key]);assert.deepEqual(options.arguments,['2','1']);return n++===0?[0,500]:[1,0];
  }},key,2,1,async ms=>{waits.push(ms)});
  await bucket.acquire();assert.equal(n,2);assert.deepEqual(waits,[500]);
});
test('bucket budget exhaustion is not exchange timeout',async()=>{
  const bucket=new RedisTokenBucket({eval:async()=>[0,500]},'test');await assert.rejects(bucket.acquire(0),RateLimitWaitError);
});
test('Redis errors fail closed before POST and are not BUY_UNKNOWN',async()=>{
  let calls=0;const bucket=new RedisTokenBucket({eval:async()=>{throw Error('Redis down')}},'test');
  const adapter=new Bit24Adapter(bucket,{mode:'LIVE',apiKey:'test',secretKey:'test',contract,fetchImpl:async()=>{calls++;return Response.json({})}});
  await assert.rejects(adapter.placeMarketBuy(buy),RateLimitUnavailableError);assert.equal(calls,0);
});
test('malformed Redis result fails closed',async()=>{
  await assert.rejects(new RedisTokenBucket({eval:async()=>['bad',0]},'test').acquire(),RateLimitUnavailableError);
});
