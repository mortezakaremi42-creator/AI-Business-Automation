import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {parse} from 'yaml';
import {PGlite} from '@electric-sql/pglite';
const file=(p:string)=>readFile(new URL('../'+p,import.meta.url),'utf8');
test('Compose has exactly three restart-always services and no public database/cache',async()=>{
  const c=parse(await file('docker-compose.yml'));
  assert.deepEqual(Object.keys(c.services).sort(),['app','postgres','redis']);
  for(const s of Object.values(c.services) as {restart:string}[])assert.equal(s.restart,'always');
  assert.equal(c.services.postgres.ports,undefined);assert.equal(c.services.redis.ports,undefined);
  assert.deepEqual(c.services.app.ports,['127.0.0.1:3100:3100']);assert.equal(c.services.app.environment.TRADING_MODE,'DRY_RUN');
  assert.equal(c.services.app.read_only,true);assert.deepEqual(c.services.app.cap_drop,['ALL']);
  assert.equal(await file('docker-compose.yml'),await file('compose.yml'));
});
test('production build runs compiled JavaScript as non-root; env excluded from build context',async()=>{
  const docker=await file('Dockerfile');assert.equal((docker.match(/^FROM /gm)||[]).length,3);
  assert.ok(docker.includes('npm ci --omit=dev'));assert.ok(docker.includes('USER node'));assert.ok(docker.includes('dist/runtime.js'));
  assert.ok(!docker.includes('tsx'));assert.ok((await file('.dockerignore')).includes('.env'));
});
test('PM2 config is CommonJS in its own scope and singleton',async()=>{
  const require=createRequire(import.meta.url);const c=require('../deploy/ecosystem.config.js');
  assert.equal(c.apps[0].instances,1);assert.equal(c.apps[0].exec_mode,'fork');assert.equal(c.apps[0].autorestart,true);
  assert.equal(c.apps[0].env_production.TRADING_MODE,'DRY_RUN');
});
test('mobile manifest, secure shell and service worker do not cache APIs',async()=>{
  const m=JSON.parse(await file('public/manifest.webmanifest'));assert.equal(m.display,'standalone');assert.equal(m.dir,'rtl');
  for(const icon of m.icons)assert.ok((await readFile(new URL('../public'+icon.src,import.meta.url))).length>0);
  const sw=await file('public/sw.js');assert.ok(sw.includes("u.pathname.startsWith('/api/')"));assert.ok(!sw.includes('BackgroundSync'));
  const js=await file('public/app.js');assert.ok(!js.includes('localStorage'));assert.ok(js.includes('credentials:'));
});
test('all phase migrations and state triggers execute on embedded PostgreSQL engine',async()=>{
  const db=new PGlite();
  try{
    for(const p of ['phase1/001_order_state_machine.sql','phase3/001_recovery_journal.sql','phase4/001_notification_outbox.sql','phase5/001_signal_inbox.sql'])await db.exec(await file('sql/'+p));
    const id='f2f464e8-147f-4cb1-966b-6a04b40d3baf';
    await db.query(`INSERT INTO trading_v2."Trades"(id,symbol,side,"entryPrice",amount) VALUES($1,'PEPE/USDT','BUY',10,1)`,[id]);
    await assert.rejects(db.query(`UPDATE trading_v2."Trades" SET status='SECURED',version=version+1 WHERE id=$1`,[id]));
    await db.query(`UPDATE trading_v2."Trades" SET status='BUY_UNKNOWN',version=version+1 WHERE id=$1`,[id]);
    await db.query(`UPDATE trading_v2."Trades" SET "buyOrderId"='confirmed-buy',version=version+1 WHERE id=$1`,[id]);
    await assert.rejects(db.query(`UPDATE trading_v2."Trades" SET status='BOUGHT_NO_OCO' WHERE id=$1`,[id]));
    await db.query(`UPDATE trading_v2."Trades" SET status='BOUGHT_NO_OCO',version=version+1 WHERE id=$1`,[id]);
    await db.query(`UPDATE trading_v2."Trades" SET status='SECURED',version=version+1 WHERE id=$1`,[id]);
    const rows=await db.query<{status:string;version:number}>(`SELECT status,version FROM trading_v2."Trades" WHERE id=$1`,[id]);assert.equal(rows.rows[0].status,'SECURED');assert.equal(rows.rows[0].version,4);
    await db.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey") VALUES('a62bac21-c9b9-4b1d-af86-d43fa930764b',$1,'BOUGHT_NO_OCO','one')`,[id]);
    await assert.rejects(db.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey") VALUES('dd68e27c-78ea-40bb-8c73-301a5c16d003',$1,'BOUGHT_NO_OCO','one')`,[id]));
  }finally{await db.close()}
});

import {mkdtemp,stat,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
test('setup creates private random env, never overwrites credentials',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'bit24-setup-'));
  try{
    const script=new URL('../scripts/setup-env.mjs',import.meta.url).pathname;
    const first=spawnSync(process.execPath,[script],{cwd:dir,input:'https://bot.example.test\n',encoding:'utf8'});assert.equal(first.status,0);
    const env=await readFile(join(dir,'.env'),'utf8');assert.ok(env.includes('TRADING_MODE=DRY_RUN'));assert.ok(env.includes('ADMIN_PASSWORD_HASH='));assert.ok(!env.includes('BIT24_API_KEY='));
    assert.equal((await stat(join(dir,'.env'))).mode & 0o777,0o600);
    const second=spawnSync(process.execPath,[script],{cwd:dir,input:'https://bot.example.test\n',encoding:'utf8'});assert.equal(second.status,1);assert.equal(await readFile(join(dir,'.env'),'utf8'),env);
  }finally{await rm(dir,{recursive:true,force:true})}
});
