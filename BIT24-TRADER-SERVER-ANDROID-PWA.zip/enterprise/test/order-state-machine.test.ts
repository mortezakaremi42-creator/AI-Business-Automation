import { test } from 'node:test';
import assert from 'node:assert/strict';
import { OrderStates as S } from '../src/orders/types.js';
import { OrderStateMachine, TRANSITIONS, type Evidence } from '../src/orders/OrderStateMachine.js';
import { OrderStateRepository, StateConflict } from '../src/orders/OrderStateRepository.js';
import type { Pool } from 'pg';
const evidence = (to:string):Evidence => to===S.BUY_UNKNOWN?{kind:'SUBMISSION_UNCERTAIN'}:
  to===S.BOUGHT_NO_OCO?{kind:'BUY_FILL_CONFIRMED',exchangeOrderId:'buy-1'}:
  to===S.SECURED?{kind:'OCO_CONFIRMED',exchangeProtectionId:'oco-1'}:
  {kind:'NO_EXECUTION_CONFIRMED',source:'RECONCILIATION'};
const allowed = new Set(['PENDING_BUY:BUY_UNKNOWN','PENDING_BUY:BOUGHT_NO_OCO','PENDING_BUY:FAILED','BUY_UNKNOWN:BOUGHT_NO_OCO','BUY_UNKNOWN:FAILED','BOUGHT_NO_OCO:SECURED']);
for (const from of Object.values(S)) for(const to of Object.values(S)) {
  test(`${from} -> ${to}`,()=>{
    const machine=new OrderStateMachine(from), valid=allowed.has(`${from}:${to}`);
    assert.equal(machine.canTransition(to),valid);
    if(valid){assert.equal(machine.transition(to,evidence(to)).state,to);assert.equal(machine.state,from)}
    else assert.throws(()=>machine.transition(to,evidence(to)),/Illegal order transition/);
  });
}
test('unknown buy cannot fail based only on local assumption or rejection',()=>{
  for(const source of ['LOCAL_PRE_SUBMIT','EXCHANGE_REJECTION'] as const)
    assert.throws(()=>new OrderStateMachine(S.BUY_UNKNOWN).transition(S.FAILED,{kind:'NO_EXECUTION_CONFIRMED',source}),/EVIDENCE/);
});
test('buy fill and protection require nonempty exchange identifiers',()=>{
  assert.throws(()=>new OrderStateMachine().transition(S.BOUGHT_NO_OCO,{kind:'BUY_FILL_CONFIRMED',exchangeOrderId:' '}));
  assert.throws(()=>new OrderStateMachine(S.BOUGHT_NO_OCO).transition(S.SECURED,{kind:'OCO_CONFIRMED',exchangeProtectionId:''}));
});
test('transition map cannot be mutated',()=>assert.throws(()=>{(TRANSITIONS.PENDING_BUY as string[]).push(S.SECURED)}));
test('runtime invalid state rejected',()=>assert.throws(()=>new OrderStateMachine('toString' as never)));
function mockPool(rowCount:number, auditFails=false){
  const calls:string[]=[];
  const c={query:async(sql:string)=>{calls.push(sql);if(sql.startsWith('INSERT')&&auditFails)throw Error('AUDIT_WRITE_FAILED');return {rowCount,rows:[{status:S.BUY_UNKNOWN,version:1}]};},release:()=>calls.push('RELEASE')};
  return {pool:{connect:async()=>c} as unknown as Pool,calls};
}
const input={id:'00000000-0000-4000-8000-000000000001',expectedState:S.PENDING_BUY,expectedVersion:0,to:S.BUY_UNKNOWN,evidence:{kind:'SUBMISSION_UNCERTAIN'} as Evidence};
test('CAS miss rolls back, writes no audit',async()=>{
  const f=mockPool(0);await assert.rejects(new OrderStateRepository(f.pool).transition(input),StateConflict);
  assert.ok(f.calls.includes('ROLLBACK'));assert.ok(!f.calls.some(x=>x.startsWith('INSERT')));assert.equal(f.calls.at(-1),'RELEASE');
});
test('successful CAS and audit commit together',async()=>{
  const f=mockPool(1);await new OrderStateRepository(f.pool).transition(input);
  assert.ok(f.calls.some(x=>x.startsWith('INSERT')));assert.ok(f.calls.includes('COMMIT'));assert.ok(!f.calls.includes('ROLLBACK'));
});
test('audit error rolls back state mutation',async()=>{
  const f=mockPool(1,true);await assert.rejects(new OrderStateRepository(f.pool).transition(input),/AUDIT/);
  assert.ok(f.calls.includes('ROLLBACK'));assert.ok(!f.calls.includes('COMMIT'));
});
