import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { Reconciler } from '../src/Reconciler.js';
import { TradingEngine } from '../src/TradingEngine.js';
import { RiskManager } from '../src/RiskManager.js';
import { Bit24Adapter, NetworkTimeoutError, type Submission } from '../src/Bit24Adapter.js';
import type { TradingStore, RecoveryTrade, TradingSignal, Inspection, TradingExchange } from '../src/TradingContracts.js';
import type { OrderState } from '../src/orders/types.js';
class MemoryStore implements TradingStore {
  rows=new Map<string,RecoveryTrade>();dry=new Set<string>();alerts:string[]=[];events:string[]=[];claimed=new Set<string>();owned=false;
  async acquireLeadership(){this.owned=true;this.events.push('leader')}
  async assertOwnership(){if(!this.owned)throw Error('no leader')}
  async releaseLeadership(){this.owned=false;this.events.push('released')}
  async listRecoveryTrades(){return [...this.rows.values()].filter(t=>!this.dry.has(t.id)&&['PENDING_BUY','BUY_UNKNOWN','BOUGHT_NO_OCO'].includes(t.status)&&t.exitStatus!=='CONFIRMED').map(t=>({...t}))}
  async get(id:string){return {...this.rows.get(id)!}}
  async countActivePositions(){return [...this.rows.values()].filter(t=>!this.dry.has(t.id)&&t.status!=='FAILED'&&t.exitStatus!=='CONFIRMED').length}
  async reserve(s:TradingSignal,dry:boolean,max:number){
    if(this.rows.has(s.id)||await this.countActivePositions()>=max)return null;
    const t:RecoveryTrade={id:s.id,symbol:s.baseCoin+'/'+s.quoteCoin,side:'BUY',entryPrice:s.entryPrice,amount:s.amount,status:'PENDING_BUY',version:0,createdAt:new Date(),updatedAt:new Date(),stopLoss:s.stopLoss,takeProfit:s.takeProfit,buyOrderId:null,ocoOrderId:null,ocoAttemptedAt:null,exitOrderId:null,exitStatus:null};
    this.rows.set(t.id,t);if(dry)this.dry.add(t.id);this.events.push('reserved');return {...t};
  }
  async transition(t:RecoveryTrade,to:OrderState){const row=this.rows.get(t.id)!;assert.equal(t.version,row.version);row.status=to;row.version++;return {...row}}
  async confirmBuy(t:RecoveryTrade,f:Extract<Inspection,{kind:'UNPROTECTED'|'PROTECTED'}>){
    const row=this.rows.get(t.id)!;assert.equal(row.version,t.version);Object.assign(row,{status:'BOUGHT_NO_OCO',amount:f.amount,entryPrice:f.entryPrice,buyOrderId:f.buyOrderId,version:row.version+1});
    if(f.kind==='PROTECTED')row.ocoOrderId=f.protectionId;return {...row};
  }
  async saveBuyAck(id:string,orderId:string){this.rows.get(id)!.buyOrderId=orderId;this.events.push('buyAck')}
  async markOcoAttempted(id:string){this.rows.get(id)!.ocoAttemptedAt=new Date();this.events.push('ocoIntent')}
  async saveOcoAck(id:string,orderId:string){this.rows.get(id)!.ocoOrderId=orderId}
  async completeSimulation(id:string){this.events.push('simulated:'+id)}
  async claimEmergencyExit(t:RecoveryTrade,_amount:string){if(this.claimed.has(t.id))return false;this.claimed.add(t.id);this.rows.get(t.id)!.exitStatus='SUBMITTING';this.events.push('exitIntent');return true}
  async saveExitAck(id:string,orderId:string){Object.assign(this.rows.get(id)!,{exitStatus:'UNKNOWN',exitOrderId:orderId})}
  async markExitUnknown(id:string){this.rows.get(id)!.exitStatus='UNKNOWN'}
  async confirmExit(id:string,orderId:string){Object.assign(this.rows.get(id)!,{exitStatus:'CONFIRMED',exitOrderId:orderId})}
  async alert(_id:string|null,code:string){this.alerts.push(code)}
}
const sig=():TradingSignal=>({id:randomUUID(),baseCoin:'PEPE',quoteCoin:'USDT',amount:'1',entryPrice:'10',stopLoss:'9',takeProfit:'12',rsi:50,timestamp:Date.now()});
const naked:Inspection={kind:'UNPROTECTED',buyOrderId:'buy',amount:'0.9',entryPrice:'10',safeToSell:true};
function exchange(inspect:(t:RecoveryTrade)=>Promise<Inspection>):TradingExchange {
  const ack=(operation:'MARKET_BUY'|'MARKET_SELL'|'OCO'):Submission=>({mode:'LIVE',simulated:false,operation,exchangeOrderId:operation==='MARKET_BUY'?'buy':operation,status:'ACKNOWLEDGED_NOT_VERIFIED'});
  return {executionMode:'LIVE',assertConfiguredForLiveTrading:()=>{},inspectTrade:inspect,placeMarketBuy:async()=>ack('MARKET_BUY'),placeMarketSell:async()=>ack('MARKET_SELL'),placeOCO:async()=>ack('OCO')};
}
async function setup(status:OrderState='BUY_UNKNOWN'){
  const store=new MemoryStore();await store.acquireLeadership();let t=(await store.reserve(sig(),false,3))!;
  store.rows.get(t.id)!.status=status;return {store,id:t.id};
}
test('startup unresolved buy blocks without submitting anything',async()=>{
  const {store}=await setup();const report=await new Reconciler(store,exchange(async()=>({kind:'UNKNOWN'}))).reconcileOnStartup();assert.equal(report.ready,false);assert.equal(store.claimed.size,0);
});
test('no execution proven by reconciliation transitions unknown to failed',async()=>{
  const {store,id}=await setup();assert.equal((await new Reconciler(store,exchange(async()=>({kind:'NO_EXECUTION_CONFIRMED'}))).reconcileOnStartup()).ready,true);assert.equal(store.rows.get(id)!.status,'FAILED');
});
test('already protected buy is secured without emergency sell',async()=>{
  const {store,id}=await setup();const ex=exchange(async()=>({kind:'PROTECTED',buyOrderId:'buy',amount:'1',entryPrice:'10',protectionId:'oco'}));
  ex.placeMarketSell=async()=>{throw Error('must not sell')};assert.equal((await new Reconciler(store,ex).reconcileOnStartup()).ready,true);assert.equal(store.rows.get(id)!.status,'SECURED');
});
test('unprotected buy journals before selling exact net amount; ACK requires fill verification',async()=>{
  const {store,id}=await setup();let n=0;
  const ex=exchange(async()=>++n===1?naked:{kind:'EXIT_CONFIRMED',exitOrderId:'sell'});
  ex.placeMarketSell=async input=>{assert.equal(store.events.at(-1),'exitIntent');assert.equal(input.amount,'0.9');return {mode:'LIVE',simulated:false,operation:'MARKET_SELL',exchangeOrderId:'sell',status:'ACKNOWLEDGED_NOT_VERIFIED'}};
  const report=await new Reconciler(store,ex).reconcileOnStartup();assert.equal(report.ready,true);assert.equal(store.rows.get(id)!.exitStatus,'CONFIRMED');assert.equal(await store.countActivePositions(),0);
});
test('timed out emergency sell is never blindly repeated on next startup',async()=>{
  const {store,id}=await setup('BOUGHT_NO_OCO');let sells=0;const ex=exchange(async()=>naked);
  ex.placeMarketSell=async()=>{sells++;throw new NetworkTimeoutError('MARKET_SELL')};const r=new Reconciler(store,ex);
  assert.equal((await r.reconcileOnStartup()).ready,false);assert.equal((await r.reconcileOnStartup()).ready,false);assert.equal(sells,1);assert.equal(store.rows.get(id)!.exitStatus,'UNKNOWN');
});
test('restart between exit intent and HTTP does not resubmit an uncertain sell',async()=>{
  const {store,id}=await setup('BOUGHT_NO_OCO');await store.claimEmergencyExit(await store.get(id),'1');let calls=0;
  const ex=exchange(async()=>naked);ex.placeMarketSell=async()=>{calls++;throw Error()};await new Reconciler(store,ex).reconcileOnStartup();assert.equal(calls,0);
});
test('exit fill detected after restart clears recovery journal',async()=>{
  const {store,id}=await setup('BOUGHT_NO_OCO');await store.claimEmergencyExit(await store.get(id),'1');
  assert.equal((await new Reconciler(store,exchange(async()=>({kind:'EXIT_CONFIRMED',exitOrderId:'sell'}))).reconcileOnStartup()).ready,true);assert.equal(store.rows.get(id)!.exitStatus,'CONFIRMED');
});
test('read API outage never becomes proof of no execution',async()=>{
  const {store,id}=await setup();const r=await new Reconciler(store,exchange(async()=>{throw Error('network')})).reconcileOnStartup();assert.equal(r.ready,false);assert.equal(store.rows.get(id)!.status,'BUY_UNKNOWN');
});
test('dry run cannot liquidate existing live holdings',async()=>{
  const {store}=await setup();const ex=new Bit24Adapter({acquire:async()=>{}});const r=await new Reconciler(store,ex).reconcileOnStartup();assert.equal(r.ready,false);assert.equal(store.claimed.size,0);
});
test('engine runs recovery before fetching signals and pauses when unresolved',async()=>{
  const store=new MemoryStore(),stop=new AbortController();let signals=0;
  const engine=new TradingEngine(store,exchange(async()=>({kind:'UNKNOWN'})),new RiskManager(store),{next:async()=>{signals++;return null}},
    {reconcileOnStartup:async()=>({ready:false,examined:1,unresolved:1})},{wait:async ms=>{assert.equal(ms,2000);stop.abort()}});
  await engine.run(stop.signal);assert.equal(signals,0);assert.equal(store.owned,false);
});
test('dry run engine risk validates, reserves then simulates; replay UUID is skipped',async()=>{
  const store=new MemoryStore(),stop=new AbortController(),s=sig();let count=0;
  const adapter=new Bit24Adapter({acquire:async()=>{}});
  const engine=new TradingEngine(store,adapter,new RiskManager(store),{next:async()=>s},new Reconciler(store,adapter),{wait:async()=>{if(++count===2)stop.abort()}});
  await engine.run(stop.signal);assert.equal(store.rows.size,1);assert.equal(store.events.filter(x=>x.startsWith('simulated:')).length,1);
});
test('RSI rejected before reserve and before adapter',async()=>{
  const store=new MemoryStore(),stop=new AbortController(),adapter=new Bit24Adapter({acquire:async()=>{throw Error('not called')}});
  const engine=new TradingEngine(store,adapter,new RiskManager(store),{next:async()=>({...sig(),rsi:80})},new Reconciler(store,adapter),{wait:async()=>{stop.abort()}});
  await engine.run(stop.signal);assert.equal(store.rows.size,0);
});
test('live buy marked UNKNOWN BEFORE request and timeout does not retry',async()=>{
  const store=new MemoryStore(),stop=new AbortController();let buys=0;
  const ex=exchange(async()=>({kind:'UNKNOWN'}));ex.placeMarketBuy=async()=>{buys++;assert.equal([...store.rows.values()][0].status,'BUY_UNKNOWN');throw new NetworkTimeoutError('MARKET_BUY')};
  const engine=new TradingEngine(store,ex,new RiskManager(store),{next:async()=>sig()},new Reconciler(store,ex),{wait:async()=>{stop.abort()}});
  await engine.run(stop.signal);assert.equal(buys,1);assert.equal([...store.rows.values()][0].status,'BUY_UNKNOWN');
});
test('live terminal fill gets OCO for net quantity then verification secures it',async()=>{
  const store=new MemoryStore(),stop=new AbortController();let inspected=0,ocos=0,sells=0;
  const ex=exchange(async()=>++inspected===1?naked:{kind:'PROTECTED',buyOrderId:'buy',amount:'0.9',entryPrice:'10',protectionId:'oco'});
  ex.placeOCO=async input=>{ocos++;assert.equal(input.amount,'0.9');assert.equal(store.events.at(-1),'ocoIntent');return {mode:'LIVE',simulated:false,operation:'OCO',exchangeOrderId:'oco',status:'ACKNOWLEDGED_NOT_VERIFIED'}};
  ex.placeMarketSell=async()=>{sells++;throw Error('no sell')};
  const engine=new TradingEngine(store,ex,new RiskManager(store),{next:async()=>sig()},new Reconciler(store,ex),{wait:async()=>{stop.abort()}});
  await engine.run(stop.signal);assert.equal(ocos,1);assert.equal(sells,0);assert.equal([...store.rows.values()][0].status,'SECURED');
});
test('backoff is bounded 2,4,8 seconds and abort releases ownership',async()=>{
  const store=new MemoryStore(),stop=new AbortController(),delays:number[]=[];
  const engine=new TradingEngine(store,exchange(async()=>({kind:'UNKNOWN'})),new RiskManager(store),{next:async()=>{throw Error('not called')}},
    {reconcileOnStartup:async()=>{throw Error('offline')}},{wait:async ms=>{delays.push(ms);if(delays.length===3)stop.abort()}});
  await engine.run(stop.signal);assert.deepEqual(delays,[2000,4000,8000]);assert.equal(store.events.at(-1),'released');
});
test('aborted engine does not acquire leader or fetch',async()=>{
  const store=new MemoryStore(),stop=new AbortController();stop.abort();const ex=exchange(async()=>({kind:'UNKNOWN'}));
  await new TradingEngine(store,ex,new RiskManager(store),{next:async()=>null},new Reconciler(store,ex)).run(stop.signal);assert.equal(store.events.length,0);
});
test('OCO timeout followed by protection confirmation never triggers market sell',async()=>{
  const store=new MemoryStore(),stop=new AbortController();let probes=0,sells=0,waits=0,ocos=0;
  const ex=exchange(async()=>++probes===1?naked:{kind:'PROTECTED',buyOrderId:'buy',amount:'0.9',entryPrice:'10',protectionId:'oco'});
  ex.placeOCO=async()=>{ocos++;throw new NetworkTimeoutError('OCO')};
  ex.placeMarketSell=async()=>{sells++;throw Error('must not sell')};
  const s=sig();const engine=new TradingEngine(store,ex,new RiskManager(store),{next:async()=>s},new Reconciler(store,ex),{wait:async()=>{if(++waits===2)stop.abort()}});
  await engine.run(stop.signal);assert.equal(ocos,1);assert.equal(sells,0);assert.equal([...store.rows.values()][0].status,'SECURED');
});
test('sell ACK without a confirmed fill keeps all new trading blocked',async()=>{
  const {store}=await setup();let sells=0;const ex=exchange(async()=>naked);
  ex.placeMarketSell=async()=>{sells++;return {mode:'LIVE',simulated:false,operation:'MARKET_SELL',exchangeOrderId:'sell',status:'ACKNOWLEDGED_NOT_VERIFIED'}};
  const reconciler=new Reconciler(store,ex);assert.equal((await reconciler.reconcileOnStartup()).ready,false);
  assert.equal((await reconciler.reconcileOnStartup()).ready,false);assert.equal(sells,1);
});
test('inconsistent fill IDs halt instead of liquidating an unrelated holding',async()=>{
  const {store,id}=await setup();store.rows.get(id)!.buyOrderId='expected-buy';let sells=0;
  const ex=exchange(async()=>naked);ex.placeMarketSell=async()=>{sells++;throw Error()};
  assert.equal((await new Reconciler(store,ex).reconcileOnStartup()).ready,false);assert.equal(sells,0);
});
test('pending crash records are inspected before any fresh signal',async()=>{
  const {store,id}=await setup('PENDING_BUY');let inspected=0;
  const ex=exchange(async()=>{inspected++;return {kind:'UNKNOWN'}});
  assert.equal((await new Reconciler(store,ex).reconcileOnStartup()).ready,false);assert.equal(inspected,1);assert.equal(store.rows.get(id)!.status,'PENDING_BUY');
});
test('recovery protected state does not discard an already uncertain emergency sell',async()=>{
  const {store,id}=await setup('BOUGHT_NO_OCO');await store.claimEmergencyExit(await store.get(id),'1');
  const ex=exchange(async()=>({kind:'PROTECTED',buyOrderId:'buy',amount:'1',entryPrice:'10',protectionId:'oco'}));
  assert.equal((await new Reconciler(store,ex).reconcileOnStartup()).ready,false);assert.equal(store.rows.get(id)!.status,'BOUGHT_NO_OCO');
});
test('adapter emergency sell uses documented market side and fixed path',async()=>{
  let calls=0;
  const adapter=new Bit24Adapter({acquire:async()=>{}},{mode:'LIVE',apiKey:'test',secretKey:'test',
    contract:{decodeAcknowledgement:()=>({exchangeOrderId:'sell'})},fetchImpl:async(url,options)=>{
      calls++;assert.equal(url,'https://rest.bit24.cash/pro/capi/v2/spot-orders/submit');const f=new URLSearchParams(String(options!.body));
      assert.equal(f.get('type'),'1');assert.equal(f.get('side'),'0');return Response.json({});
    }});
  const ack=await adapter.placeMarketSell({baseCoin:'PEPE',quoteCoin:'USDT',amount:'0.9'});assert.equal(ack.operation,'MARKET_SELL');assert.equal(calls,1);
});
test('adapter reconciliation exposes only fixed order-read endpoint with shared limiter',async()=>{
  let consumes=0;
  const adapter=new Bit24Adapter({acquire:async()=>{consumes++}},{mode:'LIVE',apiKey:'test',secretKey:'test',
    contract:{decodeAcknowledgement:()=>({exchangeOrderId:'test'}),inspectTrade:async(_trade,read)=>{await read({page:'1'});return {kind:'UNKNOWN'}}},
    fetchImpl:async(url,options)=>{assert.equal(url,'https://rest.bit24.cash/pro/capi/v2/spot-orders?page=1');assert.equal(options!.method,'GET');return Response.json({})}});
  const {store,id}=await setup();assert.equal((await adapter.inspectTrade(await store.get(id))).kind,'UNKNOWN');assert.equal(consumes,1);
});
test('engine refuses live buy if recovery/protection not configured',async()=>{
  const store=new MemoryStore(),stop=new AbortController();let buys=0;
  const ex=exchange(async()=>({kind:'UNKNOWN'}));ex.assertConfiguredForLiveTrading=()=>{throw Error('not certified')};
  ex.placeMarketBuy=async()=>{buys++;throw Error()};
  await new TradingEngine(store,ex,new RiskManager(store),{next:async()=>sig()},new Reconciler(store,ex),{wait:async()=>{stop.abort()}}).run(stop.signal);
  assert.equal(buys,0);assert.equal(store.rows.size,0);
});
