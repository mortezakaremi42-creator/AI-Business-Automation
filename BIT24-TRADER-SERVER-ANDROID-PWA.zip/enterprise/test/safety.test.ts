import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validate, type Signal} from '../src/risk.js';
import {retryRead,TransientError} from '../src/retry.js';
import {UnverifiedBit24Adapter} from '../src/exchange.js';
const valid=():Signal=>({id:'a',symbol:'PEPE/USDT',rsi:60,price:10,stop:9,take:13,quantity:1,balance:1000,exposure:0,spreadBps:10,timestamp:Date.now()});
test('valid risk passes',()=>validate(valid()));
test('RSI 75 and above rejected',()=>{for(const rsi of [75,76,100])assert.throws(()=>validate({...valid(),rsi}),/FOMO/)});
test('stale, NaN, oversized and invalid stops fail',()=>{for(const change of [{timestamp:1},{price:NaN},{quantity:1000},{stop:11}])assert.throws(()=>validate({...valid(),...change}))});
test('read backoff starts 2,4,8 seconds',async()=>{let n=0;const waits:number[]=[];assert.equal(await retryRead(async()=>{if(n++<3)throw new TransientError();return 7},async ms=>{waits.push(ms)}),7);waits.forEach((ms,i)=>assert.ok(ms>=2000*2**i&&ms<2000*2**i+250))});
test('permanent failures not retried',async()=>{let n=0;await assert.rejects(retryRead(async()=>{n++;throw Error('invalid credentials')}));assert.equal(n,1)});
test('uncertified exchange fails closed',async()=>{await assert.rejects(new UnverifiedBit24Adapter().verifyCapabilities());await assert.rejects(new UnverifiedBit24Adapter().marketBuy())});

import { Engine } from '../src/engine.js';
import type { Store } from '../src/store.js';
import type { Exchange } from '../src/exchange.js';
function fixture(failBuy=false, failOco=false) {
  const states:string[]=[], ids=new Set<string>();let buys=0,ocos=0;
  const store={db:{query:async(sql:string,args?:string[])=>{
    if(sql.startsWith('INSERT')){if(ids.has(args![0]))return {rowCount:0};ids.add(args![0]);return {rowCount:1}}
    return {rows:[],rowCount:0};
  }},state:async(_id:string,state:string)=>{states.push(state)},audit:async()=>{},alert:async()=>{}} as unknown as Store;
  const exchange:Exchange={verifyCapabilities:async()=>{},reconcile:async()=>({consistent:true,balances:{USDT:1000},positions:[],openOrders:[]}),marketBuy:async()=>{buys++;if(failBuy)throw Error('timeout');return {id:'fill',quantity:1,price:10}},nativeOco:async()=>{ocos++;if(failOco)throw Error('timeout');return {id:'oco'}}};
  return {engine:new Engine(store,exchange),states,counts:()=>({buys,ocos})};
}
test('successful order persisted then protected; duplicate signal does not rebuy',async()=>{
  const f=fixture();await f.engine.recover();const s=valid();await f.engine.onSignal(s);await f.engine.onSignal(s);assert.deepEqual(f.counts(),{buys:1,ocos:1});assert.deepEqual(f.states,['SUBMITTING','PROTECTING','PROTECTED']);
});
test('ambiguous buy never retried, engine halted',async()=>{
  const f=fixture(true);await f.engine.recover();await assert.rejects(f.engine.onSignal(valid()));assert.equal(f.engine.ready,false);assert.equal(f.counts().buys,1);assert.equal(f.states.at(-1),'UNKNOWN');
});
test('OCO failure halts, no repeated buy',async()=>{
  const f=fixture(false,true);await f.engine.recover();await assert.rejects(f.engine.onSignal(valid()));assert.equal(f.engine.ready,false);assert.equal(f.counts().buys,1);assert.equal(f.states.at(-1),'UNKNOWN');
});
