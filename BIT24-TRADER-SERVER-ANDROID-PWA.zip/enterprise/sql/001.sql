CREATE TABLE IF NOT EXISTS intents (
 id text PRIMARY KEY, symbol text NOT NULL, state text NOT NULL CHECK(state IN ('PREPARED','SUBMITTING','UNKNOWN','PROTECTING','PROTECTED','HALTED','CLOSED')),
 payload jsonb NOT NULL, exchange_id text, protection_id text, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_symbol ON intents(symbol) WHERE state <> 'CLOSED';
CREATE TABLE IF NOT EXISTS audit (id bigserial PRIMARY KEY, event text NOT NULL, details jsonb NOT NULL, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS alerts (id bigserial PRIMARY KEY, body text NOT NULL, attempts integer NOT NULL DEFAULT 0, next_at timestamptz NOT NULL DEFAULT now(), sent_at timestamptz);
CREATE TABLE IF NOT EXISTS trades (exchange_id text PRIMARY KEY, intent_id text REFERENCES intents(id), realized_return numeric NOT NULL, details jsonb NOT NULL, closed_at timestamptz DEFAULT now());
