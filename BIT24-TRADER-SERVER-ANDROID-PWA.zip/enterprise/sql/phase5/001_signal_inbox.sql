BEGIN;
CREATE TABLE trading_v2."SignalInbox" (
 id uuid PRIMARY KEY,
 payload jsonb NOT NULL CHECK (jsonb_typeof(payload)='object'),
 "createdAt" timestamptz NOT NULL DEFAULT now(),
 "consumedAt" timestamptz
);
CREATE INDEX pending_signals ON trading_v2."SignalInbox"("createdAt") WHERE "consumedAt" IS NULL;
COMMIT;
