-- Apply after phases 1 and 3, once via controlled migration.
BEGIN;
ALTER TABLE trading_v2."RecoveryAlerts" ADD COLUMN "lastEnqueuedAt" timestamptz;
CREATE INDEX pending_notification_relay ON trading_v2."RecoveryAlerts"("lastEnqueuedAt" ASC NULLS FIRST,"createdAt",id)
  WHERE "deliveredAt" IS NULL;
COMMIT;
