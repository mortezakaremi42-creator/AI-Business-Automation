-- Apply AFTER phase1 migration. No replacement of old public tables.
BEGIN;
ALTER TABLE trading_v2."Trades"
  ADD COLUMN "stopLoss" numeric(38,18),
  ADD COLUMN "takeProfit" numeric(38,18),
  ADD COLUMN "buyOrderId" text,
  ADD COLUMN "ocoOrderId" text,
  ADD COLUMN "ocoAttemptedAt" timestamptz,
  ADD COLUMN "dryRun" boolean NOT NULL DEFAULT false,
  ADD COLUMN "simulationCompletedAt" timestamptz;
CREATE TABLE trading_v2."EmergencyExits" (
  "tradeId" uuid PRIMARY KEY REFERENCES trading_v2."Trades"(id) ON DELETE RESTRICT,
  amount numeric(38,18) NOT NULL CHECK (amount>0 AND amount<'Infinity'::numeric),
  status text NOT NULL CHECK(status IN ('SUBMITTING','UNKNOWN','CONFIRMED')),
  "exchangeOrderId" text,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE trading_v2."RecoveryAlerts" (
  id uuid PRIMARY KEY,
  "tradeId" uuid REFERENCES trading_v2."Trades"(id) ON DELETE RESTRICT,
  code varchar(100) NOT NULL,
  "dedupKey" text NOT NULL,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "deliveredAt" timestamptz
);
CREATE UNIQUE INDEX pending_recovery_alert ON trading_v2."RecoveryAlerts"("dedupKey") WHERE "deliveredAt" IS NULL;
-- Allow versioned metadata updates; do not weaken the state transition graph.
CREATE OR REPLACE FUNCTION trading_v2.guard_trade_state() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='INSERT' THEN
    IF NEW.status<>'PENDING_BUY' OR NEW.version<>0 THEN RAISE EXCEPTION 'Invalid initial state'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.id IS DISTINCT FROM OLD.id OR NEW.symbol IS DISTINCT FROM OLD.symbol
     OR NEW.side IS DISTINCT FROM OLD.side OR NEW."createdAt" IS DISTINCT FROM OLD."createdAt"
     OR NEW."dryRun" IS DISTINCT FROM OLD."dryRun" THEN RAISE EXCEPTION 'Immutable identity'; END IF;
  IF NEW.status IS DISTINCT FROM OLD.status AND NOT (
    (OLD.status='PENDING_BUY' AND NEW.status IN ('BUY_UNKNOWN','BOUGHT_NO_OCO','FAILED')) OR
    (OLD.status='BUY_UNKNOWN' AND NEW.status IN ('BOUGHT_NO_OCO','FAILED')) OR
    (OLD.status='BOUGHT_NO_OCO' AND NEW.status='SECURED')
  ) THEN RAISE EXCEPTION 'Invalid transition'; END IF;
  IF NEW.version<>OLD.version+1 THEN RAISE EXCEPTION 'Invalid state version'; END IF;
  NEW."updatedAt":=clock_timestamp();
  RETURN NEW;
END;
$$;
COMMIT;
