-- Phase 1 only. Apply once through your migration runner, not automatically at worker startup.
-- Isolated from the legacy public.trades / intents schema.
BEGIN;
CREATE SCHEMA trading_v2;
CREATE TYPE trading_v2."TradeSide" AS ENUM ('BUY', 'SELL');
CREATE TYPE trading_v2."OrderStates" AS ENUM (
  'PENDING_BUY', 'BUY_UNKNOWN', 'BOUGHT_NO_OCO', 'SECURED', 'FAILED'
);
CREATE TYPE trading_v2."LogLevel" AS ENUM ('INFO', 'WARN', 'ERROR');

CREATE TABLE trading_v2."Trades" (
  id uuid PRIMARY KEY, -- generated with node:crypto.randomUUID()
  symbol varchar(64) NOT NULL CHECK (length(trim(symbol)) > 0),
  side trading_v2."TradeSide" NOT NULL,
  "entryPrice" numeric(38,18) NOT NULL CHECK ("entryPrice" > 0 AND "entryPrice" < 'Infinity'::numeric),
  amount numeric(38,18) NOT NULL CHECK (amount > 0 AND amount < 'Infinity'::numeric),
  status trading_v2."OrderStates" NOT NULL DEFAULT 'PENDING_BUY',
  version integer NOT NULL DEFAULT 0 CHECK (version >= 0),
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX trades_status_updated ON trading_v2."Trades" (status, "updatedAt");
CREATE INDEX trades_symbol_created ON trading_v2."Trades" (symbol, "createdAt" DESC);

CREATE TABLE trading_v2."SystemLogs" (
  id uuid PRIMARY KEY,
  "tradeId" uuid REFERENCES trading_v2."Trades"(id) ON DELETE RESTRICT,
  level trading_v2."LogLevel" NOT NULL,
  event varchar(80) NOT NULL,
  message varchar(2000) NOT NULL,
  -- Only allowlisted, sanitized metadata: never raw headers, credentials or response bodies.
  context jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(context) = 'object'),
  "createdAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX logs_trade_created ON trading_v2."SystemLogs" ("tradeId", "createdAt" DESC);
CREATE INDEX logs_level_created ON trading_v2."SystemLogs" (level, "createdAt" DESC);

-- Defense in depth for writes that bypass the TypeScript service.
CREATE FUNCTION trading_v2.guard_trade_state() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'PENDING_BUY' OR NEW.version <> 0 THEN
      RAISE EXCEPTION 'New trades must start PENDING_BUY at version 0';
    END IF;
    RETURN NEW;
  END IF;
  IF NEW.id IS DISTINCT FROM OLD.id OR NEW.symbol IS DISTINCT FROM OLD.symbol
     OR NEW.side IS DISTINCT FROM OLD.side OR NEW."createdAt" IS DISTINCT FROM OLD."createdAt" THEN
    RAISE EXCEPTION 'Trade identity is immutable';
  END IF;
  IF NOT (
    (OLD.status = 'PENDING_BUY' AND NEW.status IN ('BUY_UNKNOWN','BOUGHT_NO_OCO','FAILED')) OR
    (OLD.status = 'BUY_UNKNOWN' AND NEW.status IN ('BOUGHT_NO_OCO','FAILED')) OR
    (OLD.status = 'BOUGHT_NO_OCO' AND NEW.status = 'SECURED')
  ) THEN
    RAISE EXCEPTION 'Illegal order transition: % -> %', OLD.status, NEW.status;
  END IF;
  IF NEW.version <> OLD.version + 1 THEN
    RAISE EXCEPTION 'State version must increment by one';
  END IF;
  NEW."updatedAt" := clock_timestamp();
  RETURN NEW;
END;
$$;
CREATE TRIGGER enforce_trade_state BEFORE INSERT OR UPDATE ON trading_v2."Trades"
  FOR EACH ROW EXECUTE FUNCTION trading_v2.guard_trade_state();
COMMIT;
