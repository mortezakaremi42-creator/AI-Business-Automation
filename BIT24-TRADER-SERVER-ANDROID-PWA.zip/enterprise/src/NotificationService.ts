import { totalmem, freemem } from 'node:os';
import { AbortController as TelegramAbortController } from 'abort-controller';
import { Telegraf } from 'telegraf';
import { Queue, Worker, type ConnectionOptions } from 'bullmq';

export const HEARTBEAT_INTERVAL_MS = 15 * 60 * 1000;
export const NOTIFICATION_QUEUE = 'bit24-notifications-v1';
export const DELIVERY_OPTIONS = Object.freeze({
  attempts: 12,
  backoff: {type:'telegram-retry',delay:2000},
  removeOnComplete: {age:7*24*3600,count:10000},
  removeOnFail: false,
});
export interface HeartbeatSnapshot {
  mode: 'DRY_RUN' | 'LIVE' | 'UNKNOWN';
  balances: Readonly<Record<string,string>> | null;
  openPositions: number | null;
  observedAt: Date | null;
}
export interface StatusProvider { getSnapshot(signal: AbortSignal): Promise<HeartbeatSnapshot> }
export interface PendingAlert { id: string; tradeId: string | null; code: string }
export type CriticalAlert =
  | { type:'BOUGHT_NO_OCO'; tradeId: string }
  | { type:'EXCHANGE_API_DOWN' };
export interface NotificationOutbox {
  recordCritical(alert: CriticalAlert): Promise<void>;
  listPending(limit: number): Promise<PendingAlert[]>;
  getPending(id: string): Promise<PendingAlert | null>;
  noteQueued(id: string): Promise<void>;
  markDelivered(id: string): Promise<void>;
}
export interface TelegramSender { send(text: string): Promise<void> }
export class NotificationDeliveryError extends Error {
  constructor(readonly retryAfterMs = 0) { super('TELEGRAM_DELIVERY_FAILED'); this.name='NotificationDeliveryError'; }
}
// No bot token, raw API error description, response, chat ID or URL enters job data/error logs.
function sanitizedDeliveryError(error: unknown): NotificationDeliveryError {
  const response=(error as {response?:{parameters?:{retry_after?:unknown}}}|null)?.response;
  const seconds=response?.parameters?.retry_after;
  return new NotificationDeliveryError(typeof seconds==='number' && Number.isFinite(seconds) && seconds>0 ? seconds*1000 : 0);
}
export function notificationBackoff(attempts: number, error?: Error): number {
  const exponential=Math.min(30*60_000,2000*2**Math.min(Math.max(attempts-1,0),10));
  return Math.max(exponential,error instanceof NotificationDeliveryError?error.retryAfterMs:0);
}
export function createTelegrafSender(token: string, chatId: string): TelegramSender {
  if(!token || !chatId)throw Error('TELEGRAM_CONFIGURATION_REQUIRED');
  const bot=new Telegraf(token,{telegram:{webhookReply:false}});
  // Outbound only: no launch()/long-polling, no public trading/withdrawal commands.
  return {send:async text=>{
    const controller=new TelegramAbortController();const timer=setTimeout(()=>controller.abort(),10_000);
    try {
      await bot.telegram.callApi('sendMessage',{chat_id:chatId,text,protect_content:true},{signal:controller.signal});
    } catch(error) {throw sanitizedDeliveryError(error);}
    finally{clearTimeout(timer);}
  }};
}
export function formatHeartbeat(snapshot: HeartbeatSnapshot | null, now = new Date()): string {
  const balances=Object.entries(snapshot?.balances??{}).filter(([asset,value])=>
    /^[A-Z0-9_-]{1,24}$/.test(asset) && typeof value==='string' && /^\d{1,30}(\.\d{1,18})?$/.test(value)).slice(0,12);
  const memory=process.memoryUsage();const mb=(bytes:number)=>(bytes/1024/1024).toFixed(1);
  const open=snapshot?.openPositions;
  const observed=snapshot?.observedAt;
  return [
    '💚 من زنده‌ام — Bit24 AI Trader Pro',
    `حالت: ${['LIVE','DRY_RUN'].includes(snapshot?.mode??'')?snapshot!.mode:'UNKNOWN'}`,
    `موجودی تأییدشده: ${balances.length?balances.map(([a,v])=>`${a}: ${v}`).join(' | '):'نامشخص'}`,
    `پوزیشن‌های باز: ${typeof open==='number'&&Number.isSafeInteger(open)&&open>=0?open:'نامشخص'}`,
    `زمان آخرین تأیید وضعیت: ${observed instanceof Date && Number.isFinite(observed.getTime())?observed.toISOString():'نامشخص'}`,
    `RAM پردازش (RSS): ${mb(memory.rss)} MB`,
    `Heap مصرفی: ${mb(memory.heapUsed)} MB`,
    `RAM میزبان: ${mb(totalmem()-freemem())} / ${mb(totalmem())} MB`,
    `زمان گزارش: ${now.toISOString()}`,
  ].join('\n');
}
export function formatCritical(alert: PendingAlert): string {
  const explanations:Record<string,string>={
    BOUGHT_NO_OCO:'خرید تأیید شده اما حفاظت OCO هنوز تأیید نشده است؛ بررسی فوری لازم است.',
    EXCHANGE_API_DOWN:'قطع کامل API صرافی گزارش شده است؛ وضعیت سفارش‌ها نیاز به تطبیق دارد.',
    CRITICAL_UNPROTECTED_POSITION:'پوزیشن بدون حفاظت تأیید شده؛ قصد خروج اضطراری ثبت شده است.',
    CRITICAL_EMERGENCY_SELL_UNKNOWN_DO_NOT_RETRY:'نتیجه فروش اضطراری نامعلوم است؛ فروش را بدون تطبیق تکرار نکنید.',
    CRITICAL_EMERGENCY_SELL_SUBMITTED_AWAITING_FILL:'فروش اضطراری ارسال شده؛ انجام کامل آن هنوز تأیید نشده است.',
    BUY_OR_PROTECTION_UNKNOWN:'وضعیت خرید یا حفاظت نامعلوم است.',
    EMERGENCY_EXIT_RESULT_UNKNOWN:'نتیجه خروج اضطراری هنوز مشخص نیست.',
    ENGINE_PAUSED_RECONCILIATION_REQUIRED:'موتور متوقف شده و به تطبیق وضعیت نیاز دارد.',
    RECONCILIATION_FAILED_TRADING_HALTED:'بازیابی ناموفق بود؛ معامله جدید متوقف است.',
    LIVE_RECOVERY_BLOCKED_IN_DRY_RUN:'سفارش واقعی حل‌نشده در حالت Dry-Run شناسایی شده است.',
  };
  const trade=alert.tradeId && /^[0-9a-f-]{36}$/i.test(alert.tradeId)?`\nشناسه معامله: ${alert.tradeId}`:'';
  return `🔴 هشدار فوری — Bit24 AI Trader Pro\n${explanations[alert.code]??'یک رویداد عملیاتی نیازمند بررسی ثبت شده است.'}${trade}`;
}
export interface NotificationJob { name: string; data: {outboxId?: string} }
export function createNotificationProcessor(deps: {outbox: NotificationOutbox; status: StatusProvider; sender: TelegramSender}) {
  return async (job: NotificationJob): Promise<void>=>{
    try {
      if(job.name==='critical') {
        if(!job.data.outboxId || !/^[0-9a-f-]{36}$/i.test(job.data.outboxId))throw Error('INVALID_JOB');
        const alert=await deps.outbox.getPending(job.data.outboxId);
        if(!alert)return; // Already delivered (possible replay/stalled job).
        await deps.sender.send(formatCritical(alert));
        await deps.outbox.markDelivered(alert.id); // Never mark after enqueue or failed send.
      } else if(job.name==='heartbeat') {
        const controller=new AbortController();let timer:ReturnType<typeof setTimeout>|undefined;
        let snapshot:HeartbeatSnapshot|null=null;
        try {
          snapshot=await Promise.race([
            deps.status.getSnapshot(controller.signal),
            new Promise<never>((_resolve,reject)=>{timer=setTimeout(()=>{controller.abort();reject(Error('SNAPSHOT_TIMEOUT'))},5000)}),
          ]);
        } catch { /* Send liveness with explicit UNKNOWN instead of inventing balances. */ }
        finally {if(timer)clearTimeout(timer);}
        await deps.sender.send(formatHeartbeat(snapshot));
      } else throw Error('INVALID_JOB');
    }catch(error){
      if(error instanceof NotificationDeliveryError)throw error;
      // BullMQ stores error messages; deliberately strip all arbitrary messages/stacks.
      throw sanitizedDeliveryError(error);
    }
  };
}
export function redisNotificationConnection(url: string, worker = false): ConnectionOptions {
  const parsed=new URL(url);
  if(!['redis:','rediss:'].includes(parsed.protocol))throw Error('INVALID_REDIS_URL');
  const db=Number(parsed.pathname.slice(1)||0);
  if(!Number.isSafeInteger(db)||db<0)throw Error('INVALID_REDIS_DB');
  return {host:parsed.hostname,port:parsed.port?Number(parsed.port):6379,
    ...(parsed.username?{username:decodeURIComponent(parsed.username)}:{}),
    ...(parsed.password?{password:decodeURIComponent(parsed.password)}:{}),
    ...(parsed.protocol==='rediss:'?{tls:{}}:{}),db,
    connectTimeout:5000,maxRetriesPerRequest:worker?null:1,enableOfflineQueue:worker,
    ...(worker?{}:{commandTimeout:5000}),
  };
}
export interface NotificationServiceOptions {
  redisUrl: string; botToken: string; chatId: string;
  outbox: NotificationOutbox; status: StatusProvider;
  // Must accept safe constant codes only. Never forward raw BullMQ/Telegraf errors.
  onDiagnostic?: (code: string)=>void;
}
export class NotificationService {
  private readonly queue: Queue;
  private readonly worker: Worker;
  private timer: ReturnType<typeof setInterval> | null=null;
  private relayTask: Promise<void> | null=null;
  private started=false;
  constructor(private readonly options: NotificationServiceOptions) {
    const report=(code:string)=>{try{options.onDiagnostic?.(code)}catch{/* monitoring must not crash Worker */}};
    const sender=createTelegrafSender(options.botToken,options.chatId);
    this.queue=new Queue(NOTIFICATION_QUEUE,{connection:redisNotificationConnection(options.redisUrl)});
    this.worker=new Worker(NOTIFICATION_QUEUE,createNotificationProcessor({outbox:options.outbox,status:options.status,
      sender}),{
      autorun:false,connection:redisNotificationConnection(options.redisUrl,true),concurrency:1,
      limiter:{max:1,duration:1100},settings:{backoffStrategy:(attempts,_type,error)=>notificationBackoff(attempts,error)},
    });
    this.queue.on('error',()=>report('NOTIFICATION_QUEUE_UNAVAILABLE'));
    this.worker.on('error',()=>report('NOTIFICATION_WORKER_UNAVAILABLE'));
    this.worker.on('failed',job=>report(job && job.attemptsMade >= (job.opts.attempts??1)?'NOTIFICATION_RETRIES_EXHAUSTED':'NOTIFICATION_RETRY_SCHEDULED'));
  }
  async start(): Promise<void> {
    if(this.started)throw Error('NOTIFICATIONS_ALREADY_STARTED');
    this.started=true;
    try {
      await this.queue.waitUntilReady();
      await this.queue.upsertJobScheduler('heartbeat-15-minutes',{every:HEARTBEAT_INTERVAL_MS},
        {name:'heartbeat',data:{},opts:{...DELIVERY_OPTIONS,priority:10}});
      void this.worker.run().catch(()=>this.diagnostic('NOTIFICATION_WORKER_STOPPED'));
      this.timer=setInterval(()=>{void this.relayPending().catch(()=>this.diagnostic('NOTIFICATION_OUTBOX_RELAY_FAILED'))},1000);
      await this.relayPending();
    }catch(error){await this.close();throw Error('NOTIFICATION_STARTUP_FAILED');}
  }
  async health(): Promise<{running: boolean; failedJobs: number}> {
    const counts=await this.queue.getJobCounts('failed');
    return {running:this.started&&this.worker.isRunning(),failedJobs:counts.failed??0};
  }
  async sendHeartbeat(): Promise<void> {
    await this.queue.add('heartbeat',{}, {...DELIVERY_OPTIONS,priority:10,
      jobId:`heartbeat-${Math.floor(Date.now()/HEARTBEAT_INTERVAL_MS)}`});
  }
  async sendCriticalAlert(alert: CriticalAlert): Promise<void> {
    await persistCriticalAlert(this.options.outbox,alert);
  }
  relayPending(): Promise<void> {
    if(this.relayTask)return this.relayTask;
    this.relayTask=relayNotificationBatch(this.options.outbox,this.queue).finally(()=>{this.relayTask=null});
    return this.relayTask;
  }
  private diagnostic(code:string){try{this.options.onDiagnostic?.(code)}catch{/* safe */}}
  async close(): Promise<void> {
    if(this.timer)clearInterval(this.timer);this.timer=null;
    if(this.relayTask)await this.relayTask.catch(()=>{});
    await this.worker.close();await this.queue.close();this.started=false;
  }
}

export async function persistCriticalAlert(outbox: NotificationOutbox, alert: CriticalAlert): Promise<void> {
  // Trading path waits only for durable DB persistence, never Telegram/Redis delivery.
  if(!alert || !['BOUGHT_NO_OCO','EXCHANGE_API_DOWN'].includes(alert.type))throw Error('INVALID_ALERT_TYPE');
  if(alert.type==='BOUGHT_NO_OCO' && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(alert.tradeId))throw Error('INVALID_TRADE_ID');
  await outbox.recordCritical(alert);
}
export async function relayNotificationBatch(outbox: NotificationOutbox, queue: Pick<Queue,'add'>): Promise<void> {
  const pending=await outbox.listPending(100);
  for(const alert of pending) {
    await queue.add('critical',{outboxId:alert.id},{...DELIVERY_OPTIONS,priority:1,jobId:`recovery-${alert.id}`});
    // Failed jobs remain for operator review; dedup add never blindly resets retry counters.
    await outbox.noteQueued(alert.id);
  }
}
