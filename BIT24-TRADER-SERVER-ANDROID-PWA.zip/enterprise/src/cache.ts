import type { createClient } from 'redis';
import { TransientError } from './retry.js';
type Redis = ReturnType<typeof createClient>;
export class ApiCache {
  constructor(private redis: Redis) {}
  async read<T>(endpoint: string, load: () => Promise<T>, ttlMs = 1000, identity = endpoint): Promise<T> {
    const key = 'bit24:read:'+identity;
    const cached = await this.redis.get(key); if (cached) return JSON.parse(cached) as T;
    // Atomic shared rate limit; scope is per endpoint, as in Bit24 API documentation.
    const count = Number(await this.redis.eval("local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('PEXPIRE',KEYS[1],60000) end; return n",{keys:['bit24:rate:'+endpoint],arguments:[]}));
    if (count > 230) throw new TransientError('RATE_LIMIT');
    // Redis failure must propagate: never bypass the rate guard.
    const value = await load(); await this.redis.set(key,JSON.stringify(value),{PX:ttlMs});return value;
  }
}
