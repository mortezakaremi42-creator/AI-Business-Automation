// Match the PostgreSQL enum exactly. No binary float for persisted money.
export const OrderStates = {
  PENDING_BUY: 'PENDING_BUY',
  BUY_UNKNOWN: 'BUY_UNKNOWN',
  BOUGHT_NO_OCO: 'BOUGHT_NO_OCO',
  SECURED: 'SECURED',
  FAILED: 'FAILED',
} as const;
export type OrderState = typeof OrderStates[keyof typeof OrderStates];
export type TradeSide = 'BUY' | 'SELL';
export type DecimalString = string;
export interface Trade {
  id: string;
  symbol: string;
  side: TradeSide;
  entryPrice: DecimalString;
  amount: DecimalString;
  status: OrderState;
  version: number;
  createdAt: Date;
  updatedAt: Date;
}
export interface SystemLog {
  id: string;
  tradeId: string | null;
  level: 'INFO' | 'WARN' | 'ERROR';
  event: string;
  message: string;
  context: Record<string, unknown>;
  createdAt: Date;
}
