import { randomUUID } from 'node:crypto';
import type { Pool } from 'pg';
export interface ApiDiagnostic {
  tradeId?: string;
  event: 'NETWORK_ERROR' | 'API_RESPONSE';
  operation: 'READ_BALANCE' | 'READ_ORDER' | 'BUY' | 'OCO' | 'RECONCILE';
  httpStatus?: number;
  durationMs?: number;
  outcome: 'SUCCESS' | 'TIMEOUT' | 'REJECTED' | 'NETWORK_FAILURE' | 'UNKNOWN';
}
export class SystemLogRepository {
  constructor(private readonly pool: Pool) {}
  async api(d: ApiDiagnostic): Promise<void> {
    // Explicit allowlist, never log response text, tokens, URLs with queries or Error.stack.
    const context = {operation:d.operation, outcome:d.outcome,
      ...(Number.isInteger(d.httpStatus) && d.httpStatus! >= 100 && d.httpStatus! <= 599 ? {httpStatus:d.httpStatus} : {}),
      ...(Number.isFinite(d.durationMs) && d.durationMs! >= 0 ? {durationMs:d.durationMs} : {})};
    await this.pool.query(`INSERT INTO trading_v2."SystemLogs"(id,"tradeId",level,event,message,context)
      VALUES($1,$2,$3,$4,'API diagnostic',$5)`,
      [randomUUID(),d.tradeId??null,d.outcome==='SUCCESS'?'INFO':'ERROR',d.event,JSON.stringify(context)]);
  }
}
