import { OrderStates as S, type OrderState } from './types.js';
export const TRANSITIONS: Readonly<Record<OrderState, readonly OrderState[]>> = Object.freeze({
  [S.PENDING_BUY]: Object.freeze([S.BUY_UNKNOWN, S.BOUGHT_NO_OCO, S.FAILED]),
  [S.BUY_UNKNOWN]: Object.freeze([S.BOUGHT_NO_OCO, S.FAILED]),
  [S.BOUGHT_NO_OCO]: Object.freeze([S.SECURED]),
  [S.SECURED]: Object.freeze([]),
  [S.FAILED]: Object.freeze([]),
});
export type Evidence =
  | { kind: 'SUBMISSION_UNCERTAIN' }
  | { kind: 'BUY_FILL_CONFIRMED'; exchangeOrderId: string }
  | { kind: 'NO_EXECUTION_CONFIRMED'; source: 'LOCAL_PRE_SUBMIT' | 'EXCHANGE_REJECTION' | 'RECONCILIATION' }
  | { kind: 'OCO_CONFIRMED'; exchangeProtectionId: string };
export class InvalidOrderTransition extends Error {
  constructor(from: OrderState, to: OrderState) {
    super(`Illegal order transition: ${from} -> ${to}`);
    this.name = 'InvalidOrderTransition';
  }
}
// Pure, immutable, no I/O. Evidence must come from a trusted exchange/reconciliation adapter.
export class OrderStateMachine {
  constructor(readonly state: OrderState = S.PENDING_BUY) {
    if (!Object.hasOwn(TRANSITIONS, state)) throw Error('INVALID_ORDER_STATE');
  }
  canTransition(to: OrderState): boolean { return TRANSITIONS[this.state].includes(to); }
  transition(to: OrderState, evidence: Evidence): OrderStateMachine {
    if (!this.canTransition(to)) throw new InvalidOrderTransition(this.state, to);
    let valid = false;
    if (to === S.BUY_UNKNOWN) valid = evidence.kind === 'SUBMISSION_UNCERTAIN';
    if (to === S.BOUGHT_NO_OCO) valid = evidence.kind === 'BUY_FILL_CONFIRMED' && !!evidence.exchangeOrderId.trim();
    if (to === S.SECURED) valid = evidence.kind === 'OCO_CONFIRMED' && !!evidence.exchangeProtectionId.trim();
    if (to === S.FAILED) valid = evidence.kind === 'NO_EXECUTION_CONFIRMED' &&
      (this.state !== S.BUY_UNKNOWN || evidence.source === 'RECONCILIATION');
    if (!valid) throw Error('TRANSITION_EVIDENCE_REQUIRED');
    return new OrderStateMachine(to);
  }
}
