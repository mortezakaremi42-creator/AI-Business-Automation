import { randomUUID } from 'node:crypto';
import type { Pool } from 'pg';
import { OrderStateMachine, type Evidence } from './OrderStateMachine.js';
import type { OrderState, Trade } from './types.js';
export class StateConflict extends Error {
  constructor() { super('ORDER_STATE_CONFLICT: reload and reconcile; do not resubmit the order'); }
}
// All state mutation + audit in one transaction. No exchange calls inside a DB transaction.
export class OrderStateRepository {
  constructor(private readonly pool: Pool) {}
  async transition(input: {id: string; expectedState: OrderState; expectedVersion: number; to: OrderState; evidence: Evidence}): Promise<Trade> {
    new OrderStateMachine(input.expectedState).transition(input.to, input.evidence);
    const c = await this.pool.connect();
    try {
      await c.query('BEGIN');
      const result = await c.query<Trade>(
        `UPDATE trading_v2."Trades" SET status=$4,version=version+1
         WHERE id=$1 AND status=$2 AND version=$3 RETURNING *`,
        [input.id,input.expectedState,input.expectedVersion,input.to]);
      if (result.rowCount !== 1) throw new StateConflict();
      // Log safe evidence category, not an arbitrary exchange payload.
      await c.query(`INSERT INTO trading_v2."SystemLogs"(id,"tradeId",level,event,message,context)
        VALUES($1,$2,$3,'ORDER_TRANSITION','Order state changed',$4)`,
        [randomUUID(),input.id,input.to==='BOUGHT_NO_OCO'?'ERROR':'INFO',JSON.stringify({from:input.expectedState,to:input.to,evidenceKind:input.evidence.kind,version:result.rows[0].version})]);
      await c.query('COMMIT');
      return result.rows[0];
    } catch (e) { await c.query('ROLLBACK'); throw e; }
    finally { c.release(); }
  }
}
