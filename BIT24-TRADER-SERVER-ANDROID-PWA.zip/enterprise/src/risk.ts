export interface Signal { id: string; symbol: string; rsi: number; price: number; stop: number; take: number; quantity: number; balance: number; exposure: number; spreadBps: number; timestamp: number }
export function validate(s: Signal, now = Date.now()) {
  if (!/^[A-Z0-9]+\/[A-Z0-9]+$/.test(s.symbol) || !s.id || s.id.length > 128) throw Error('INVALID_SIGNAL');
  for (const k of ['rsi','price','stop','take','quantity','balance','exposure','spreadBps','timestamp'] as const)
    if (!Number.isFinite(s[k])) throw Error('INVALID_NUMBER');
  if (s.rsi < 0 || s.rsi >= 75) throw Error('FOMO_RSI_BLOCK');
  if (now - s.timestamp > 5000 || s.timestamp > now + 1000) throw Error('STALE_SIGNAL');
  if (!(s.stop > 0 && s.stop < s.price && s.take > s.price && s.quantity > 0 && s.balance > 0 && s.exposure >= 0)) throw Error('INVALID_RISK');
  if (s.spreadBps < 0 || s.spreadBps > 50) throw Error('SPREAD_BLOCK');
  if ((s.price - s.stop) * s.quantity > s.balance * .01) throw Error('RISK_BUDGET');
  if (s.exposure + s.price * s.quantity > s.balance * .2) throw Error('EXPOSURE_LIMIT');
}
