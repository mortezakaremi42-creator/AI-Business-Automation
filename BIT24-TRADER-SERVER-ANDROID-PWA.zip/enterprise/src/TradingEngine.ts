import type { RiskManager } from './RiskManager.js';
import { RiskRejectionError } from './RiskManager.js';
import { Reconciler, isPositiveDecimal } from './Reconciler.js';
import type { TradingSignal, TradingStore, TradingExchange } from './TradingContracts.js';
export interface SignalSource { next(signal: AbortSignal): Promise<TradingSignal | null>; ack?(id: string): Promise<void> }
export interface EngineOptions {
  intervalMs?: number; maxOpenPositions?: number;
  wait?: (ms: number, signal: AbortSignal) => Promise<void>;
}
export function abortableWait(ms: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.resolve();
  return new Promise(resolve=>{
    const done=()=>{clearTimeout(timer);signal.removeEventListener('abort',done);resolve()};
    const timer=setTimeout(done,ms);signal.addEventListener('abort',done,{once:true});
  });
}
export class TradingEngine {
  private running = false;
  private currentStatus = {phase:'STOPPED',lastIterationAt:null as number|null};
  get status() { return {...this.currentStatus}; }
  private readonly interval: number;
  private readonly max: number;
  private readonly wait: (ms: number, signal: AbortSignal)=>Promise<void>;
  constructor(private readonly store: TradingStore, private readonly exchange: TradingExchange,
    private readonly risk: Pick<RiskManager,'validateSignal'>, private readonly source: SignalSource,
    private readonly reconciler: Pick<Reconciler,'reconcileOnStartup'>, options: EngineOptions = {}) {
    this.interval=options.intervalMs??1000;this.max=options.maxOpenPositions??3;this.wait=options.wait??abortableWait;
    if (!Number.isSafeInteger(this.max)||this.max<1||!Number.isFinite(this.interval)||this.interval<1)throw Error('INVALID_ENGINE_OPTIONS');
  }
  async run(signal: AbortSignal): Promise<void> {
    if (this.running) throw Error('ENGINE_ALREADY_RUNNING');
    if (signal.aborted) return;
    this.running=true;this.currentStatus.phase='STARTING';
    let owned=false,failures=0;
    try {
      await this.store.acquireLeadership();owned=true;
      while (!signal.aborted) {
        try {
          this.currentStatus={phase:'RECOVERING',lastIterationAt:Date.now()};
          await this.store.assertOwnership();
          // Startup AND every iteration: unresolved exposure always takes priority over new signals.
          const recovery=await this.reconciler.reconcileOnStartup();
          if (!recovery.ready) throw Error('RECOVERY_NOT_READY');
          this.currentStatus.phase='RUNNING';
          if (signal.aborted) break;
          const next=await this.source.next(signal);
          if (next && !signal.aborted) { await this.processSignal(next,signal); await this.source.ack?.(next.id); }
          failures=0;
          await this.wait(this.interval,signal);
        } catch {
          this.currentStatus.phase='PAUSED';
          if (signal.aborted) break;
          // Missing DB/network never falls through to a new buy. Alerts must not kill retry loop.
          try { await this.store.alert(null,'ENGINE_PAUSED_RECONCILIATION_REQUIRED'); } catch { /* external watchdog required when DB is down */ }
          const delay=Math.min(30_000,2000*2**Math.min(failures++,4));
          await this.wait(delay,signal);
        }
      }
    } finally {
      try { if(owned)await this.store.releaseLeadership(); }
      finally {this.running=false;this.currentStatus.phase='STOPPED';}
    }
  }
  private async processSignal(s: TradingSignal, abort: AbortSignal) {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s.id) ||
      !/^[A-Z0-9]{1,24}$/.test(s.baseCoin) || !/^[A-Z0-9]{1,24}$/.test(s.quoteCoin) || s.baseCoin===s.quoteCoin ||
      ![s.amount,s.entryPrice,s.stopLoss,s.takeProfit].every(isPositiveDecimal) ||
      !Number.isFinite(s.timestamp) || Date.now()-s.timestamp>5000 || s.timestamp>Date.now()+1000) {
      await this.store.alert(null,'INVALID_OR_STALE_SIGNAL_REJECTED');return;
    }
    const decimal=(v:string)=>{const [a,b='']=v.split('.');return BigInt(a)*10n**18n+BigInt(b.padEnd(18,'0'))};
    if (!(decimal(s.stopLoss)<decimal(s.entryPrice) && decimal(s.entryPrice)<decimal(s.takeProfit))) {
      await this.store.alert(null,'INVALID_PROTECTION_PRICES');return;
    }
    try { await this.risk.validateSignal(s); }
    catch(error) {
      if(error instanceof RiskRejectionError && ['REJECTED_RSI_TOO_HIGH','REJECTED_MAX_OPEN_POSITIONS','REJECTED_INVALID_SIGNAL'].includes(error.code))return;
      throw error;
    }
    if (abort.aborted) return;
    const dry=this.exchange.executionMode==='DRY_RUN';
    if(!dry)this.exchange.assertConfiguredForLiveTrading();
    let trade=await this.store.reserve(s,dry,this.max);
    if (!trade) return; // signal already seen, symbol active, or capacity exhausted
    await this.store.assertOwnership();
    if (dry) {
      const buy=await this.exchange.placeMarketBuy(s);
      if(buy.mode!=='DRY_RUN')throw Error('MODE_MISMATCH');
      const protection=await this.exchange.placeOCO(s);
      if(protection.mode!=='DRY_RUN')throw Error('MODE_MISMATCH');
      await this.store.completeSimulation(trade.id);
      return;
    }
    // Pre-write ambiguity marker survives a crash even before HTTP response or ACK persistence.
    trade=await this.store.transition(trade,'BUY_UNKNOWN');
    await this.store.assertOwnership();
    if(abort.aborted)return;
    const receipt=await this.exchange.placeMarketBuy(s); // no retry inside this method
    if(receipt.mode!=='LIVE'||receipt.operation!=='MARKET_BUY')throw Error('INVALID_BUY_RECEIPT');
    await this.store.saveBuyAck(trade.id,receipt.exchangeOrderId);
    // Confirm actual terminal fill before protecting its NET quantity. ACK is not fill.
    trade=await this.store.get(trade.id);
    const fact=await this.exchange.inspectTrade(trade);
    if(fact.kind==='UNPROTECTED' && fact.safeToSell===true && isPositiveDecimal(fact.amount) && isPositiveDecimal(fact.entryPrice) && fact.buyOrderId.trim()) {
      trade=await this.store.confirmBuy(trade,fact);
      await this.store.markOcoAttempted(trade.id);
      await this.store.assertOwnership();
      const oco=await this.exchange.placeOCO({...s,amount:fact.amount});
      if(oco.mode!=='LIVE'||oco.operation!=='OCO')throw Error('INVALID_OCO_RECEIPT');
      await this.store.saveOcoAck(trade.id,oco.exchangeOrderId);
    }
    // Any OCO timeout/error escapes to the loop; next recovery checks protection before selling.
    const report=await this.reconciler.reconcileOnStartup();
    if(!report.ready)throw Error('BUY_REQUIRES_RECONCILIATION');
  }
}
