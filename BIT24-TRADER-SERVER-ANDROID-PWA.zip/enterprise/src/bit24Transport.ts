import { createHmac } from 'node:crypto';
import { ApiCache } from './cache.js';
import { retryRead, TransientError } from './retry.js';
const READS = new Set(['/asset/capi/v1/wallet/assets','/pro/capi/v2/spot-orders','/pro/capi/v2/margin-orders/positions']);
// Only the certified adapter may call writes. This transport never retries POST.
const WRITES = new Set(['/pro/capi/v2/spot-orders/submit']);
export class Bit24Transport {
  constructor(private cache: ApiCache, private apiKey: string, private secret: string) {}
  private async request(method:'GET'|'POST',path:string,fields:Record<string,string>={}) {
    if (!(method==='GET'?READS:WRITES).has(path)) throw Error('ENDPOINT_FORBIDDEN');
    const form=new URLSearchParams(fields);
    if(method==='POST')form.set('signature',createHmac('sha256',this.secret).update(form.toString()).digest('hex'));
    const url=new URL(path,'https://rest.bit24.cash');
    if(method==='GET')url.search=form.toString();
    let response:Response;
    try {
      response=await fetch(url,{method,headers:{'X-BIT24-APIKEY':this.apiKey,...(method==='POST'?{'Content-Type':'application/x-www-form-urlencoded'}:{})},body:method==='POST'?form.toString():undefined,signal:AbortSignal.timeout(10_000),redirect:'error'});
    }catch {throw new TransientError(method==='POST'?'UNKNOWN_WRITE_RESULT':'NETWORK_FAILURE')}
    if(response.status===429 || response.status>=500)throw new TransientError('EXCHANGE_UNAVAILABLE');
    if(!response.ok)throw Error(`EXCHANGE_HTTP_${response.status}`);
    // HTTP success is NOT order acceptance; certified adapter must validate exchange envelope.
    return response.json() as Promise<unknown>;
  }
  read(path:string,fields:Record<string,string>={}) {
    if(!READS.has(path))throw Error('ENDPOINT_FORBIDDEN');
    return retryRead(()=>this.cache.read(path,()=>this.request('GET',path,fields),1000,path+'?'+new URLSearchParams(Object.entries(fields).sort()).toString()));
  }
}
