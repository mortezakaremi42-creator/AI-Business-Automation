import { randomUUID } from 'node:crypto';
import type { Pool } from 'pg';
import type { CriticalAlert, NotificationOutbox, PendingAlert } from './NotificationService.js';
export class PgNotificationOutbox implements NotificationOutbox {
  constructor(private readonly pool: Pool) {}
  async recordCritical(alert: CriticalAlert): Promise<void> {
    const tradeId=alert.type==='BOUGHT_NO_OCO'?alert.tradeId:null;
    await this.pool.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey")
      VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`,
      [randomUUID(),tradeId,alert.type,(tradeId??'system')+':'+alert.type]);
  }
  async listPending(limit:number):Promise<PendingAlert[]> {
    if(!Number.isSafeInteger(limit)||limit<1||limit>1000)throw Error('INVALID_BATCH');
    const r=await this.pool.query<PendingAlert>(`SELECT id,"tradeId",code FROM trading_v2."RecoveryAlerts"
      WHERE "deliveredAt" IS NULL ORDER BY "lastEnqueuedAt" ASC NULLS FIRST,"createdAt",id LIMIT $1`,[limit]);return r.rows;
  }
  async getPending(id:string):Promise<PendingAlert|null> {
    const r=await this.pool.query<PendingAlert>('SELECT id,"tradeId",code FROM trading_v2."RecoveryAlerts" WHERE id=$1 AND "deliveredAt" IS NULL',[id]);return r.rows[0]??null;
  }
  async noteQueued(id:string):Promise<void> {
    await this.pool.query('UPDATE trading_v2."RecoveryAlerts" SET "lastEnqueuedAt"=now() WHERE id=$1 AND "deliveredAt" IS NULL',[id]);
  }
  async markDelivered(id:string):Promise<void> {
    await this.pool.query('UPDATE trading_v2."RecoveryAlerts" SET "deliveredAt"=now() WHERE id=$1 AND "deliveredAt" IS NULL',[id]);
  }
}
