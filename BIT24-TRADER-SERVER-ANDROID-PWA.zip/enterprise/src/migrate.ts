import 'dotenv/config';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Pool} from 'pg';
if(!process.env.DATABASE_URL){console.error('DATABASE_URL_REQUIRED');process.exit(1)}
const files=['phase1/001_order_state_machine.sql','phase3/001_recovery_journal.sql','phase4/001_notification_outbox.sql','phase5/001_signal_inbox.sql'];
const pool=new Pool({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:5000,query_timeout:30_000});
pool.on('error',()=>console.error('MIGRATION_DATABASE_UNAVAILABLE'));
try {
  const c=await pool.connect();
  try {
    await c.query('SELECT pg_advisory_lock(2419044)');
    await c.query('CREATE TABLE IF NOT EXISTS public.bit24_migrations(name text PRIMARY KEY,checksum text NOT NULL,applied_at timestamptz NOT NULL DEFAULT now())');
    for(const file of files){
      const raw=await readFile(new URL('../sql/'+file,import.meta.url),'utf8');
      const checksum=createHash('sha256').update(raw).digest('hex');
      const old=await c.query('SELECT checksum FROM public.bit24_migrations WHERE name=$1',[file]);
      if(old.rowCount){if(old.rows[0].checksum!==checksum)throw Error('MIGRATION_CHECKSUM_CHANGED');continue;}
      // Wrap script + migration ledger atomically. Controlled scripts have a single outer BEGIN/COMMIT.
      const sql=raw.replace(/^BEGIN;\s*$/m,'').replace(/^COMMIT;\s*$/m,'');
      await c.query('BEGIN');
      try {await c.query(sql);await c.query('INSERT INTO public.bit24_migrations(name,checksum) VALUES($1,$2)',[file,checksum]);await c.query('COMMIT');}
      catch(error){await c.query('ROLLBACK');throw error;}
      console.log('APPLIED',file);
    }
  }finally{try{await c.query('SELECT pg_advisory_unlock(2419044)')}finally{c.release()}}
}catch{console.error('MIGRATION_FAILED: inspect schema/version; do not drop production data');process.exitCode=1;}
finally{await pool.end();}
