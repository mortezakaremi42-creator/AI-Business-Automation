import type { Signal } from './risk.js';
export interface Fill { id: string; quantity: number; price: number }
export interface Reconciliation { consistent: boolean; balances: Record<string, number>; openOrders: unknown[]; positions: unknown[] }
export interface Exchange {
  // Must verify actual account permissions and native contingent-order semantics.
  verifyCapabilities(): Promise<void>;
  reconcile(local: unknown[]): Promise<Reconciliation>;
  marketBuy(s: Signal): Promise<Fill>;
  nativeOco(fill: Fill, signal: Signal): Promise<{ id: string }>;
}
// Intentional deployment gate: no fabricated WebSocket URLs, OCO fields or response mappings.
export class UnverifiedBit24Adapter implements Exchange {
  async verifyCapabilities(): Promise<never> { throw Error('BIT24_ADAPTER_NOT_CERTIFIED'); }
  async reconcile(): Promise<Reconciliation> { throw Error('RECONCILIATION_NOT_CERTIFIED'); }
  async marketBuy(): Promise<Fill> { throw Error('LIVE_TRADING_DISABLED'); }
  async nativeOco(): Promise<{id: string}> { throw Error('NATIVE_OCO_NOT_CERTIFIED'); }
}
