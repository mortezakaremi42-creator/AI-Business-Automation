import { randomUUID } from 'node:crypto';
import type { Pool, PoolClient } from 'pg';
import type { TradingStore, TradingSignal, RecoveryTrade, Inspection } from './TradingContracts.js';
import type { OrderState } from './orders/types.js';
import { OrderStateRepository, StateConflict } from './orders/OrderStateRepository.js';
const ACTIVE=`t.status <> 'FAILED' AND NOT t."dryRun" AND NOT EXISTS
  (SELECT 1 FROM trading_v2."EmergencyExits" e WHERE e."tradeId"=t.id AND e.status='CONFIRMED')`;
const VIEW=`SELECT t.*,e.status AS "exitStatus",e."exchangeOrderId" AS "exitOrderId"
  FROM trading_v2."Trades" t LEFT JOIN trading_v2."EmergencyExits" e ON e."tradeId"=t.id`;
export class PgTradingStore implements TradingStore {
  private leader: PoolClient | null=null;
  private owned=false;
  private readonly states: OrderStateRepository;
  constructor(private readonly pool: Pool) {this.states=new OrderStateRepository(pool);}
  async acquireLeadership() {
    if(this.leader)throw Error('LEADERSHIP_ALREADY_ACQUIRED');
    const c=await this.pool.connect();
    try {
      const r=await c.query('SELECT pg_try_advisory_lock(2419042) AS owned');
      if(!r.rows[0].owned)throw Error('ANOTHER_WORKER_ACTIVE');
      this.leader=c;this.owned=true;c.on('error',()=>{this.owned=false});
    }catch(e){c.release(true);throw e;}
  }
  async assertOwnership() {
    if(!this.owned || !this.leader)throw Error('LEADERSHIP_LOST');
    try {await this.leader.query('SELECT 1')}catch{this.owned=false;throw Error('LEADERSHIP_LOST')}
    if(!this.owned)throw Error('LEADERSHIP_LOST');
  }
  async releaseLeadership() {
    const c=this.leader;this.leader=null;
    try {if(c&&this.owned)await c.query('SELECT pg_advisory_unlock(2419042)');}
    finally{this.owned=false;if(c)c.release(true);}
  }
  async listRecoveryTrades(): Promise<RecoveryTrade[]> {
    const r=await this.pool.query<RecoveryTrade>(`${VIEW} WHERE ${ACTIVE}
      AND t.status IN ('PENDING_BUY','BUY_UNKNOWN','BOUGHT_NO_OCO') ORDER BY t."createdAt"`);return r.rows;
  }
  async get(id:string): Promise<RecoveryTrade> {
    const r=await this.pool.query<RecoveryTrade>(`${VIEW} WHERE t.id=$1`,[id]);
    if(!r.rows[0])throw Error('TRADE_NOT_FOUND');return r.rows[0];
  }
  async countActivePositions() {
    const r=await this.pool.query(`SELECT count(*)::integer AS n FROM trading_v2."Trades" t WHERE ${ACTIVE}`);return r.rows[0].n as number;
  }
  async reserve(s:TradingSignal,dryRun:boolean,max:number):Promise<RecoveryTrade|null> {
    await this.assertOwnership();
    const c=await this.pool.connect();
    try {
      await c.query('BEGIN');
      // All phase3 reserve callers use this transaction lock; singleton does not replace DB constraints.
      await c.query('SELECT pg_advisory_xact_lock(2419043)');
      const active=await c.query(`SELECT count(*)::integer AS n FROM trading_v2."Trades" t WHERE ${ACTIVE}`);
      const symbol=s.baseCoin+'/'+s.quoteCoin;
      const same=await c.query(`SELECT 1 FROM trading_v2."Trades" t WHERE ${ACTIVE} AND t.symbol=$1 LIMIT 1`,[symbol]);
      if(active.rows[0].n>=max || same.rowCount){await c.query('ROLLBACK');return null;}
      const r=await c.query(`INSERT INTO trading_v2."Trades"
        (id,symbol,side,"entryPrice",amount,"stopLoss","takeProfit","dryRun")
        VALUES($1,$2,'BUY',$3,$4,$5,$6,$7) ON CONFLICT(id) DO NOTHING RETURNING id`,
        [s.id,symbol,s.entryPrice,s.amount,s.stopLoss,s.takeProfit,dryRun]);
      await c.query('COMMIT');return r.rowCount?this.get(s.id):null;
    }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
  }
  async transition(t:RecoveryTrade,to:OrderState):Promise<RecoveryTrade> {
    const evidence=to==='FAILED'?{kind:'NO_EXECUTION_CONFIRMED' as const,source:'RECONCILIATION' as const}:
      to==='BUY_UNKNOWN'?{kind:'SUBMISSION_UNCERTAIN' as const}:
      to==='SECURED'?{kind:'OCO_CONFIRMED' as const,exchangeProtectionId:t.ocoOrderId??''}:null;
    if(!evidence)throw Error('UNSUPPORTED_TRANSITION');
    await this.states.transition({id:t.id,expectedState:t.status,expectedVersion:t.version,to,evidence});
    return this.get(t.id);
  }
  async confirmBuy(t:RecoveryTrade,f:Extract<Inspection,{kind:'UNPROTECTED'|'PROTECTED'}>):Promise<RecoveryTrade> {
    if(!['PENDING_BUY','BUY_UNKNOWN','BOUGHT_NO_OCO'].includes(t.status))throw Error('INVALID_BUY_STATE');
    const c=await this.pool.connect();
    try {
      await c.query('BEGIN');
      const r=await c.query(`UPDATE trading_v2."Trades" SET status='BOUGHT_NO_OCO',"entryPrice"=$4,amount=$5,
        "buyOrderId"=$6,"ocoOrderId"=COALESCE($7,"ocoOrderId"),version=version+1
        WHERE id=$1 AND status=$2 AND version=$3 RETURNING id`,
        [t.id,t.status,t.version,f.entryPrice,f.amount,f.buyOrderId,f.kind==='PROTECTED'?f.protectionId:null]);
      if(r.rowCount!==1)throw new StateConflict();
      await c.query(`INSERT INTO trading_v2."SystemLogs"(id,"tradeId",level,event,message)
        VALUES($1,$2,'WARN','BUY_CONFIRMED','Fill confirmed; protection requires verification')`,[randomUUID(),t.id]);
      if(f.kind==='UNPROTECTED' && t.status!=='BOUGHT_NO_OCO')await c.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey")
        VALUES($1,$2,'BOUGHT_NO_OCO',$3) ON CONFLICT DO NOTHING`,[randomUUID(),t.id,t.id+':BOUGHT_NO_OCO']);
      await c.query('COMMIT');return this.get(t.id);
    }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
  }
  private async metadata(id:string,sql:string,args:unknown[]=[]) {
    const r=await this.pool.query(`UPDATE trading_v2."Trades" SET ${sql},version=version+1 WHERE id=$1 RETURNING id`,[id,...args]);
    if(r.rowCount!==1)throw Error('TRADE_NOT_FOUND');
  }
  saveBuyAck(id:string,orderId:string){return this.metadata(id,'"buyOrderId"=$2',[orderId]);}
  markOcoAttempted(id:string){return this.metadata(id,'"ocoAttemptedAt"=now()');}
  saveOcoAck(id:string,orderId:string){return this.metadata(id,'"ocoOrderId"=$2',[orderId]);}
  completeSimulation(id:string){return this.metadata(id,'"simulationCompletedAt"=now()');}
  async claimEmergencyExit(t:RecoveryTrade,amount:string):Promise<boolean> {
    const c=await this.pool.connect();
    try {
      await c.query('BEGIN');
      const trade=await c.query('SELECT status,version FROM trading_v2."Trades" WHERE id=$1 FOR UPDATE',[t.id]);
      if(trade.rows[0]?.status!=='BOUGHT_NO_OCO'||trade.rows[0]?.version!==t.version)throw new StateConflict();
      const r=await c.query(`INSERT INTO trading_v2."EmergencyExits"("tradeId",amount,status)
        VALUES($1,$2,'SUBMITTING') ON CONFLICT("tradeId") DO NOTHING RETURNING "tradeId"`,[t.id,amount]);
      // Alert and exit intent survive even a crash before HTTP. Actual notification delivery is separate.
      await c.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey")
        VALUES($1,$2,'CRITICAL_UNPROTECTED_POSITION',$3) ON CONFLICT DO NOTHING`,[randomUUID(),t.id,t.id+':CRITICAL_UNPROTECTED_POSITION']);
      await c.query('COMMIT');return !!r.rowCount;
    }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
  }
  async saveExitAck(id:string,orderId:string) {
    await this.pool.query(`UPDATE trading_v2."EmergencyExits" SET "exchangeOrderId"=$2,status='UNKNOWN',"updatedAt"=now() WHERE "tradeId"=$1 AND status<>'CONFIRMED'`,[id,orderId]);
  }
  async markExitUnknown(id:string) {
    await this.pool.query(`UPDATE trading_v2."EmergencyExits" SET status='UNKNOWN',"updatedAt"=now() WHERE "tradeId"=$1 AND status<>'CONFIRMED'`,[id]);
  }
  async confirmExit(id:string,orderId:string) {
    const r=await this.pool.query(`UPDATE trading_v2."EmergencyExits" SET status='CONFIRMED',"exchangeOrderId"=$2,"updatedAt"=now() WHERE "tradeId"=$1 RETURNING "tradeId"`,[id,orderId]);
    if(r.rowCount!==1)throw Error('EXIT_JOURNAL_MISSING');
  }
  async alert(tradeId:string|null,code:string) {
    await this.pool.query(`INSERT INTO trading_v2."RecoveryAlerts"(id,"tradeId",code,"dedupKey")
      VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`,[randomUUID(),tradeId,code,(tradeId??'system')+':'+code]);
  }
}
