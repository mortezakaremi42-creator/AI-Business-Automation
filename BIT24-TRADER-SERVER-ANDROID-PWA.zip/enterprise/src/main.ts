import 'dotenv/config';
import http from 'node:http';
import express from 'express';
import { Pool } from 'pg';
import { createClient } from 'redis';
import { jwtVerify } from 'jose';
import { WebSocketServer, WebSocket } from 'ws';
import { Store } from './store.js';
import { Engine } from './engine.js';
import { UnverifiedBit24Adapter } from './exchange.js';
import { Telegram } from './telegram.js';
import { sleep } from './retry.js';

function required(k:string) { const v=process.env[k]; if(!v)throw Error(`MISSING_${k}`);return v; }
async function main() {
  const secret = required('JWT_SECRET'); if(Buffer.byteLength(secret)<32)throw Error('JWT_SECRET_TOO_SHORT');
  const jwtKey = new TextEncoder().encode(secret);
  const issuer=required('JWT_ISSUER'),audience=required('JWT_AUDIENCE');
  const db=new Pool({connectionString:required('DATABASE_URL'),connectionTimeoutMillis:5000,query_timeout:10_000});
  const redis=createClient({url:required('REDIS_URL'),socket:{connectTimeout:5000}});
  redis.on('error',()=>console.error('REDIS_UNAVAILABLE'));
  db.on('error',()=>console.error('POSTGRES_POOL_UNAVAILABLE'));
  await redis.connect();
  // Dedicated connection holds singleton ownership for its entire lifetime.
  const leader=await db.connect();
  const lock=await leader.query('SELECT pg_try_advisory_lock(2419042) AS acquired');
  if(!lock.rows[0].acquired)throw Error('ANOTHER_WORKER_ACTIVE');
  let owned=true;
  const store=new Store(db),engine=new Engine(store,new UnverifiedBit24Adapter());
  leader.on('error',()=>{owned=false;engine.ready=false;console.error('LEADER_CONNECTION_LOST');process.exit(1)});
  const telegram=new Telegram(store,required('TELEGRAM_BOT_TOKEN'),required('TELEGRAM_CHAT_ID'));
  const app=express();app.disable('x-powered-by');
  app.get('/health/live',(_q,res)=>res.json({alive:true}));
  app.get('/health/ready',(_q,res)=>res.status(engine.ready?200:503).json({ready:engine.ready}));
  async function authorized(token:string) {
    const {payload}=await jwtVerify(token,jwtKey,{algorithms:['HS256'],issuer,audience,requiredClaims:['exp','sub']});
    if(payload.role!=='operator')throw Error('FORBIDDEN');
  }
  app.use('/api',async(req,res,next)=>{
    try {await authorized((req.headers.authorization||'').replace(/^Bearer /,''));next()}catch{res.status(401).json({error:'UNAUTHORIZED'})}
  });
  app.get('/api/status',(_req,res)=>res.json({ready:engine.ready,balances:engine.balances,mode:'CERTIFICATION_REQUIRED'}));
  // Deliberately no key-storage, withdrawal, order or public signal-injection routes.
  const server=http.createServer(app),wss=new WebSocketServer({noServer:true,maxPayload:4096});
  server.on('upgrade',(req,socket,head)=>{
    // Secure HttpOnly dashboard session, no JWT in URL/logs. Same-origin reverse proxy required.
    const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('session='))?.slice(8);
    if(req.url!=='/events'||!token){socket.destroy();return}
    void authorized(token).then(()=>wss.handleUpgrade(req,socket,head,ws=>{
      // Revalidate periodically so an expired session does not remain authorized.
      const timer=setInterval(()=>{void authorized(token).catch(()=>ws.close(1008,'Session expired'))},30_000);
      ws.on('close',()=>clearInterval(timer));ws.on('error',()=>ws.terminate());
      ws.send(JSON.stringify({type:'status',ready:engine.ready}));
    })).catch(()=>socket.destroy());
  });
  server.listen(Number(process.env.PORT||3100),'0.0.0.0');
  let stopping=false,heartbeat=0,lastRecovery=0;
  const shutdown=()=>{stopping=true;engine.ready=false};
  process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
  process.on('uncaughtException',()=>{console.error('FATAL_EXCEPTION');process.exit(1)});
  process.on('unhandledRejection',()=>{console.error('FATAL_REJECTION');process.exit(1)});
  while(!stopping && owned){
    try {
      await leader.query('SELECT 1');await redis.ping();
      if(!engine.ready && Date.now()-lastRecovery>60_000){
        lastRecovery=Date.now();
        try{await engine.recover()}catch{
          await store.alert('ربات زنده است اما معاملات قفل‌اند: تطبیق یا تأیید اتصال صرافی انجام نشده است.');
        }
      }
      if(Date.now()-heartbeat>=15*60_000){
        await store.alert(`من زنده‌ام | آماده معامله: ${engine.ready} | آخرین موجودی تأییدشده: ${JSON.stringify(engine.balances)}`);heartbeat=Date.now();
      }
      await telegram.flush();
      for(const ws of wss.clients)if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'status',ready:engine.ready,at:Date.now()}));
    }catch{
      engine.ready=false;console.error('DEPENDENCY_FAILURE_TRADING_HALTED');
      try{await store.alert('هشدار: اختلال سرویس یا شبکه؛ معاملات متوقف شدند.')}catch{console.error('ALERT_STORAGE_UNAVAILABLE')}
      await sleep(2000);
    }
    await sleep(1000);
  }
  wss.clients.forEach(ws=>ws.terminate());wss.close();await new Promise<void>(resolve=>server.close(()=>resolve()));
  await leader.query('SELECT pg_advisory_unlock(2419042)');leader.release();await redis.quit();await db.end();
}
main().catch(()=>{console.error('STARTUP_FAILURE');process.exitCode=1});
