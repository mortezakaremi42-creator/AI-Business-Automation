import type { MarketBuy, OCO, Submission } from './Bit24Adapter.js';
import type { Trade, OrderState } from './orders/types.js';
export interface TradingSignal extends MarketBuy {
  id: string; rsi: number; entryPrice: string; stopLoss: string; takeProfit: string; timestamp: number;
}
export interface RecoveryTrade extends Trade {
  stopLoss: string | null; takeProfit: string | null;
  buyOrderId: string | null; ocoOrderId: string | null; ocoAttemptedAt: Date | null; exitOrderId: string | null;
  exitStatus: 'SUBMITTING' | 'UNKNOWN' | 'CONFIRMED' | null;
}
export type Inspection =
  | { kind: 'UNKNOWN' }
  | { kind: 'NO_EXECUTION_CONFIRMED' }
  | { kind: 'PROTECTED'; buyOrderId: string; amount: string; entryPrice: string; protectionId: string }
  | { kind: 'UNPROTECTED'; buyOrderId: string; amount: string; entryPrice: string;
      // Trusted adapter must confirm buy is terminal, no live/pending OCO or other exits,
      // and this amount is net owned, unlocked, attributable to THIS trade, precision-adjusted.
      safeToSell: true }
  | { kind: 'EXIT_CONFIRMED'; exitOrderId: string };
export interface TradingExchange {
  readonly executionMode: 'DRY_RUN' | 'LIVE';
  assertConfiguredForLiveTrading(): void;
  placeMarketBuy(input: MarketBuy): Promise<Submission>;
  placeOCO(input: OCO): Promise<Submission>;
  placeMarketSell(input: MarketBuy): Promise<Submission>;
  inspectTrade(trade: RecoveryTrade): Promise<Inspection>;
}
export interface TradingStore {
  acquireLeadership(): Promise<void>;
  assertOwnership(): Promise<void>;
  releaseLeadership(): Promise<void>;
  listRecoveryTrades(): Promise<RecoveryTrade[]>;
  get(id: string): Promise<RecoveryTrade>;
  countActivePositions(): Promise<number>;
  // Atomic, deduplicated by persistent signal UUID, capacity enforced in DB as well as RiskManager.
  reserve(signal: TradingSignal, dryRun: boolean, maxPositions: number): Promise<RecoveryTrade | null>;
  transition(trade: RecoveryTrade, to: OrderState): Promise<RecoveryTrade>;
  confirmBuy(trade: RecoveryTrade, fact: Extract<Inspection,{kind:'UNPROTECTED'|'PROTECTED'}>): Promise<RecoveryTrade>;
  saveBuyAck(id: string, exchangeOrderId: string): Promise<void>;
  markOcoAttempted(id: string): Promise<void>;
  saveOcoAck(id: string, exchangeOrderId: string): Promise<void>;
  completeSimulation(id: string): Promise<void>;
  claimEmergencyExit(trade: RecoveryTrade, amount: string): Promise<boolean>;
  saveExitAck(id: string, exchangeOrderId: string): Promise<void>;
  markExitUnknown(id: string): Promise<void>;
  confirmExit(id: string, exchangeOrderId: string): Promise<void>;
  alert(tradeId: string | null, code: string): Promise<void>;
}
