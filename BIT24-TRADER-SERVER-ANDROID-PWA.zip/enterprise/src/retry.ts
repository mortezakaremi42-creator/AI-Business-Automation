export class TransientError extends Error {}
export const sleep = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
// Reads only. Never apply automatically to money-moving writes.
export async function retryRead<T>(fn: () => Promise<T>, wait = sleep): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try { return await fn(); } catch (e) {
      if (!(e instanceof TransientError) || attempt >= 4) throw e;
      await wait(Math.min(30_000, 2000 * 2 ** attempt) + Math.random() * 250);
    }
  }
}
