import type { Exchange } from './exchange.js';
import { validate, type Signal } from './risk.js';
import { retryRead } from './retry.js';
import type { Store } from './store.js';
export class Engine {
  ready = false;
  private busy = false;
  balances: Record<string,number> = {};
  constructor(private store: Store, private exchange: Exchange) {}
  async recover() {
    this.ready = false;
    const local = await this.store.db.query("SELECT * FROM intents WHERE state<>'CLOSED'");
    await this.exchange.verifyCapabilities();
    const remote = await retryRead(()=>this.exchange.reconcile(local.rows));
    this.balances = remote.balances;
    if (!remote.consistent || local.rows.some(r=>r.state !== 'PROTECTED')) throw Error('MANUAL_RECONCILIATION_REQUIRED');
    this.ready = true;
    await this.store.audit('RECOVERY_OK',{open:local.rowCount});
  }
  async onSignal(signal: Signal) {
    if (!this.ready || this.busy) throw Error('ENGINE_NOT_READY');
    this.busy = true;
    let submitted = false, inserted = false;
    try {
      validate(signal);
      const row = await this.store.db.query("INSERT INTO intents(id,symbol,state,payload) VALUES($1,$2,'PREPARED',$3) ON CONFLICT DO NOTHING RETURNING id",[signal.id,signal.symbol,JSON.stringify(signal)]);
      if (!row.rowCount) return;
      inserted = true;
      // Persist before network I/O; a crash here becomes a reconciliation gate, not a duplicate buy.
      await this.store.state(signal.id,'SUBMITTING');
      submitted = true;
      const fill = await this.exchange.marketBuy(signal); // NEVER blind-retry a write
      await this.store.state(signal.id,'PROTECTING',fill.id);
      if (!Number.isFinite(fill.quantity) || fill.quantity <= 0) throw Error('UNVERIFIED_FILL');
      const oco = await this.exchange.nativeOco(fill,signal);
      if (!oco.id) throw Error('UNVERIFIED_OCO');
      await this.store.state(signal.id,'PROTECTED',fill.id,oco.id);
    } catch(e) {
      if (inserted) {
        this.ready = false;
        await this.store.state(signal.id,submitted?'UNKNOWN':'HALTED');
        await this.store.alert('توقف ایمن: وضعیت سفارش/حفاظت نیاز به بررسی فوری دارد. سفارش تکرار نشد.');
      }
      throw e;
    } finally { this.busy = false; }
  }
}
