import type { Store } from './store.js';
export class Telegram {
  constructor(private store: Store, private token: string, private chat: string) {}
  async flush() {
    // Single worker enforced by database advisory lock. Durable at-least-once delivery.
    const rows = await this.store.db.query('SELECT id,body FROM alerts WHERE sent_at IS NULL AND next_at<=now() ORDER BY id LIMIT 10');
    for (const a of rows.rows) {
      try {
        const response = await fetch(`https://api.telegram.org/bot${this.token}/sendMessage`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:this.chat,text:a.body}),signal:AbortSignal.timeout(10_000)});
        const data = await response.json() as {ok?:boolean};
        if (!response.ok || !data.ok) throw Error('TELEGRAM_REJECTED');
        await this.store.db.query('UPDATE alerts SET sent_at=now() WHERE id=$1',[a.id]);
      } catch {
        await this.store.db.query("UPDATE alerts SET attempts=attempts+1,next_at=now()+ LEAST(900,POWER(2,LEAST(attempts+1,10))) * interval '1 second' WHERE id=$1",[a.id]);
      }
    }
  }
}
