import type { RecoveryTrade, TradingExchange, TradingStore, Inspection } from './TradingContracts.js';
export interface ReconciliationReport { ready: boolean; examined: number; unresolved: number }
export function isPositiveDecimal(v: unknown): v is string {
  return typeof v === 'string' && /^(0|[1-9]\d{0,19})(\.\d{1,18})?$/.test(v) && /[1-9]/.test(v);
}
export class Reconciler {
  constructor(private readonly store: TradingStore, private readonly exchange: TradingExchange) {}
  async reconcileOnStartup(): Promise<ReconciliationReport> {
    await this.store.assertOwnership();
    const trades = await this.store.listRecoveryTrades();
    let unresolved = 0;
    // Sequential: emergency exits are never submitted concurrently by this worker.
    for (const trade of trades) {
      if (this.exchange.executionMode !== 'LIVE') {
        unresolved++; await this.store.alert(trade.id,'LIVE_RECOVERY_BLOCKED_IN_DRY_RUN'); continue;
      }
      try { if (!await this.reconcileTrade(trade)) unresolved++; }
      catch {
        unresolved++;
        // Never log raw network errors/credentials. Failure to store alerts propagates to engine backoff.
        await this.store.alert(trade.id,'RECONCILIATION_FAILED_TRADING_HALTED');
      }
    }
    return {ready:unresolved===0,examined:trades.length,unresolved};
  }
  private async reconcileTrade(initial: RecoveryTrade): Promise<boolean> {
    await this.store.assertOwnership();
    let trade = initial;
    const fact = await this.exchange.inspectTrade(trade);
    if (fact.kind === 'UNKNOWN') { await this.store.alert(trade.id,'BUY_OR_PROTECTION_UNKNOWN'); return false; }
    if (fact.kind === 'EXIT_CONFIRMED') {
      if (!trade.exitStatus || !fact.exitOrderId.trim() || (trade.exitOrderId && trade.exitOrderId!==fact.exitOrderId)) throw Error('UNEXPECTED_EXIT');
      await this.store.confirmExit(trade.id,fact.exitOrderId); return true;
    }
    if (fact.kind === 'NO_EXECUTION_CONFIRMED') {
      if (trade.exitStatus || trade.status === 'BOUGHT_NO_OCO') throw Error('CONTRADICTORY_NO_EXECUTION');
      await this.store.transition(trade,'FAILED'); return true;
    }
    this.validateFill(fact);
    if(trade.buyOrderId && trade.buyOrderId!==fact.buyOrderId)throw Error('BUY_ID_MISMATCH');
    trade = await this.store.confirmBuy(trade,fact);
    // Any previous emergency write must be reconciled, never blindly repeated or forgotten.
    if (trade.exitStatus) { await this.store.alert(trade.id,'EMERGENCY_EXIT_RESULT_UNKNOWN'); return false; }
    if (fact.kind === 'PROTECTED') {
      if (!fact.protectionId.trim()) throw Error('INVALID_PROTECTION_ID');
      await this.store.transition(trade,'SECURED'); return true;
    }
    if (fact.safeToSell !== true) throw Error('EXIT_SAFETY_NOT_CONFIRMED');
    const [baseCoin,quoteCoin] = trade.symbol.split('/');
    if (!baseCoin || !quoteCoin) throw Error('INVALID_SYMBOL');
    // Persist a one-shot journal entry BEFORE calling sell. Crash after this point requires reconciliation.
    if (!await this.store.claimEmergencyExit(trade,fact.amount)) return false;
    await this.store.assertOwnership();
    try {
      const receipt = await this.exchange.placeMarketSell({baseCoin,quoteCoin,amount:fact.amount});
      if (receipt.mode !== 'LIVE' || receipt.operation !== 'MARKET_SELL') throw Error('INVALID_SELL_RECEIPT');
      await this.store.saveExitAck(trade.id,receipt.exchangeOrderId);
    } catch {
      await this.store.markExitUnknown(trade.id);
      await this.store.alert(trade.id,'CRITICAL_EMERGENCY_SELL_UNKNOWN_DO_NOT_RETRY');
      return false;
    }
    await this.store.alert(trade.id,'CRITICAL_EMERGENCY_SELL_SUBMITTED_AWAITING_FILL');
    // ACK is not a fill. Only a subsequent trusted inspection may confirm the position is flat.
    const after = await this.exchange.inspectTrade(await this.store.get(trade.id));
    if (after.kind !== 'EXIT_CONFIRMED' || !after.exitOrderId.trim()) return false;
    const recorded=await this.store.get(trade.id);
    if(recorded.exitOrderId && recorded.exitOrderId!==after.exitOrderId)throw Error('EXIT_ID_MISMATCH');
    await this.store.confirmExit(trade.id,after.exitOrderId);
    return true;
  }
  private validateFill(fact: Extract<Inspection,{kind:'UNPROTECTED'|'PROTECTED'}>) {
    if (!fact.buyOrderId.trim() || !isPositiveDecimal(fact.amount) || !isPositiveDecimal(fact.entryPrice)) throw Error('INVALID_FILL');
  }
}
