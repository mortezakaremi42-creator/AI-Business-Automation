export interface RiskSignal { rsi: number }
export interface PositionCounter {
  // Include pending/unknown buys and unprotected holdings, not only SECURED.
  countActivePositions(): Promise<number>;
}
export class RiskRejectionError extends Error {
  constructor(readonly code: 'REJECTED_RSI_TOO_HIGH' | 'REJECTED_MAX_OPEN_POSITIONS' | 'REJECTED_INVALID_SIGNAL' | 'REJECTED_POSITION_STATE_UNAVAILABLE') {
    super(code); this.name = 'RiskRejectionError';
  }
}
export class RiskManager {
  constructor(private readonly positions: PositionCounter, private readonly maxOpenPositions = 3) {
    if (!Number.isSafeInteger(maxOpenPositions) || maxOpenPositions < 1) throw Error('INVALID_POSITION_LIMIT');
  }
  async validateSignal(signal: RiskSignal): Promise<void> {
    if (!signal || !Number.isFinite(signal.rsi) || signal.rsi < 0 || signal.rsi > 100)
      throw new RiskRejectionError('REJECTED_INVALID_SIGNAL');
    // Preserve the previously agreed stricter boundary: 75 itself is also rejected.
    if (signal.rsi >= 75) throw new RiskRejectionError('REJECTED_RSI_TOO_HIGH');
    let count: number;
    try { count = await this.positions.countActivePositions(); }
    catch { throw new RiskRejectionError('REJECTED_POSITION_STATE_UNAVAILABLE'); }
    if (!Number.isSafeInteger(count) || count < 0) throw new RiskRejectionError('REJECTED_POSITION_STATE_UNAVAILABLE');
    if (count >= this.maxOpenPositions) throw new RiskRejectionError('REJECTED_MAX_OPEN_POSITIONS');
  }
}
