import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import {scrypt,timingSafeEqual,randomUUID} from 'node:crypto';
import {Pool} from 'pg';
import {createClient} from 'redis';
import {SignJWT,jwtVerify} from 'jose';
import {WebSocketServer,WebSocket} from 'ws';
import {PgTradingStore} from './PgTradingStore.js';
import {PgNotificationOutbox} from './PgNotificationOutbox.js';
import {NotificationService} from './NotificationService.js';
import {Bit24Adapter,RedisTokenBucket} from './Bit24Adapter.js';
import {Reconciler,isPositiveDecimal} from './Reconciler.js';
import {RiskManager} from './RiskManager.js';
import {TradingEngine,type SignalSource} from './TradingEngine.js';
import type {TradingSignal} from './TradingContracts.js';
function env(key:string){const v=process.env[key];if(!v)throw Error('MISSING_'+key);return v;}
async function main(){
  if((process.env.TRADING_MODE??'DRY_RUN')!=='DRY_RUN')throw Error('LIVE_NOT_CERTIFIED');
  const key=env('JWT_SECRET');if(Buffer.byteLength(key)<32)throw Error('JWT_SECRET_TOO_SHORT');
  const jwtKey=new TextEncoder().encode(key),origin=new URL(env('PUBLIC_ORIGIN')).origin;
  const production=process.env.NODE_ENV==='production';
  if(production&&!origin.startsWith('https://'))throw Error('HTTPS_REQUIRED');
  const passwordSpec=env('ADMIN_PASSWORD_HASH').split(':');
  if(passwordSpec.length!==2||!/^[0-9a-f]{32}$/.test(passwordSpec[0])||!/^[0-9a-f]{128}$/.test(passwordSpec[1]))throw Error('INVALID_PASSWORD_HASH');
  const issuer='bit24-runtime',audience='bit24-operator';
  const pool=new Pool({connectionString:env('DATABASE_URL'),connectionTimeoutMillis:5000,query_timeout:5000,max:12});
  pool.on('error',()=>console.error('DATABASE_CONNECTION_FAILURE'));
  const redis=createClient({url:env('REDIS_URL'),disableOfflineQueue:true,socket:{connectTimeout:5000},commandsQueueMaxLength:1000});
  redis.on('error',()=>console.error('REDIS_UNAVAILABLE'));
  await redis.connect();await pool.query('SELECT id FROM trading_v2."SignalInbox" LIMIT 0');
  const store=new PgTradingStore(pool),outbox=new PgNotificationOutbox(pool);
  // Intentionally no API credentials/verified contract in deployed adapter: HTTP trading cannot run.
  const adapter=new Bit24Adapter(new RedisTokenBucket(redis,'bit24:dryrun:single-account'));
  const source:SignalSource={next:async signal=>{
    if(signal.aborted)return null;
    const r=await pool.query<{payload:TradingSignal}>('SELECT payload FROM trading_v2."SignalInbox" WHERE "consumedAt" IS NULL ORDER BY "createdAt",id LIMIT 1');
    return r.rows[0]?.payload??null;
  },ack:async id=>{await pool.query('UPDATE trading_v2."SignalInbox" SET "consumedAt"=now() WHERE id=$1',[id])}};
  const engine=new TradingEngine(store,adapter,new RiskManager(store,3),source,new Reconciler(store,adapter));
  const stop=new AbortController();let ending=false;
  const app=express();app.disable('x-powered-by');app.set('trust proxy','loopback');
  app.use((_req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',`default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' ${origin.replace(/^http/,'ws')}; img-src 'self' data:; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'`);next()});
  app.use(express.json({limit:'8kb'}));
  const wrap=(fn:express.RequestHandler):express.RequestHandler=>(req,res,next)=>{Promise.resolve(fn(req,res,next)).catch(next)};
  const token=(req:express.Request)=>(req.headers.cookie??'').split(';').map(v=>v.trim()).find(v=>v.startsWith('session='))?.slice(8)??'';
  async function verify(value:string){const {payload}=await jwtVerify(value,jwtKey,{algorithms:['HS256'],issuer,audience,requiredClaims:['exp','sub']});if(payload.role!=='operator')throw Error('UNAUTHORIZED')}
  // Global rate key (single operator deployment) is conservative and does not trust spoofed forwarded IPs.
  async function limit(scope:string,max:number){const count=Number(await redis.eval("local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],60) end; return n",{keys:['runtime:limit:'+scope],arguments:[]}));return count<=max;}
  app.use('/api',(req,res,next)=>{res.setHeader('Cache-Control','no-store');if(req.method!=='GET'&&req.headers.origin!==origin){res.status(403).json({error:'ORIGIN_FORBIDDEN'});return}next()});
  app.post('/api/login',wrap(async(req,res)=>{
    if(!await limit('login',10)){res.status(429).json({error:'RATE_LIMIT'});return}
    const password=typeof req.body?.password==='string'?req.body.password:'';
    const hash=await new Promise<Buffer>((resolve,reject)=>scrypt(password.slice(0,256),passwordSpec[0],64,(error,value)=>error?reject(error):resolve(value)));
    if(req.body?.username!==(process.env.ADMIN_USERNAME??'admin')||!timingSafeEqual(hash,Buffer.from(passwordSpec[1],'hex'))){res.status(401).json({error:'INVALID_CREDENTIALS'});return}
    const jwt=await new SignJWT({role:'operator'}).setProtectedHeader({alg:'HS256'}).setSubject('operator').setIssuer(issuer).setAudience(audience).setIssuedAt().setExpirationTime('1h').sign(jwtKey);
    res.cookie('session',jwt,{httpOnly:true,secure:production,sameSite:'strict',maxAge:3600_000,path:'/'});res.json({ok:true});
  }));
  app.use('/api',wrap(async(req,res,next)=>{try{await verify(token(req));next()}catch{res.status(401).json({error:'UNAUTHORIZED'})}}));
  app.post('/api/logout',(_req,res)=>{res.clearCookie('session',{path:'/',httpOnly:true,secure:production,sameSite:'strict'});res.json({ok:true})});
  let notifications:NotificationService|null=null;
  const status=async()=>({mode:'DRY_RUN' as const,balances:null,openPositions:await store.countActivePositions(),observedAt:null});
  app.get('/api/status',wrap(async(_req,res)=>{
    const trades=await pool.query('SELECT id,symbol,status,"dryRun","simulationCompletedAt","createdAt" FROM trading_v2."Trades" ORDER BY "createdAt" DESC LIMIT 20');
    const alerts=await pool.query('SELECT code,"createdAt","deliveredAt" FROM trading_v2."RecoveryAlerts" ORDER BY "createdAt" DESC LIMIT 10');
    res.json({...await status(),engine:engine.status,telegram:notifications?'ENABLED':'NOT_CONFIGURED',signalFeed:'MANUAL_DRY_RUN_ONLY',trades:trades.rows,alerts:alerts.rows});
  }));
  app.post('/api/dry-run',wrap(async(req,res)=>{
    if(!await limit('dryrun',10)){res.status(429).json({error:'RATE_LIMIT'});return}
    const b=req.body;
    if(!b||!['baseCoin','quoteCoin'].every(k=>typeof b[k]==='string'&&/^[A-Z0-9]{1,24}$/.test(b[k]))||b.baseCoin===b.quoteCoin||
      !['amount','entryPrice','stopLoss','takeProfit'].every(k=>isPositiveDecimal(b[k]))||!Number.isFinite(b.rsi)||b.rsi<0||b.rsi>100){res.status(400).json({error:'INVALID_SIGNAL'});return}
    const s:TradingSignal={id:randomUUID(),baseCoin:b.baseCoin,quoteCoin:b.quoteCoin,amount:b.amount,entryPrice:b.entryPrice,stopLoss:b.stopLoss,takeProfit:b.takeProfit,rsi:b.rsi,timestamp:Date.now()};
    await pool.query('INSERT INTO trading_v2."SignalInbox"(id,payload) VALUES($1,$2)',[s.id,JSON.stringify(s)]);
    res.status(202).json({id:s.id,message:'DRY_RUN_QUEUED_NOT_EXECUTED'});
  }));
  app.post('/api/heartbeat',wrap(async(_req,res)=>{if(!notifications){res.status(409).json({error:'TELEGRAM_NOT_CONFIGURED'});return}if(!await limit('heartbeat',3)){res.status(429).json({error:'RATE_LIMIT'});return}await notifications.sendHeartbeat();res.status(202).json({queued:true})}));
  app.get('/health/live',(_req,res)=>res.json({alive:!ending}));
  app.get('/health/monitor',wrap(async(_req,res)=>{
    try{
      await pool.query('SELECT 1');await redis.ping();
      const notificationHealth=notifications?await notifications.health():null;
      const state=engine.status;const healthy=(!notificationHealth||(notificationHealth.running&&notificationHealth.failedJobs===0))&&!ending&&state.phase==='RUNNING'&&state.lastIterationAt!==null&&Date.now()-state.lastIterationAt<120_000;
      res.status(healthy?200:503).json({ok:healthy,mode:'DRY_RUN'});
    }catch{res.status(503).json({ok:false})}
  }));
  app.get('/health/trading',(_req,res)=>res.status(503).json({ready:false,reason:'LIVE_NOT_CERTIFIED'}));
  app.use(express.static(new URL('../public/',import.meta.url).pathname,{etag:true,setHeaders:(res,path)=>{if(path.endsWith('sw.js')||path.endsWith('.html'))res.setHeader('Cache-Control','no-cache')}}));
  app.use(((error:unknown,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{console.error('HTTP_REQUEST_FAILED');res.status(503).json({error:'SERVICE_UNAVAILABLE'})}) as express.ErrorRequestHandler);
  const server=http.createServer(app);const sockets=new WebSocketServer({noServer:true,maxPayload:1024});
  server.on('upgrade',(req,socket,head)=>{
    if(req.url!=='/events'||req.headers.origin!==origin){socket.destroy();return}
    void verify((req.headers.cookie??'').split(';').map(x=>x.trim()).find(x=>x.startsWith('session='))?.slice(8)??'').then(()=>{
      sockets.handleUpgrade(req,socket,head,ws=>{
        const timer=setInterval(()=>{void verify((req.headers.cookie??'').split(';').map(x=>x.trim()).find(x=>x.startsWith('session='))?.slice(8)??'').then(()=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'engine',...engine.status}))}).catch(()=>ws.close(1008,'Expired'))},5000);
        ws.on('close',()=>clearInterval(timer));ws.on('error',()=>ws.terminate());
      });
    }).catch(()=>socket.destroy());
  });
  if(Boolean(process.env.TELEGRAM_BOT_TOKEN)!==Boolean(process.env.TELEGRAM_CHAT_ID))throw Error('INCOMPLETE_TELEGRAM_CONFIGURATION');
  if(process.env.TELEGRAM_BOT_TOKEN){
    notifications=new NotificationService({redisUrl:env('REDIS_URL'),botToken:process.env.TELEGRAM_BOT_TOKEN,chatId:env('TELEGRAM_CHAT_ID'),outbox,status:{getSnapshot:status},onDiagnostic:code=>console.error(code)});
    await notifications.start();
  }
  await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(Number(process.env.PORT??3100),'0.0.0.0',resolve)});
  const shutdown=()=>{if(ending)return;ending=true;stop.abort();const t=setTimeout(()=>process.exit(1),50_000);t.unref()};
  process.once('SIGTERM',shutdown);process.once('SIGINT',shutdown);
  const watchdog=setInterval(()=>{
    const last=engine.status.lastIterationAt;
    if(!ending&&last!==null&&Date.now()-last>120_000){console.error('ENGINE_STALLED_RESTART');process.exit(1)}
  },30_000);watchdog.unref();
  console.log('RUNTIME_STARTED_DRY_RUN_ONLY');
  try{await engine.run(stop.signal)}finally{
    clearInterval(watchdog);ending=true;sockets.clients.forEach(ws=>ws.terminate());sockets.close();
    await new Promise<void>(resolve=>server.close(()=>resolve()));
    await notifications?.close();await redis.quit();await pool.end();
  }
}
main().catch(()=>{console.error('RUNTIME_FATAL_CHECK_CONFIGURATION_AND_MIGRATIONS');process.exit(1)});
