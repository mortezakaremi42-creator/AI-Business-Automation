import { Pool } from 'pg';
export class Store {
  constructor(readonly db: Pool) {}
  async audit(event: string, details: unknown) { await this.db.query('INSERT INTO audit(event,details) VALUES($1,$2)', [event, JSON.stringify(details)]); }
  async alert(body: string) { await this.db.query('INSERT INTO alerts(body) VALUES($1)', [body]); }
  async state(id: string, state: string, exchangeId?: string, protectionId?: string) {
    await this.db.query('UPDATE intents SET state=$2, exchange_id=COALESCE($3,exchange_id), protection_id=COALESCE($4,protection_id),updated_at=now() WHERE id=$1', [id,state,exchangeId,protectionId]);
  }
  async closed(exchangeId: string, intentId: string, realizedReturn: number, details: unknown) {
    if (!Number.isFinite(realizedReturn)) throw Error('INVALID_RETURN');
    const c = await this.db.connect();
    try {
      await c.query('BEGIN');
      const row = await c.query('INSERT INTO trades(exchange_id,intent_id,realized_return,details) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING RETURNING exchange_id',[exchangeId,intentId,realizedReturn,JSON.stringify(details)]);
      if (row.rowCount) {
        await c.query("UPDATE intents SET state='CLOSED',updated_at=now() WHERE id=$1",[intentId]);
        if (realizedReturn < -.02) await c.query('INSERT INTO alerts(body) VALUES($1)',[`هشدار: معامله ${exchangeId} با بازده ${(realizedReturn*100).toFixed(2)}٪ بسته شد.`]);
      }
      await c.query('COMMIT');
    } catch(e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
  }
}
