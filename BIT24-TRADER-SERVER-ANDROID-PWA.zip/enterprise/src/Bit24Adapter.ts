import type { Inspection, RecoveryTrade } from './TradingContracts.js';
import { createHash, createHmac, randomUUID } from 'node:crypto';
import { sleep } from './retry.js';
export type Operation = 'MARKET_BUY' | 'MARKET_SELL' | 'OCO' | 'RECONCILE';
export interface MarketBuy { baseCoin: string; quoteCoin: string; amount: string }
export interface OCO extends MarketBuy { stopLoss: string; takeProfit: string }
export type Submission =
  | { mode: 'DRY_RUN'; simulated: true; operation: Operation; simulationId: string }
  | { mode: 'LIVE'; simulated: false; operation: Operation; exchangeOrderId: string; status: 'ACKNOWLEDGED_NOT_VERIFIED' };
export class NetworkTimeoutError extends Error {
  readonly outcome = 'UNKNOWN';
  constructor(readonly operation: Operation) { super('NETWORK_TIMEOUT'); this.name = 'NetworkTimeoutError'; }
}
export class UnknownSubmissionError extends Error {
  readonly outcome = 'UNKNOWN';
  constructor(readonly operation: Operation, readonly httpStatus?: number) { super('UNKNOWN_SUBMISSION_RESULT'); this.name = 'UnknownSubmissionError'; }
}
export class RateLimitWaitError extends Error {
  readonly submitted = false;
  constructor() { super('RATE_LIMIT_WAIT_EXCEEDED'); this.name = 'RateLimitWaitError'; }
}
export class RateLimitUnavailableError extends Error {
  readonly submitted = false;
  constructor() { super('REDIS_RATE_LIMIT_UNAVAILABLE'); this.name = 'RateLimitUnavailableError'; }
}
export interface RedisEval {
  eval(script: string, options: { keys: string[]; arguments: string[] }): Promise<unknown>;
}
// Redis TIME is shared by all workers. Consumption, refill and expiry are atomic.
export const TOKEN_BUCKET_LUA = `
local tm = redis.call('TIME')
local now = tonumber(tm[1]) * 1000 + tonumber(tm[2]) / 1000
local rate = tonumber(ARGV[1])
local capacity = tonumber(ARGV[2])
local data = redis.call('HMGET', KEYS[1], 'tokens', 'at')
local tokens = tonumber(data[1]) or capacity
local last = tonumber(data[2]) or now
now = math.max(now, last)
tokens = math.min(capacity, tokens + (now - last) * rate / 1000)
local allowed = 0
local wait = 0
if tokens >= 1 then
 tokens = tokens - 1
 allowed = 1
else
 wait = math.ceil((1 - tokens) * 1000 / rate)
end
redis.call('HSET', KEYS[1], 'tokens', tokens, 'at', now)
redis.call('PEXPIRE', KEYS[1], math.ceil(capacity / rate * 1000) + 1000)
return {allowed, wait}
`;
export class RedisTokenBucket {
  constructor(private readonly redis: RedisEval, private readonly key: string,
    private readonly rate = 2, private readonly capacity = 1,
    private readonly wait: (ms: number) => Promise<void> = sleep) {
    if (!key || !Number.isFinite(rate) || rate <= 0 || !Number.isSafeInteger(capacity) || capacity < 1)
      throw Error('INVALID_BUCKET_CONFIG');
  }
  async acquire(maxWaitMs = 5000): Promise<void> {
    if (!Number.isFinite(maxWaitMs) || maxWaitMs < 0) throw Error('INVALID_WAIT_BUDGET');
    const start = performance.now();
    for (;;) {
      let result: unknown;
      try { result = await this.redis.eval(TOKEN_BUCKET_LUA, {keys: [this.key], arguments: [String(this.rate), String(this.capacity)]}); }
      catch { throw new RateLimitUnavailableError(); }
      if (!Array.isArray(result) || result.length !== 2 || ![0,1].includes(Number(result[0])) || !Number.isFinite(Number(result[1])))
        throw new RateLimitUnavailableError();
      if (Number(result[0]) === 1) return;
      const delay = Math.max(1, Number(result[1]));
      if (performance.now() - start + delay > maxWaitMs) throw new RateLimitWaitError();
      await this.wait(delay);
    }
  }
}
export interface VerifiedOrderContract {
  // Only approved REST reads are supplied. Must handle pagination, ownership, terminal partial fills,
  // open/cancelled OCOs and delayed visibility. No record found alone is NOT no execution.
  inspectTrade?(trade: RecoveryTrade, readOrders: (query: Record<string,string>) => Promise<unknown>): Promise<Inspection>;
  // Inject only after matching official docs + sandbox/account tests. Never from HTTP/user input.
  // Must validate response envelope; returning an ID is ACK only, not fill/OCO confirmation.
  decodeAcknowledgement(body: unknown, operation: Operation): { exchangeOrderId: string };
  // OCO field semantics remain gated until officially verified; endpoint is fixed below.
  encodeOCO?(input: OCO): Record<string, string>;
}
export interface AdapterOptions {
  mode?: 'DRY_RUN' | 'LIVE';
  apiKey?: string;
  secretKey?: string;
  timeoutMs?: number;
  contract?: VerifiedOrderContract;
  fetchImpl?: typeof fetch;
}
const PATH = '/pro/capi/v2/spot-orders/submit';
function positiveDecimal(value: string) {
  // Keep money as decimal text. Market-specific tick/step/min-notional checks belong in certified contract.
  return typeof value === 'string' && /^(0|[1-9]\d{0,19})(\.\d{1,18})?$/.test(value) && /[1-9]/.test(value);
}
function validateBuy(input: MarketBuy) {
  if (!input || !/^[A-Z0-9]{1,24}$/.test(input.baseCoin) || !/^[A-Z0-9]{1,24}$/.test(input.quoteCoin) || input.baseCoin === input.quoteCoin || !positiveDecimal(input.amount))
    throw Error('INVALID_ORDER_INPUT');
}
function compareDecimals(a: string, b: string) {
  const units = (v: string) => { const [whole, fraction = ''] = v.split('.'); return BigInt(whole) * 10n ** 18n + BigInt(fraction.padEnd(18, '0')); };
  return units(a) < units(b);
}
export class Bit24Adapter {
  private readonly mode: 'DRY_RUN' | 'LIVE';
  private readonly request: typeof fetch;
  private readonly timeoutMs: number;
  constructor(private readonly limiter: Pick<RedisTokenBucket, 'acquire'>, private readonly options: AdapterOptions = {}) {
    this.mode = options.mode ?? 'DRY_RUN';
    if (!['LIVE','DRY_RUN'].includes(this.mode)) throw Error('INVALID_MODE');
    this.request = options.fetchImpl ?? fetch;
    this.timeoutMs = options.timeoutMs ?? 10_000;
    if (!Number.isSafeInteger(this.timeoutMs) || this.timeoutMs < 1 || this.timeoutMs > 60_000) throw Error('INVALID_TIMEOUT');
  }
  static bucketKey(apiKey: string): string {
    // Shared account scope; never put raw credentials into Redis keys.
    return 'bit24:orders:bucket:' + createHash('sha256').update(apiKey).digest('hex');
  }
  get executionMode(): 'DRY_RUN' | 'LIVE' { return this.mode; }
  assertConfiguredForLiveTrading(): void {
    // Configuration gate only; official contract, account permissions and infrastructure still need certification.
    if (this.mode !== 'LIVE' || !this.options.apiKey || !this.options.secretKey ||
      !this.options.contract?.encodeOCO || !this.options.contract?.inspectTrade)
      throw Error('LIVE_RECOVERY_AND_PROTECTION_NOT_CONFIGURED');
  }
  async placeMarketBuy(input: MarketBuy): Promise<Submission> {
    try {
      validateBuy(input);
      return await this.submit('MARKET_BUY', () => ({base_coin_symbol:input.baseCoin,quote_coin_symbol:input.quoteCoin,side:'1',type:'1',amount:input.amount}));
    } catch (error) { throw error; } // Preserve typed timeout and uncertainty for the state-machine layer.
  }
  async placeMarketSell(input: MarketBuy): Promise<Submission> {
    try {
      validateBuy(input);
      return await this.submit('MARKET_SELL', () => ({base_coin_symbol:input.baseCoin,quote_coin_symbol:input.quoteCoin,side:'0',type:'1',amount:input.amount}));
    } catch (error) { throw error; }
  }
  async inspectTrade(trade: RecoveryTrade): Promise<Inspection> {
    if (this.mode !== 'LIVE' || !this.options.contract?.inspectTrade || !this.options.apiKey)
      throw Error('RECONCILIATION_CONTRACT_NOT_VERIFIED');
    // The resolver cannot supply arbitrary endpoints or trigger writes.
    return this.options.contract.inspectTrade(trade, query => this.readOrders(query));
  }
  private async readOrders(query: Record<string,string>): Promise<unknown> {
    await this.limiter.acquire();
    const url = new URL('https://rest.bit24.cash/pro/capi/v2/spot-orders');
    url.search = new URLSearchParams(query).toString();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.request(url.toString(), {method:'GET',redirect:'error',
        headers:{'X-BIT24-APIKEY':this.options.apiKey!},signal:controller.signal});
      if (!response.ok) throw Error('RECONCILIATION_READ_FAILED');
      const body: unknown = await response.json();
      if (controller.signal.aborted) throw new NetworkTimeoutError('RECONCILE');
      return body;
    } catch (error) {
      if (controller.signal.aborted || (error instanceof Error && ['TimeoutError','AbortError'].includes(error.name)))
        throw new NetworkTimeoutError('RECONCILE');
      throw Error('RECONCILIATION_READ_FAILED');
    } finally { clearTimeout(timer); }
  }
  async placeOCO(input: OCO): Promise<Submission> {
    try {
      validateBuy(input);
      if (!positiveDecimal(input.stopLoss) || !positiveDecimal(input.takeProfit) || !compareDecimals(input.stopLoss,input.takeProfit)) throw Error('INVALID_OCO_PRICES');
      return await this.submit('OCO', () => {
        if (!this.options.contract?.encodeOCO) throw Error('OCO_CONTRACT_NOT_VERIFIED');
        const fields = this.options.contract.encodeOCO(input);
        if (fields.type !== '3' || fields.side !== '0' || fields.base_coin_symbol !== input.baseCoin || fields.quote_coin_symbol !== input.quoteCoin || fields.amount !== input.amount || 'signature' in fields)
          throw Error('INVALID_CERTIFIED_OCO_FIELDS');
        return fields;
      });
    } catch (error) { throw error; }
  }
  private async submit(operation: Operation, encode: () => Record<string,string>): Promise<Submission> {
    if (this.mode === 'DRY_RUN') {
      await this.limiter.acquire();
      return {mode:'DRY_RUN',simulated:true,operation,simulationId:randomUUID()};
    }
    if (!this.options.apiKey || !this.options.secretKey || !this.options.contract) throw Error('LIVE_CONTRACT_NOT_VERIFIED');
    const fields = encode(); // All preflight failures happen before any network write.
    await this.limiter.acquire();
    const form = new URLSearchParams(fields);
    form.set('signature', createHmac('sha256', this.options.secretKey).update(form.toString()).digest('hex'));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.request('https://rest.bit24.cash' + PATH, {
        method:'POST',redirect:'error',signal:controller.signal,
        headers:{'Content-Type':'application/x-www-form-urlencoded','X-BIT24-APIKEY':this.options.apiKey},body:form.toString(),
      });
      // Even an HTTP error is not proof that a write was never executed. Reconcile, never blindly retry.
      if (!response.ok) throw new UnknownSubmissionError(operation,response.status);
      const body: unknown = await response.json();
      if (controller.signal.aborted) throw new NetworkTimeoutError(operation);
      const ack = this.options.contract.decodeAcknowledgement(body,operation);
      if (typeof ack.exchangeOrderId !== 'string' || !ack.exchangeOrderId.trim()) throw Error('INVALID_ACK');
      return {mode:'LIVE',simulated:false,operation,exchangeOrderId:ack.exchangeOrderId,status:'ACKNOWLEDGED_NOT_VERIFIED'};
    } catch (error) {
      if (controller.signal.aborted || (error instanceof Error && ['TimeoutError','AbortError'].includes(error.name)))
        throw new NetworkTimeoutError(operation);
      if (error instanceof UnknownSubmissionError) throw error;
      throw new UnknownSubmissionError(operation);
    } finally { clearTimeout(timer); }
  }
}
