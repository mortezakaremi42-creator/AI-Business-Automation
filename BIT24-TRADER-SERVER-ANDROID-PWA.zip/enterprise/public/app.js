'use strict';
const $=id=>document.getElementById(id);let socket,refreshing=false,installPrompt;
const notify=text=>{$('message').textContent=text};
async function api(path,options={}){
  const res=await fetch(path,{...options,headers:{'Content-Type':'application/json',...options.headers},credentials:'same-origin',signal:AbortSignal.timeout(8000)});
  const data=await res.json();if(!res.ok){if(res.status===401)showLogin();throw Error(data.error||'SERVICE_UNAVAILABLE')}return data;
}
function showLogin(){$('loginCard').hidden=false;$('dashboard').hidden=true;if(socket){socket.close();socket=null}}
function showDashboard(){$('loginCard').hidden=true;$('dashboard').hidden=false}
const phases={RUNNING:'فعال — شبیه‌سازی',PAUSED:'توقف ایمن',RECOVERING:'در حال بازیابی',STARTING:'راه‌اندازی',STOPPED:'متوقف'};
function engineState(state){$('engineState').textContent=phases[state?.phase]||'نامشخص'}
function connect(){if(socket&&socket.readyState<2)return;socket=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/events`);socket.onopen=()=>{$('connection').textContent='● اتصال زندهٔ پنل برقرار است'};socket.onmessage=e=>{try{engineState(JSON.parse(e.data))}catch{}};socket.onclose=()=>{$('connection').textContent='○ اتصال زنده قطع است؛ به‌روزرسانی را بزن'};socket.onerror=()=>{$('connection').textContent='○ ارتباط با سرور برقرار نشد'}}
function cell(row,text){const c=document.createElement('td');c.textContent=text;row.append(c)}
async function refresh(){if(refreshing)return;refreshing=true;try{
  const data=await api('/api/status');showDashboard();engineState(data.engine);$('openPositions').textContent=data.openPositions??'نامشخص';$('telegramState').textContent=data.telegram==='ENABLED'?'پیکربندی شده':'تنظیم نشده';$('lastUpdate').textContent='آخرین دریافت: '+new Date().toLocaleTimeString('fa-IR');
  $('trades').replaceChildren();for(const t of data.trades){const row=document.createElement('tr');cell(row,t.symbol);cell(row,t.dryRun?'آزمایش':'واقعی — نیازمند بررسی');cell(row,t.dryRun?(t.simulationCompletedAt?'شبیه‌سازی تکمیل شد':'آزمایش ناتمام'):t.status);cell(row,new Date(t.createdAt).toLocaleString('fa-IR'));$('trades').append(row)}
  if(!data.trades.length){const row=document.createElement('tr');cell(row,'هنوز آزمایشی ثبت نشده است.');$('trades').append(row)}
  $('alerts').replaceChildren();for(const a of data.alerts){const li=document.createElement('li');li.textContent=`${a.code} — ${a.deliveredAt?'تلگرام پذیرفته است':'در انتظار تحویل'} — ${new Date(a.createdAt).toLocaleString('fa-IR')}`;$('alerts').append(li)}
  if(!data.alerts.length){const li=document.createElement('li');li.textContent='رویدادی ثبت نشده است.';$('alerts').append(li)}connect();
}catch(error){if(error.message!=='UNAUTHORIZED')notify('دریافت وضعیت ناموفق بود؛ اتصال سرور را بررسی کن.')}finally{refreshing=false}}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{await api('/api/login',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});e.target.password.value='';notify('ورود موفق بود.');await refresh()}catch{notify('ورود ناموفق؛ رمز، آدرس HTTPS و وضعیت سرور را بررسی کن.')}finally{b.disabled=false}});
$('refresh').onclick=()=>refresh();$('logout').onclick=async()=>{try{await api('/api/logout',{method:'POST',body:'{}'})}catch{}showLogin();notify('از پنل خارج شدی. موتور سرور همچنان مستقل است.')};
$('heartbeat').onclick=async()=>{try{await api('/api/heartbeat',{method:'POST',body:'{}'});notify('درخواست پیام در صف قرار گرفت؛ تحویل هنوز تأیید نشده است.')}catch{notify('درخواست پیام انجام نشد؛ تنظیمات تلگرام یا محدودیت نرخ را بررسی کن.')}};
$('signalForm').addEventListener('submit',async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const form=Object.fromEntries(new FormData(e.target));form.rsi=Number(form.rsi);const r=await api('/api/dry-run',{method:'POST',body:JSON.stringify(form)});notify('فقط آزمایش در صف ثبت شد: '+r.id);setTimeout(()=>refresh(),2000)}catch{notify('ثبت آزمایش ناموفق بود؛ ورودی‌ها و ارتباط سرور را بررسی کن.')}finally{b.disabled=false}});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('install').hidden=false});$('install').onclick=async()=>{if(installPrompt){await installPrompt.prompt();installPrompt=null;$('install').hidden=true}};
window.addEventListener('online',()=>refresh());window.addEventListener('offline',()=>{$('connection').textContent='○ گوشی آفلاین است؛ وضعیت سرور مشخص نیست'});
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
void refresh();
