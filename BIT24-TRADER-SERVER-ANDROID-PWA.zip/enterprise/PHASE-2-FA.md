# فاز ۲: ریسک و آداپتور REST

فایل‌ها:
- `src/RiskManager.ts`
- `src/Bit24Adapter.ts`
- `test/phase2.test.ts`

## وضعیت اجرا
ماژول‌ها مستقل و تست‌پذیرند؛ به engine قبلی وصل نشده‌اند و هیچ سفارش واقعی ارسال نشده است. حالت پیش‌فرض DRY_RUN است و حتی بدون credential هیچ fetch انجام نمی‌دهد. خروجی شبیه‌سازی فقط simulationId دارد؛ exchangeOrderId یا fill جعلی تولید نمی‌کند. Dry-Run یک رسید شبیه‌سازی است، نه شبیه‌سازی دفتر سفارش یا اجرای واقعی خرید/OCO.

## ریسک
`validateSignal({rsi})` از PositionCounter تزریق‌شده تعداد پوزیشن‌های فعال را می‌گیرد. پیش‌فرض سقف ۳ است. طبق توافق سخت‌گیرانهٔ قبلی RSI دقیقاً ۷۵ هم رد می‌شود (نه فقط بالای آن)؛ code و message خطا REJECTED_RSI_TOO_HIGH است. وضعیت پوزیشن نامعتبر/نامعلوم fail-closed می‌شود. Counter باید شامل خریدهای pending، unknown، دارایی بدون حفاظت و پوزیشن‌های باز تأییدشده باشد. خواندن شمارنده به‌تنهایی رزرو اتمیک ظرفیت نیست؛ فاز موتور باید count+reservation را با قفل/تراکنش سریال کند تا دو سیگنال همزمان از سقف عبور نکنند. SECURED در schema فاز۱ به معنی بسته‌شدن معامله نیست؛ lifecycle خروج هنوز کامل نشده است.

## Token Bucket
Lua با Redis TIME و یک کلید مشترک حساب، refill و مصرف را اتمیک می‌کند. پیش‌فرض rate=2 توکن در ثانیه و capacity=1 است تا burst دوتایی ایجاد نشود. تقریباً هر ۵۰۰ میلی‌ثانیه یک درخواست مجاز می‌شود؛ ظرفیت قابل تنظیم است. TTL از زمان پرشدن کامل طولانی‌تر است. تمام Workerهای یک API key باید از `Bit24Adapter.bucketKey(apiKey)` استفاده کنند. برای چند API key متعلق به یک حساب، scope واحد حساب لازم است؛ محدودیت صرافی را باید برای حساب/endpoint تأیید کرد.

قطع/پاسخ نامعتبر Redis درخواست را متوقف می‌کند. RateLimitWaitError و RateLimitUnavailableError قبل از ارسال POST رخ می‌دهند و نباید BUY_UNKNOWN بسازند. مهلت انتظار پیش‌فرض صف ۵ ثانیه است؛ Redis client را با connectTimeout، command timeout و offline queue غیرفعال پیکربندی کنید. این کلاس timeout داخلی فرمان Redis ندارد؛ محدودیت انتظار صف بعد از پاسخ Redis بررسی می‌شود. cache برای سفارش نوشتنی ممنوع است؛ کش خواندن در ماژول قبلی جداست.

## آداپتور
Market Buy از مسیر مستند ثابت `POST https://rest.bit24.cash/pro/capi/v2/spot-orders/submit` با side=1، type=1، amount و نمادهای پایه/مظنه استفاده می‌کند. HMAC روی همان form URL-encoded ساخته می‌شود. هیچ endpoint دلخواه، برداشت، redirect یا retry خودکار POST وجود ندارد.

OCO از همان مسیر submit با type=3، side=0 استفاده خواهد کرد؛ جزئیات پارامترهای حدضرر/حدسود حدس زده نشده‌اند. به همین دلیل در LIVE یک `VerifiedOrderContract` با encodeOCO معتبر و decoder تأیید پاسخ لازم است. بدون codec متد قبل از شبکه متوقف می‌شود. encodeOCO در تست‌ها فقط codec آزمایشی است و قرارداد Bit24 نیست. مقدار فروش OCO باید مقدار واقعاً fillشده پس از کسر کارمزد/precision باشد؛ آداپتور به‌تنهایی مالکیت، موجودی، fill، min-notional و tick-size را تأیید نمی‌کند. این تأییدها قبل از فعال‌سازی واقعی الزامی‌اند.

پاسخ HTTP موفق حتی با ID، فقط `ACKNOWLEDGED_NOT_VERIFIED` است؛ نباید آن را مستقیماً به BOUGHT_NO_OCO یا SECURED تبدیل کنید. fill واقعی و فعال‌بودن حفاظت باید از خواندن وضعیت صرافی تأیید شوند. نوع VerifiedOrderContract یک مرز تزریق مورد اعتماد است، نه اثبات اتوماتیک صلاحیت/مجوزهای صرافی. Live عمداً بدون credentials + contract باز نمی‌شود؛ هیچ contract آمادهٔ تأییدنشده‌ای ارائه نشده است.

## طبقه‌بندی خطا و ارتباط با فاز۱
- timeout درخواست Market Buy → `NetworkTimeoutError`, operation=MARKET_BUY → لایه بالاتر باید BUY_UNKNOWN و reconciliation را بررسی کند.
- timeout درخواست OCO → همان کلاس با operation=OCO → خرید قبلاً انجام شده؛ BOUGHT_NO_OCO حفظ می‌شود تا حفاظت تطبیق داده شود. آن را BUY_UNKNOWN نکنید و OCO را کورکورانه تکرار نکنید.
- قطع اتصال پس از ارسال، HTTP خطادار، JSON نامعتبر یا ACK نامطمئن → UnknownSubmissionError → نتیجه نامعلوم و نیازمند تطبیق، نه FAILED قطعی.
- خطای ورودی، صلاحیت LIVE یا محدودکننده پیش از ارسال → سفارش ارسال نشده است؛ با timeout صرافی اشتباه نشود.

try/catch در متدهای عمومی خطای typed را بدون تغییر حفظ می‌کند؛ طبقه‌بندی شبکه در submit مشترک است. timeout از شروع fetch تا خواندن JSON معتبر فعال است. قطع اینترنت نمی‌تواند اجرای سرور صرافی را لغو کند؛ Abort فقط انتظار کلاینت را متوقف می‌کند.

## نمونه Dry-Run
```ts
import { createClient } from 'redis';
import { Bit24Adapter, RedisTokenBucket } from './src/Bit24Adapter.js';
import { RiskManager } from './src/RiskManager.js';
const redis = createClient({url:process.env.REDIS_URL,
  disableOfflineQueue:true,socket:{connectTimeout:5000}});
redis.on('error', () => console.error('REDIS_UNAVAILABLE'));
await redis.connect();
const limiter = new RedisTokenBucket(redis, 'bit24:dryrun:single-account');
const adapter = new Bit24Adapter(limiter); // DRY_RUN
const risk = new RiskManager({countActivePositions: async () => 0}); // مثال تست؛ در سرور از DB بخوانید.
await risk.validateSignal({rsi:60});
const receipt = await adapter.placeMarketBuy({baseCoin:'PEPE',quoteCoin:'USDT',amount:'100'});
await redis.quit();
```
در این نمونه مقدار صفر counter فقط fixture آموزشی است و نباید در موتور واقعی استفاده شود. نمونهٔ LIVE عمداً ارائه نشده تا پیش از تأیید قرارداد، معامله‌ای فعال نشود.

## آزمون
`cd enterprise && npm run typecheck && npm test`
نتیجه: ۱۶ تست جدید، ۵۷ تست موفق در مجموع. تست Lua/Redis در این مرحله با mock است؛ Redis واقعی، چند Worker همزمان و حساب Bit24 تست نشده‌اند. در فاز تأیید زیرساخت باید نرخ واقعی، رقابت چند worker، توقف Redis، timeout بعد از ارسال و جواب دیرهنگام صرافی آزمایش شوند. هیچ تغییری در فاز۳ یا موتور قبلی اعمال نشده است.
