# فاز ۴ — مانیتورینگ و تلگرام

## فایل‌ها و وضعیت
- `src/NotificationService.ts`: Telegraf، BullMQ، Worker مستقل، heartbeat، ارسال هشدار و relay.
- `src/PgNotificationOutbox.ts`: اتصال به صف پایدار RecoveryAlerts فاز۳.
- `sql/phase4/001_notification_outbox.sql`: نشانگر آخرین enqueue و ایندکس relay.
- `test/notifications.test.ts`: تست‌های واحد بدون ارسال واقعی پیام.

کتابخانه‌ها با نسخهٔ lockشده اضافه شده‌اند: Telegraf 4.16.3، BullMQ 5.76.2 و ioredis 5.9.2. نسخهٔ سازگار BullMQ با redis@4 پروژه انتخاب شده است. بررسی npm audit --omit=dev در این مرحله صفر آسیب‌پذیری گزارش کرد؛ این نتیجه جایگزین ممیزی امنیتی نیست.

این سرویس هنوز از main.ts قدیمی auto-start نمی‌شود؛ برای راه‌اندازی از composition جدا استفاده کنید. هیچ توکن واقعی در کد قرار نگرفته، هیچ پیام واقعی ارسال نشده و Redis/Telegram واقعی در این فاز تست نشده‌اند. فاز ۵ اجرا نشده است.

## مسیر پیام و non-blocking بودن
```
موتور ترید → ثبت هشدار در PostgreSQL outbox → relay مستقل → BullMQ/Redis
                                                           ↓
                                                Worker → Telegraf → Telegram
                                                           ↓
                                                 ثبت deliveredAt پس از موفقیت
```
`sendCriticalAlert()` فقط ثبت پایدار DB را await می‌کند؛ منتظر Redis، Telegram یا پایان retry نمی‌ماند. همین نوشتن DB هزینه/زمان دارد و باید query_timeout داشته باشد؛ ادعای «هیچ انتظار در هیچ شرایطی» نمی‌کنیم. relay هر یک ثانیه batch را به صف می‌برد. `sendHeartbeat()` فقط enqueue در Redis را await می‌کند، نه ارسال تلگرام. Producer محدودیت اتصال/فرمان ۵ ثانیه و retry محدود دارد؛ Worker برای اتصال مجدد مستقل نگه داشته شده است. قطع Redis نباید باعث گم‌شدن هشدار commitشده در PostgreSQL شود.

Jobها فقط outboxId دارند؛ توکن، chat ID، پاسخ خام API، اطلاعات ورود و stack خام خطای Telegram وارد payload یا error ذخیره‌شده نمی‌شوند. Telegraf فقط outbound callApi/sendMessage دارد؛ launch/long-polling و دستور عمومی معامله/برداشت ساخته نشده است.

## Retry و اولویت
- critical: priority=1؛ heartbeat: priority=10.
- ۱۲ تلاش، exponential backoff از ۲ ثانیه با سقف تأخیر عادی ۳۰ دقیقه.
- خطای 429 و retry_after تلگرام محترم شمرده می‌شود؛ اگر از backoff عادی بیشتر باشد همان حداقل زمان انتظار استفاده می‌شود.
- یک ارسال همزمان؛ محدودکنندهٔ Worker حداکثر یک job در ۱۱۰۰ میلی‌ثانیه.
- timeout درخواست Telegram حدود ۱۰ ثانیه با AbortController سازگار با Telegraf.
- صف نیازمند Redis پایدار با AOF و maxmemory-policy=noeviction است.

اولویت بالا به معنی preempt کردن پیام درحال ارسال نیست؛ critical ممکن است پشت یک heartbeat فعال (حداکثر حدود ۵ ثانیه دریافت وضعیت + ۱۰ ثانیه Telegram در شرایط timeout) بماند. قطع شبکه/تلگرام اجازهٔ تحویل «فوری تضمینی» نمی‌دهد.

پس از اتمام retry، job failed نگه داشته می‌شود، deliveredAt خالی می‌ماند و کد NOTIFICATION_RETRIES_EXHAUSTED به diagnostic داده می‌شود. اضافه‌کردن مجدد همان jobId شمارندهٔ retry را بی‌صدا صفر نمی‌کند. اپراتور باید بعد از اصلاح علت، failed job را با ابزار مدیریتی BullMQ retry کند؛ مانیتور مستقل برای صف failed لازم است. failedهای نگه‌داشته‌شده در relay به کمک lastEnqueuedAt نوبتی بررسی می‌شوند تا پیام‌های جدید پشت ۱۰۰ failed قدیمی گرسنه نمانند.

ضمانت تحویل at-least-once است، نه exactly-once: اگر Telegram پیام را پذیرفته باشد ولی پاسخ یا ثبت deliveredAt از بین برود، retry می‌تواند پیام تکراری بسازد. deliveredAt فقط پذیرش موفق API تلگرام را نشان می‌دهد، نه خوانده‌شدن توسط کاربر.

## heartbeat
`start()` با upsertJobScheduler یک برنامهٔ پایدار ۱۵دقیقه‌ای در BullMQ می‌سازد؛ setInterval مرورگر یا گوشی نیست. بسته به رفتار scheduler، اولین job جدید می‌تواند بلافاصله اجرا شود. در زمان خاموشی تمام Workerها پیام ارسال نمی‌شود؛ پس از راه‌اندازی، صف/برنامه ادامه پیدا می‌کند، نه اینکه لزوماً برای تک‌تک بازه‌های ازدست‌رفته پیام تولید کند.

محتوا:
- حالت LIVE/DRY_RUN/UNKNOWN؛
- آخرین موجودی تأییدشده و زمان تأیید؛
- تعداد پوزیشن‌های باز؛
- RSS و heap پردازش ارسال‌کننده؛
- RAM استفاده‌شده/کل میزبان از node:os.

`StatusProvider` باید snapshot معتبر از موتور/DB بدهد. موجودی صرافی را این ماژول حدس نمی‌زند؛ نبود snapshot، خطا یا timeout به «نامشخص» تبدیل می‌شود، نه موجودی صفر. وضعیت stale با زمان مشاهده نشان داده می‌شود. در Worker جدا، RAM پردازش به Worker تلگرام مربوط است، نه الزاماً موتور ترید؛ در کانتینر RAM میزبان node:os ممکن است با سقف cgroup متفاوت باشد. برای RAM تمام سرویس‌ها باید متریک مستقل جمع‌آوری شود.

## هشدار قرمز و اتصال به فاز۳
```ts
await notifications.sendCriticalAlert({type:'BOUGHT_NO_OCO',tradeId});
await notifications.sendCriticalAlert({type:'EXCHANGE_API_DOWN'});
await notifications.sendHeartbeat(); // دستی؛ فقط enqueue
```
tradeId باید UUID یک معاملهٔ موجود باشد. شناسهٔ ساختگی در استفادهٔ واقعی ندهید.

فاز۳ هنگام گذار fill نامطمئن/معلق به BOUGHT_NO_OCO، هشدار را اکنون در همان تراکنش fill ثبت می‌کند؛ تغییر فایل PgTradingStore فقط برای این اتصال است. inspectionهای تکراری همان وضعیت آن هشدار گذار را دوباره تولید نمی‌کنند. رویدادهای اضطراری فاز۳ هم از همان outbox ارسال می‌شوند. هشدار ممکن است تا زمان تحویل از نظر تاریخی صحیح باشد ولی وضعیت معامله بعداً SECURED شده باشد؛ متن عمداً «هنوز تأیید نشده» و نیاز بررسی را بیان می‌کند.

EXCHANGE_API_DOWN یک رویداد معنایی است: مسئول سلامت API باید پس از تأیید قطع کامل آن را فراخوانی کند؛ یک timeout تنها یا خطای دیتابیس را خودکار «قطع کامل صرافی» نام‌گذاری نکرده‌ایم. تشخیص فعال outage/ریکاوری به این ماژول تحمیل نشده و باید در composition موتور متصل شود. caller نباید به هر خطای شبکه نامرتبط این نوع بدهد. لاگ‌های تشخیصی فقط کدهای ثابت دارند.

dedup هشدارهای تحویل‌نشده همان trade/code در DB فعال است؛ پس از تحویل، یک رویداد مستقل جدید قابل ثبت است. برای رویدادهای پرتکرار، سازندهٔ رویداد باید تشخیص تغییر حالت یا cooldown داشته باشد تا هر دور loop هشدار جدید نسازد.

## نمونهٔ composition
پس از اعمال migrationهای فاز۱، فاز۳ و فاز۴:
```ts
import {Pool} from 'pg';
import {NotificationService} from './src/NotificationService.js';
import {PgNotificationOutbox} from './src/PgNotificationOutbox.js';
import {PgTradingStore} from './src/PgTradingStore.js';

const pool=new Pool({connectionString:process.env.DATABASE_URL,
  connectionTimeoutMillis:5000,query_timeout:5000,max:10});
pool.on('error',()=>console.error('NOTIFICATION_DB_UNAVAILABLE'));
const trades=new PgTradingStore(pool);
const notifications=new NotificationService({
  redisUrl:process.env.REDIS_URL!,
  botToken:process.env.TELEGRAM_BOT_TOKEN!,
  chatId:process.env.TELEGRAM_CHAT_ID!,
  outbox:new PgNotificationOutbox(pool),
  status:{getSnapshot:async()=>({
    mode:'UNKNOWN',
    balances:null, // تا اتصال snapshot موجودی معتبر؛ هرگز صفر یا موجودی تستی نگذارید.
    openPositions:await trades.countActivePositions(),
    observedAt:null, // این نمونه ادعای snapshot مالی کامل ندارد.
  })},
  onDiagnostic:code=>console.error(code),
});
await notifications.start();
// در composition نهایی، balances/observedAt و mode را از snapshot معتبر موتور تأمین کنید.
// هنگام SIGTERM: await notifications.close(); سپس await pool.end().
```
این قطعه فقط الگوی اتصال است، نه فایل main جدید. همان bot/chat/database را روی تمام Workerهای این queue نگه دارید؛ چند حساب/tenant مختلف نیاز به queue name و outbox جدا دارند. سرویس را پس از close دوباره روی همان نمونه start نکنید. کلیدها فقط از env سمت سرور/secret manager بیایند و هرگز به Android یا مرورگر نروند. credentials واقعی برای نصب/تست درخواست نشده‌اند.

## محدودیت شکست کامل
وقتی پردازش crash یا سرور کاملاً خاموش باشد، خود همان پردازش نمی‌تواند heartbeat/هشدار مرگش را ارسال کند. watchdog مستقل بیرون VPS باید فقدان heartbeat و صف failed را مانیتور کند. restart policy و queue جای آن را نمی‌گیرند. قطع همزمان PostgreSQL و Redis نیز نیازمند هشدار خارجی است؛ سرویس نه پیام را تحویل‌شده فرض می‌کند و نه خطا را به خطای ترید تبدیل می‌کند.

## تست
`cd enterprise && npm run typecheck && npm test`
۱۹ تست جدید؛ مجموع ۱۰۰ تست موفق. پوشش: formatter، RAM/موجودی نامشخص، enqueue اولویت‌دار، شکست Redis، retry و 429، عدم ثبت deliveredAt قبل از موفقیت، replay، خطای DB بعد از ارسال، sanitize خطا، تنظیمات Redis، و ثبت هشدار همراه fill در تراکنش. این‌ها unit/mock هستند؛ تحویل واقعی Telegram، reconnect Redis و scheduler در چند پردازش هنوز integration-test نشده‌اند.
