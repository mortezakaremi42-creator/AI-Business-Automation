# فاز ۱ — دیتابیس و ماشین حالت

## دامنه
فقط مدل داده، قوانین گذار و ذخیرهٔ تراکنشی. هیچ API صرافی، سفارش واقعی، موتور جدید یا فاز بعدی اجرا نشده است. این کد هنوز به engine قدیمی وصل نشده است. Dry-Run فعلاً یعنی هیچ درخواست معامله‌ای از این ماژول صادر نمی‌شود؛ شبیه‌ساز fill در فاز بعد تعریف خواهد شد.

## ساختار
- `sql/phase1/001_order_state_machine.sql`: Schema بومی PostgreSQL (بدون وابستگی به ORM)، جدول‌های `trading_v2."Trades"` و `trading_v2."SystemLogs"`، Enum با نام `OrderStates`.
- `src/orders/types.ts`: مدل‌های TypeScript؛ قیمت و مقدار رشتهٔ ده‌دهی‌اند، نه number اعشاری جاوااسکریپت.
- `src/orders/OrderStateMachine.ts`: ماشین حالت immutable و مستقل از دیتابیس؛ اعتبارسنجی گراف و نوع شاهد.
- `src/orders/OrderStateRepository.ts`: تغییر وضعیت با compare-and-swap روی status/version و ثبت audit در همان تراکنش.
- `src/orders/SystemLogRepository.ts`: ثبت تشخیص خطا/پاسخ API با metadata محدود، بدون ذخیرهٔ secrets یا بدنهٔ خام پاسخ.
- `test/order-state-machine.test.ts`: تمام ۲۵ جفت گذار، شواهد، rollback و تعارض نسخه.

## گراف
```
PENDING_BUY ──timeout/uncertainty──> BUY_UNKNOWN
     │                                  │
     ├──confirmed fill──────────┐       ├──confirmed fill──┐
     │                          ▼       │                 ▼
     │                      BOUGHT_NO_OCO ──confirmed OCO──> SECURED
     │                                  
     └──confirmed no execution──> FAILED
BUY_UNKNOWN ──reconciliation proves no execution──> FAILED
```
`SECURED` و `FAILED` در این فاز نهایی‌اند. SECURED یعنی مرحلهٔ تأمین حفاظت کامل شده، نه اینکه معامله بسته شده است. خروج از معامله و شکست/لغو حفاظت در مدل فعلی پوشش داده نشده‌اند و نیازمند طراحی جدا هستند.

از `BOUGHT_NO_OCO` به `FAILED` نمی‌رویم: دارایی خریده‌شده با خطای OCO ناپدید نمی‌شود. این وضعیت بحرانی باقی می‌ماند. همچنین BUY_UNKNOWN دوباره به PENDING_BUY برنمی‌گردد تا خرید کورکورانه تکرار نشود. عدم مشاهده در یک پاسخ API به‌تنهایی اثبات عدم اجرا نیست.

شاهد fill و OCO باید از آداپتور مطمئن بیاید. ماشین حالت فقط نوع/وجود شناسه را چک می‌کند و اصالت آن را نمی‌تواند اثبات کند. trigger دیتابیس گراف را enforce می‌کند، اما صحت شواهد به لایهٔ مورد اعتماد برنامه وابسته است؛ دسترسی مستقیم نوشتن را به نقش سرویس محدود کنید.

## مدل داده
`Trades`: id UUID، symbol، side به شکل BUY/SELL، entryPrice، amount، status، version، createdAt و updatedAt. UUID توسط `crypto.randomUUID()` ساخته می‌شود. نوع عددی `numeric(38,18)` است؛ مقدار قیمت/حجم باید مثبت باشد. precision نهایی مطابق بازار باید در آداپتور کنترل شود. قبل از fill، entryPrice قیمت برنامه‌ریزی‌شده و amount حجم درخواستی است؛ هنگام تأیید fill باید با ارقام واقعی جایگزین شوند. API فعلی repository فقط وضعیت را تغییر می‌دهد؛ ذخیرهٔ fill و شناسه‌های صرافی در فاز اتصال تکمیل می‌شود. Enum سمت معامله SELL را می‌پذیرد، ولی گراف این فاز مخصوص workflow خرید و حفاظت است؛ آن را برای سفارش مستقل SELL استفاده نکنید.

`SystemLogs`: id، tradeId اختیاری، level، event، message، context JSONB، createdAt. لاگ‌های API فقط operation/outcome/status/duration را ذخیره می‌کنند؛ عمداً raw API response، Authorization، امضا، آدرس حاوی query و توکن ذخیره نمی‌شود. اگر در فاز بعد دادهٔ تشخیصی بیشتری لازم شد، فقط فیلدهای بی‌خطر با allowlist اضافه شوند. سیاست retention و redaction مستقل برای لاگ تولید لازم است.

## کاربرد
```ts
import { OrderStateMachine } from './src/orders/OrderStateMachine.js';
const pending = new OrderStateMachine();
const unknown = pending.transition('BUY_UNKNOWN', { kind: 'SUBMISSION_UNCERTAIN' });
const bought = unknown.transition('BOUGHT_NO_OCO', {
  kind: 'BUY_FILL_CONFIRMED', exchangeOrderId: 'confirmed-buy-id',
});
const secured = bought.transition('SECURED', {
  kind: 'OCO_CONFIRMED', exchangeProtectionId: 'confirmed-oco-id',
});
// pending.transition('SECURED', ...) => InvalidOrderTransition
```
این شناسه‌ها فقط نمونهٔ آموزشی‌اند، نه سفارش موجود. برای ثبت وضعیت از Repository استفاده کنید، نه تغییر شیء در حافظه. در StateConflict ابتدا وضعیت را دوباره بخوانید و تطبیق دهید؛ هیچ درخواست خریدی را صرفاً به‌دلیل conflict تکرار نکنید.

## اعمال migration و آزمون
روی دیتابیس آزمایشی و پس از backup:
```sh
cd enterprise
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/phase1/001_order_state_machine.sql
npm run typecheck
npm test
```
این migration یک‌بار اجرا می‌شود و auto-run نیست. به‌عمد در زیرپوشهٔ phase1 است تا Compose قدیمی آن را تصادفی اعمال نکند. جدول‌های public قبلی دست‌نخورده‌اند. trigger گذار نامعتبر و تغییر هویت را رد می‌کند و updatedAt را به‌روز می‌کند. CAS از overwrite همزمان جلوگیری می‌کند؛ جایگزین idempotency key در صرافی یا recovery واقعی نیست.

نتیجهٔ فعلی: typecheck موفق، ۳۲ تست جدید و ۹ تست موجود موفق (۴۱ مجموع). تست repository با mock است؛ migration و trigger در PostgreSQL واقعی هنوز اجرا/تست نشده‌اند.
