# فاز ۳ — بازیابی و حلقهٔ ترید

## دامنه و وضعیت واقعی
`Reconciler.ts` و `TradingEngine.ts` پیاده‌سازی شدند. برای ذخیرهٔ پایدار، `TradingContracts.ts`، `PgTradingStore.ts` و migration زیرپوشهٔ `sql/phase3` اضافه شدند. آداپتور فاز۲ فقط با Market Sell و یک مرز تأییدشدهٔ خواندن وضعیت تکمیل شده است. endpoint تازه یا WebSocket فرضی وجود ندارد.

این موتور جایگزین خودکار main.ts قبلی نشده است؛ worker قدیمی و این موتور را همزمان اجرا نکنید. پیکربندی پیش‌فرض Bit24Adapter هنوز Dry-Run است. هیچ حساب صرافی، دیتابیس/Redis واقعی، فروش واقعی یا اجرای ۲۴ساعته در این مرحله آزمایش نشده است. codec واقعی تفسیر پاسخ/تطبیق Bit24 همچنان نیازمند تأیید است. محض ساخته‌شدن کلاس‌ها، سیستم آمادهٔ پول واقعی نیست.

## Reconciler
`reconcileOnStartup()` ابتدا مالکیت worker را بررسی می‌کند و سفارش‌های BUY_UNKNOWN و BOUGHT_NO_OCO را از دیتابیس می‌خواند؛ PENDING_BUYهای زنده هم برای پوشش crash پیش از دریافت/ثبت پاسخ خوانده می‌شوند. رکورد Dry-Run و خروج اضطراری کاملاً تأییدشده وارد بازیابی زنده نمی‌شوند.

نتیجهٔ inspection از آداپتور مورد اعتماد باید یکی از این موارد باشد:
- UNKNOWN: خرید جدید ممنوع؛ نه خرید/فروش دوباره و نه فرض شکست.
- NO_EXECUTION_CONFIRMED: فقط تأیید قطعی عدم اجرا (نه نبودن در یک صفحهٔ API) می‌تواند خرید معلق/نامعلوم را FAILED کند. برای دارایی قبلاً خریده‌شده چنین نتیجه‌ای تناقض است.
- PROTECTED: خرید واقعی و پوشش فعال کل مقدار توسط OCO تأیید شده؛ پس از ثبت fill واقعی، SECURED می‌شود، بدون فروش اضطراری.
- UNPROTECTED: خرید terminal، مقدار خالص متعلق به همان معامله و قابل‌فروش، نبود OCO فعال یا درحال ثبت و نبود خروج دیگر تأیید شده باشد. `safeToSell=true` باید حاصل بررسی واقعی باشد، نه مقدار پیش‌فرض.
- EXIT_CONFIRMED: خروج اضطراری متعلق به همین معامله کاملاً fill شده و باقی‌مانده/سفارش خطرناک وجود ندارد. ACK فروش این معنی را ندارد.

برای وضعیت بی‌حفاظ، اول یک رکورد تک‌بارمصرف EmergencyExits و هشدار بحرانی در یک تراکنش ثبت می‌شود؛ سپس Market Sell با مقدار خالص/قابل‌فروش ارسال می‌شود. تأیید HTTP فروش باعث بازشدن قفل خریدهای جدید نمی‌شود؛ inspection بعدی باید خروج کامل را تأیید کند. خطای فروش، timeout یا crash، ژورنال را برای تطبیق نگه می‌دارد و فروش خودکار تکرار نمی‌شود. حتی crash بین ثبت قصد و ارسال HTTP با محافظه‌کاری نیازمند تطبیق است.

نبودن OCO در یک پاسخ لحظه‌ای، به‌ویژه بعد از timeout ثبت OCO، مجوز فروش نیست. resolver باید تمام صفحـات مرتبط، سفارش‌های درحال اجرا/لغو، partial fill، fee، precision، مالکیت دارایی و تأخیر مشاهدهٔ صرافی را بررسی کند. در حالت نامطمئن UNKNOWN برگرداند. OCO رزروشده یا فروش نامعلوم باید پیش از هر اقدام تازه حل شود؛ این طرح عمداً سرمایه را با «فروش دوبارهٔ حدسی» به خطر نمی‌اندازد. در partial sell، تا خروج کامل تأیید نشده باشد سیستم متوقف می‌ماند و بازمانده را خودکار دوباره نمی‌فروشد.

## حلقهٔ موتور
`run(abortSignal)`:
1. قفل session اختصاصی PostgreSQL را برای کل عمر اجرا می‌گیرد؛ همان شناسهٔ قفل worker قدیمی استفاده شده است.
2. قبل از دریافت سیگنال، reconciliation اجرا می‌شود؛ باقیماندهٔ نامعلوم تمام خریدهای جدید را می‌بندد.
3. سیگنال از SignalSource تزریق‌شده گرفته می‌شود؛ UUID پایدار، تازگی، اعشار مثبت، stop<entry<take و RiskManager بررسی می‌شوند.
4. رزرو در DB با transaction advisory lock، کنترل سقف ۳، کنترل نماد فعال و جلوگیری از تکرار UUID انجام می‌شود.
5. Dry-Run فقط رسید شبیه‌سازی خرید/OCO می‌گیرد و تکمیل simulation را ثبت می‌کند؛ fill و سود یا وضعیت SECURED جعلی تولید نمی‌کند.
6. LIVE فقط وقتی codec خواندن/حفاظت و credentials پیکربندی شده‌اند پیش می‌رود. این gate تأیید واقعی مجوزهای حساب یا کیفیت زیرساخت نیست.
7. پیش از POST خرید، وضعیت BUY_UNKNOWN روی دیسک ثبت می‌شود. حتی crash پس از ارسال و پیش از ذخیرهٔ ACK باعث خرید دوباره نمی‌شود.
8. ACK خرید ذخیره می‌شود؛ سپس fill واقعی/terminal بررسی می‌شود. در مسیر عادی، قصد OCO قبل از درخواست ثبت و OCO با مقدار خالص fill ارسال می‌شود. SECURED تنها پس از inspection حفاظت فعال ثبت می‌شود.
9. شکست OCO/خرید به حلقه برمی‌گردد؛ در دور بازیابی، فروش اضطراری فقط با شواهد معتبر نبود حفاظت انجام می‌شود.
10. خطاها به توقف امن و backoff حدود ۲،۴،۸،۱۶،۳۰ ثانیه منجر می‌شوند. تکرار حلقه به معنی تکرار POST نیست؛ مسیر بعدی از ژورنال و reconciliation آغاز می‌شود.

حلقه ترتیبی است، setInterval همپوشان ندارد، دوباره run همزمان روی همان نمونه را رد می‌کند و از AbortSignal برای پایان استفاده می‌کند. SignalSource باید timeout و abort را رعایت کند. عملیات HTTP درحال اجرا با timeout آداپتور پایان می‌یابند؛ توقف برنامه، انجام سفارش در صرافی را لغو نمی‌کند. از دست‌رفتن اتصال مالکیت، ارسال جدید را متوقف می‌کند؛ بدون پشتیبانی idempotency صرافی، ادعای exactly-once سراسری نداریم.

## ژورنال و schema
ابتدا migration فاز۱ و سپس `sql/phase3/001_recovery_journal.sql` اعمال شود. این migration ستون‌های stopLoss/takeProfit، شناسه‌های buy/OCO، زمان تلاش OCO و پرچم simulation را اضافه می‌کند.

- EmergencyExits: یک ردیف برای هر معامله، وضعیت SUBMITTING/UNKNOWN/CONFIRMED، مقدار و شناسهٔ خروج.
- RecoveryAlerts: صف پایدار هشدار با dedup پیام تحویل‌نشده. تحویل تلگرام این صف هنوز به dispatcher متصل نشده است؛ «ثبت هشدار» به معنی «دریافت پیام تلگرام» نیست. اتصال notification در فاز بعد تکمیل می‌شود.
- trigger فاز۱ گراف وضعیت را حفظ می‌کند اما اجازهٔ تغییر metadata با افزایش version را می‌دهد.

Enum فاز۱ عمداً تغییر نکرده است؛ معاملهٔ نقدشدهٔ اضطراری در ستون status همچنان BOUGHT_NO_OCO می‌ماند ولی EmergencyExits.CONFIRMED نمایانگر پایان این خروج است و آن رکورد از پوزیشن فعال/بازیابی حذف می‌شود. گزارش‌ها باید این ژورنال را join کنند؛ خواندن status به‌تنهایی برای تشخیص باز/بسته کافی نیست. چرخهٔ کامل خروج عادی و حسابداری PnL در این فاز پیاده نشده است. SECURED همچنان پوزیشن باز شمرده می‌شود.

## اتصال نمونه (نه اجرای خودکار)
```ts
import { Pool } from 'pg';
import { PgTradingStore } from './src/PgTradingStore.js';
import { RiskManager } from './src/RiskManager.js';
import { Reconciler } from './src/Reconciler.js';
import { TradingEngine, type SignalSource } from './src/TradingEngine.js';
// adapter همان Bit24Adapter فاز۲ است، پیش‌فرض DRY_RUN.
// source باید سرویس سیگنال داخلی باشد، نه ورودی عمومی مرورگر.
const pool = new Pool({ connectionString: process.env.DATABASE_URL,
  max: 10, connectionTimeoutMillis: 5000, query_timeout: 10000 });
const store = new PgTradingStore(pool);
const recovery = new Reconciler(store, adapter);
const engine = new TradingEngine(store, adapter, new RiskManager(store, 3), source, recovery);
const stop = new AbortController();
process.once('SIGTERM', () => stop.abort());
process.once('SIGINT', () => stop.abort());
try { await engine.run(stop.signal); } finally { await pool.end(); }
```
این قطعه الگوی wiring است؛ `adapter` و `source` باید از dependency composition واقعی تأمین شوند. فایل main قدیمی را با آن همزمان اجرا نکنید. هیچ سیگنال تصادفی یا کلید واقعی در کد اضافه نشده است. دادهٔ مالی تطبیق باید تازه باشد؛ cache قدیمی برای تصمیم فروش اضطراری معتبر نیست. خواندن وضعیت صرافی در آداپتور از مسیر مستند GET /pro/capi/v2/spot-orders با محدودکنندهٔ مشترک استفاده می‌کند؛ pagination و تفسیر واقعی به قرارداد مورد اعتماد واگذار شده‌اند. نتیجهٔ خالی به‌صورت خودکار به NO_EXECUTION تبدیل نمی‌شود.

## آزمون‌ها و محدودیت‌ها
`cd enterprise && npm run typecheck && npm test`
۲۴ تست جدید فاز۳، مجموع ۸۱ تست موفق. شامل: شروع با سفارش نامعلوم، OCO موجود، فروش با حجم خالص، timeout فروش و عدم تکرار، crash بین intent و ارسال، ACK بدون fill، OCO timeout و کشف حفاظت، عدم فروش نامرتبط، ظرفیت/RSI، Dry-Run، backoff و توقف.

تست‌ها unit و درون‌حافظه‌ای هستند؛ migration/قفل‌های PostgreSQL، قطع واقعی اتصال، چند پردازش و semantics Bit24 هنوز integration-test نشده‌اند. قبل از LIVE نیاز به تست sandbox/حساب محدود، صحت Trade-only و Withdraw-disabled، fault-injection، تأیید qty/fee/min-notional، polling تطبیق تمام صفحه‌ها و watchdog خارج سرور است. Market Sell زیان، اسلیپیج یا اجرای موفق را تضمین نمی‌کند؛ ممکن است نقدینگی/حداقل سفارش مانع خروج شود. هیچ وعدهٔ «نجات قطعی سرمایه» داده نمی‌شود.
