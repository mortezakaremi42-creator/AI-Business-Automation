# Bit24 Trader Control — integrated deployment (Dry-Run only)

Start with [DEPLOYMENT-FA.md](DEPLOYMENT-FA.md) for VPS, Docker, PM2, HTTPS, external monitoring and Android PWA installation.

- `npm run setup`: generate private local `.env` (never overwrite existing secrets).
- `npm run typecheck && npm run build && npm test`
- `npm run migrate`: explicitly apply versioned schema to a fresh database.
- `npm start`: compiled integrated runtime (`dist/runtime.js`), not the legacy worker.

**Live trading is deliberately disabled.** The mobile dashboard is a PWA, not a native APK or Next.js implementation. It supports login, server status, manual dry-run signal tests and Telegram heartbeat requests. There is no connected automatic live market signal feed or fabricated balance/PnL.

All phase notes describe their implementation at that point in time; the deployment guide supersedes their earlier entrypoint/configuration examples.
