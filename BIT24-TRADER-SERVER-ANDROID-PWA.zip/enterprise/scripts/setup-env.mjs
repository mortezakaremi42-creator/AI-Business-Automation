import {randomBytes,scryptSync} from 'node:crypto';
import {writeFileSync,existsSync} from 'node:fs';
import {createInterface} from 'node:readline/promises';
if(existsSync('.env')){console.error('.env already exists; refusing to rotate secrets or overwrite it');process.exit(1)}
const rl=createInterface({input:process.stdin,output:process.stdout});
let origin;
try {origin=new URL(await rl.question('Public HTTPS origin (e.g. https://bot.your-domain.tld): '));}
finally {rl.close()}
if(origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error('Use HTTPS origin only');
const password=randomBytes(18).toString('base64url'),salt=randomBytes(16).toString('hex');
const pg=randomBytes(24).toString('hex'),redis=randomBytes(24).toString('hex');
const file=`NODE_ENV=production\nPORT=3100\nPUBLIC_ORIGIN=${origin.origin}\nTRADING_MODE=DRY_RUN\nADMIN_USERNAME=admin\nADMIN_PASSWORD_HASH=${salt}:${scryptSync(password,salt,64).toString('hex')}\nJWT_SECRET=${randomBytes(48).toString('hex')}\nPOSTGRES_PASSWORD=${pg}\nREDIS_PASSWORD=${redis}\nDATABASE_URL=postgres://trader:${pg}@127.0.0.1:5432/trader\nREDIS_URL=redis://:${redis}@127.0.0.1:6379/0\nTELEGRAM_BOT_TOKEN=\nTELEGRAM_CHAT_ID=\n`;
writeFileSync('.env',file,{flag:'wx',mode:0o600});
console.log('\n.env created with permissions 0600. Username: admin');
console.log('One-time generated dashboard password (save in your password manager): '+password);
console.log('Do not send this password or .env in chat. Compose overrides DB/Redis hostnames internally.');
