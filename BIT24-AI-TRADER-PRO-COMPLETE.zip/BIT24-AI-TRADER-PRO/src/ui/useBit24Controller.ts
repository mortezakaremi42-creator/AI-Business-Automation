import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import type {AppStatusSnapshot,CapitalRiskConfig,ExitStrategyConfig,ProVerificationReport} from '../shared/contracts.js';
import {BackendClient,BackendError,normalizeBackendBase} from './backendClient.js';
function savedBase(){try{return normalizeBackendBase(localStorage.getItem('bit24.backend')??window.BIT24_API_BASE??'')}catch{return ''}}
function savedToken(){try{return sessionStorage.getItem('bit24.dashboardToken')??''}catch{return ''}}
// Remote controller only: no market simulator, browser vault or browser trading engine.
export function useBit24Controller(){
  const [config,setConfig]=useState(()=>({baseUrl:savedBase(),token:savedToken()}));
  const client=useMemo(()=>new BackendClient(config),[config]);
  const [snapshot,setSnapshot]=useState<AppStatusSnapshot|null>(null);
  const [backendConnected,setConnected]=useState(false);
  const [busyAction,setBusy]=useState<string|null>(null);
  const [toastMessage,setToast]=useState<string|null>(null);
  const [connectionError,setConnectionError]=useState('در حال اتصال به بک‌اند…');
  const busy=useRef(false),generation=useRef(0);
  const blockKey='bit24.pendingWrite.'+client.baseUrl;
  const [uncertainWrite,setUncertain]=useState(()=>{try{return localStorage.getItem(blockKey)}catch{return null}});
  const toastTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const showToast=useCallback((message:string)=>{setToast(message);if(toastTimer.current)clearTimeout(toastTimer.current);toastTimer.current=setTimeout(()=>setToast(null),6000)},[]);
  const accept=useCallback((data:AppStatusSnapshot)=>setSnapshot(prev=>!prev||data.serverTimestamp>=prev.serverTimestamp?data:prev),[]);
  useEffect(()=>()=>{if(toastTimer.current)clearTimeout(toastTimer.current)},[]);
  useEffect(()=>{
    let cancelled=false,failures=0;let timer:ReturnType<typeof setTimeout>;const abort=new AbortController();
    generation.current++;setSnapshot(null);setConnected(false);
    try{setUncertain(localStorage.getItem(blockKey))}catch{setUncertain(null)}
    async function poll(){
      try{const data=await client.sync(abort.signal);if(cancelled)return;accept(data);setConnected(true);setConnectionError('');failures=0;}
      catch(error){if(cancelled)return;setConnected(false);setConnectionError(error instanceof Error?error.message:'خطای اتصال');failures++;}
      if(!cancelled)timer=setTimeout(poll,failures?Math.min(30_000,2000*2**Math.min(failures-1,4)):2000);
    }
    void poll();return()=>{cancelled=true;abort.abort();clearTimeout(timer)};
  },[client,accept,blockKey]);
  const saveBackendConnection=(baseUrl:string,token:string)=>{
    try{const base=normalizeBackendBase(baseUrl);localStorage.setItem('bit24.backend',base);sessionStorage.setItem('bit24.dashboardToken',token.trim());setConfig({baseUrl:base,token:token.trim()});showToast('آدرس ذخیره شد؛ در حال اتصال. توکن فقط برای این نشست نگه‌داری می‌شود.');}
    catch(error){showToast(error instanceof Error?error.message:'ذخیره تنظیمات انجام نشد.');}
  };
  const call=useCallback(async(action:string,path:string,body:Record<string,unknown>={},financial=false):Promise<any>=>{
    if(busy.current)return {ok:false};
    if(!backendConnected){showToast('سرور در دسترس نیست؛ هیچ معاملهٔ محلی جایگزین نشد.');return {ok:false};}
    if(financial&&uncertainWrite){showToast('نتیجه درخواست قبلی نامعلوم است. قبل از خرید/فروش جدید، آن را در سرور تطبیق دهید.');return {ok:false};}
    busy.current=true;setBusy(action);const version=generation.current;
    if(financial){setUncertain(action);try{localStorage.setItem(blockKey,action)}catch{}}
    try{
      const data=await client.request(path,body);
      if(version!==generation.current)return data;
      if(data?.snapshot)accept(data.snapshot);
      if(financial){setUncertain(null);try{localStorage.removeItem(blockKey)}catch{}}
      if(data?.messageFa)showToast(data.messageFa);
      try{accept(await client.sync())}catch{setConnected(false);setConnectionError('همگام‌سازی پس از عملیات ناموفق بود؛ نتیجه را در سرور بررسی کنید.');}
      return data;
    }catch(error){
      if(version!==generation.current)return {ok:false};
      if(error instanceof BackendError&&error.payload?.snapshot)accept(error.payload.snapshot);
      if(financial&&error instanceof BackendError&&!error.unknownWrite){setUncertain(null);try{localStorage.removeItem(blockKey)}catch{}}
      showToast((error instanceof Error?error.message:'خطای درخواست')+(financial&&(!(error instanceof BackendError)||error.unknownWrite)?' نتیجه سفارش نامعلوم است؛ درخواست تکرار نشد.':''));
      return {ok:false};
    }finally{busy.current=false;setBusy(null)}
  },[client,backendConnected,uncertainWrite,accept,showToast,blockKey]);
  return {
    snapshot,backendConnected,busyAction,toastMessage,connectionError,backendBase:config.baseUrl,saveBackendConnection,uncertainWrite,
    startScanner:()=>call('startScanner','/api/scanner/start'),stopScanner:()=>call('stopScanner','/api/scanner/stop'),
    startDemoTrading:()=>call('startDemo','/api/trading/start-demo'),stopTrading:()=>call('stopTrading','/api/trading/stop'),
    emergencyStop:()=>call('emergencyStop','/api/trading/emergency-stop'),clearEmergencyStop:()=>call('clearEmergency','/api/trading/clear-emergency'),
    manualDemoBuy:(symbol:string)=>call('buy-'+symbol,'/api/buy',{symbol},true),
    manualDemoSell:(symbol:string)=>call('sell-'+symbol,'/api/sell',{symbol},true),
    toggleGoldAutoDemo:(enabled:boolean)=>call('goldAuto','/api/gold/toggle-auto',{enabled}),
    manualGoldDemoBuy:(symbol:'PAXG/IRT'|'XAUT/IRT')=>call('goldBuy-'+symbol,'/api/gold/demo-buy',{symbol},true),
    updateRiskSettings:(params:{capital?:Partial<CapitalRiskConfig>;exit?:Partial<ExitStrategyConfig>})=>call('riskUpdate','/api/risk/update',params),
    saveBit24Credentials:(apiKey:string,secretKey:string)=>call('saveBit24','/api/settings/bit24',{apiKey,secretKey}),
    verifyBit24Connection:()=>call('verifyBit24','/api/settings/bit24/verify'),clearBit24Credentials:()=>call('clearBit24','/api/settings/bit24/clear'),
    saveTelegramSettings:(params:{botToken?:string;chatId?:string;enabled:boolean})=>call('saveTelegram','/api/settings/telegram',params),
    sendDailyTelegramReport:()=>call('tgDaily','/api/settings/telegram/daily-report'),
    runPro100Test:async():Promise<ProVerificationReport|undefined>=>{const data=await call('pro100','/api/verification/run-100');return data?.report},
    downloadTradesCsv:async()=>{
      try{const response=await fetch(client.url('/api/reports/trades.csv'),{headers:config.token?{'X-API-Token':config.token}:{},signal:AbortSignal.timeout(10000),redirect:'error'});if(!response.ok)throw Error('دریافت گزارش ناموفق بود.');const url=URL.createObjectURL(await response.blob());const a=document.createElement('a');a.href=url;a.download='bit24-history.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}catch{showToast('گزارش از سرور دریافت نشد.')}
    },
  };
}
