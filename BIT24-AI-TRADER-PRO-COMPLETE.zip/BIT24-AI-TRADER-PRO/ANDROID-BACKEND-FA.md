# اتصال پنل Bit24 به Node و ساخت APK اندروید

## وضعیت واقعی این تحویل

- رابط موجود پروژه React/Vite است؛ همان رابط اصلاح شده، نه یک HTML مستقلِ موازی.
- موتور معاملاتی، موجودی و قیمت در مرورگر ساخته نمی‌شوند. پنل از `/api/coins` و `/api/status` همگام می‌شود؛ خرید و فروش به سرور می‌روند.
- **اتصال واقعی به Node به معنی معاملات واقعی صرافی نیست.** این بسته خرید/فروش DEMO دارد و `/api/trading/activate-live` همیشه 403 می‌دهد. بدون فید تأییدشده، دادهٔ بازار سرور شبیه‌سازی‌شده است؛ برچسب فید را بررسی کنید.
- پروژهٔ Android تولید و `cap sync android` اجرا شده است. **خود APK در محیط تحویل ساخته نشده**؛ JDK/Android SDK موجود نیست. تست روی گوشی و Gradle build هنوز انجام نشده‌اند.
- Node داخل APK اجرا نمی‌شود. کامپیوتر/سرور باید جداگانه روشن بماند؛ بستن اپ، سرور را متوقف نمی‌کند. اجرای یک‌ماهه در پس‌زمینهٔ گوشی تضمین نشده است.
- وضعیت DEMO این سرور در حافظه است؛ راه‌اندازی دوباره، حساب آزمایشی را از نو می‌سازد. این بسته جایگزین پایگاه داده و تطبیق سفارش‌های واقعی نیست.

## ۱. پیش‌نیازهای رایانه

1. Node.js 22 LTS با نسخهٔ حداقل 22.12 و npm نصب کنید.
2. Android Studio نصب کنید؛ از **More Actions → SDK Manager** یا **Tools → SDK Manager**:
   - SDK Platforms: **Android 15 / API 35**.
   - SDK Tools: **Android SDK Build-Tools 35**، **Android SDK Platform-Tools** و **Android SDK Command-line Tools**.
3. JDK **21** نصب/انتخاب کنید. در Android Studio:
   **Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK → JDK 21**.
   JBR همراه Studio را فقط اگر نسخهٔ 21 است انتخاب کنید. برای خط فرمان `JAVA_HOME` باید همان JDK باشد.
4. دانلود وابستگی‌های Gradle به دسترسی رایانه به Google Maven، Maven Central و سرویس توزیع Gradle نیاز دارد.

بررسی در ترمینال:

```sh
node --version
npm --version
java -version
```

## ۲. نصب وابستگی‌های همین پروژه

در پوشهٔ پروژه:

```sh
cd AI-Business-Automation
npm ci
npm run typecheck
npm test
npm run build
```

Capacitor 7 در `package.json` و lockfile با نسخهٔ دقیق ثبت شده است؛ `npm ci` هر سه بسته را نصب می‌کند. فرمان معادل نصب اولیه، **فقط برای اطلاع**:

```sh
npm install --save-exact @capacitor/core@7.6.10 @capacitor/android@7.6.10
npm install --save-dev --save-exact @capacitor/cli@7.6.10
```

## ۳. ساخت تنظیمات خصوصی سرور

فرمان زیر اگر `.env` وجود نداشته باشد آن را از نمونه ایجاد می‌کند و توکن پنل و عبارت رمزنگاری تصادفی می‌نویسد؛ فایل موجود را تغییر نمی‌دهد:

```sh
node -e "const fs=require('fs'),c=require('crypto');if(!fs.existsSync('.env'))fs.writeFileSync('.env',fs.readFileSync('.env.example','utf8').replace('DASHBOARD_API_TOKEN=','DASHBOARD_API_TOKEN='+c.randomBytes(32).toString('hex')).replace('BIT24_VAULT_PASSPHRASE=change-this-to-a-strong-random-32char-secret','BIT24_VAULT_PASSPHRASE='+c.randomBytes(32).toString('hex')),{flag:'wx'});console.log('Open .env locally; never share its secrets.');"
```

اگر قبلاً `.env` دارید، مقدار قوی `DASHBOARD_API_TOKEN` را دستی تنظیم کنید. متغیر واقعی رمز گاوصندوق `BIT24_VAULT_PASSPHRASE` و کلید محرمانهٔ صرافی `BIT24_SECRET_KEY` است. عبارت گاوصندوق موجود را بدون برنامهٔ مهاجرت عوض نکنید.

برای این آزمایش فیلدهای Bit24 و تلگرام را خالی بگذارید. **توکن پنل با API Key یا Secret صرافی فرق دارد.** توکن را در گفت‌وگو، Git، URL، یا فایل عمومی `backend-config.js` نگذارید.

## ۴. IP شبکه و CORS

کامپیوتر و گوشی به Wi-Fi یکسان متصل باشند. برای IP کامپیوتر:

```powershell
# Windows PowerShell
ipconfig
```

```sh
# Linux
ip -4 addr
# macOS، برای رابط Wi-Fi معمول
ipconfig getifaddr en0
```

مثال: اگر IPv4 کامپیوتر `192.168.1.20` باشد، آدرس API در گوشی این است:

```text
http://192.168.1.20:3000
```

در `.env` برای APK و مرورگر کامپیوتر، مبدأهای پیش‌فرض کافی‌اند. اگر داشبورد را در مرورگر گوشی هم باز می‌کنید، مبدأ LAN را اضافه کنید:

```dotenv
PORT=3000
CORS_ALLOWED_ORIGINS=http://localhost,https://localhost,capacitor://localhost,http://localhost:3000,http://127.0.0.1:3000,http://192.168.1.20:3000
```

IP نمونه را جایگزین IP واقعی کنید؛ پس از ویرایش `.env` سرور را دوباره اجرا کنید.

CORS در `src/server/mobileAccess.ts` قبل از مسیرهای API نصب شده است:

```ts
const access = createMobileAccess(options);
app.use('/api', access.middleware);
app.use(express.json({ limit: '256kb' }));
```

این پیاده‌سازی به‌جای `app.use(cors())` باز، فقط مبدأهای مجاز و هدر `X-API-Token` را می‌پذیرد؛ OPTIONS بدون توکن پاسخ می‌گیرد، اما درخواست واقعی توکن لازم دارد. **CORS احراز هویت یا فایروال نیست**؛ توکن روی همهٔ APIها و گزارش‌ها اعمال می‌شود و WebSocket نیز محافظت شده است. بدون توکن تنظیم‌شده فقط درخواست loopback مجاز است، نه گوشی روی LAN.

فایروال سیستم‌عامل: ورودی TCP پورت **3000 فقط در شبکهٔ خصوصی/LAN** مجاز باشد. روی روتر Port Forward عمومی باز نکنید. Guest Wi-Fi / AP Isolation ممکن است ارتباط دستگاه‌ها را قطع کند. VPN گوشی گاهی مسیر LAN را می‌بندد؛ برای آزمایش آن را خاموش کنید یا دسترسی LAN را مجاز کنید.

## ۵. اجرای Node

پس از build، در ترمینال اول:

```sh
npm start
```

یا برای توسعه:

```sh
npm run dev
```

این دو فرمان را هم‌زمان روی یک پورت اجرا نکنید. سرور روی `0.0.0.0:3000` گوش می‌دهد؛ برای آدرس گوشی از IP واقعی کامپیوتر استفاده کنید، نه `0.0.0.0` و نه `localhost`.

آزمون مستقل API در ترمینال دوم، بدون نوشتن توکن در فرمان:

```sh
node --env-file=.env -e "fetch('http://127.0.0.1:3000/api/status',{headers:{'X-API-Token':process.env.DASHBOARD_API_TOKEN}}).then(async r=>console.log(r.status,await r.json()))"
```

داشبورد رایانه: `http://localhost:3000`. بعد از راه‌اندازی توکن‌دار، وارد کردن همان توکن در فرم پنل لازم است.

## ۶. آدرس قابل تنظیم در برنامه

در صفحهٔ اتصال اپ:

1. آدرس `http://192.168.1.20:3000` را **بدون `/api`** وارد کنید.
2. مقدار `DASHBOARD_API_TOKEN` را از `.env` محلی در فیلد «توکن دسترسی پنل» وارد کنید.
3. «ذخیره و اتصال مجدد» را بزنید.

آدرس در localStorage می‌ماند؛ توکن فقط sessionStorage است و ممکن است بعد از بسته‌شدن اپ دوباره لازم شود. این ذخیره‌سازی، گاوصندوق سخت‌افزاری نیست.

پیش‌فرض اختیاری هنگام بسته‌بندی در `public/backend-config.js`:

```js
window.BIT24_API_BASE = 'http://192.168.1.20:3000';
```

مقدار ذخیره‌شده در فرم بر این پیش‌فرض اولویت دارد. پس از تغییر فایل عمومی build و sync لازم است. تغییر از داخل فرم نیازی به ساخت دوبارهٔ APK ندارد. در نسخهٔ مرورگر مقدار خالی یعنی API هم‌مبدأ با صفحه؛ در APK آدرس سرور را وارد کنید.

**HTTP فقط آزمایش DEMO در LAN مورد اعتماد است**؛ توکن آن هم روی شبکه رمز نشده است. کلید واقعی صرافی یا تلگرام را از پنل HTTP ارسال نکنید. برای اینترنت عمومی از API دارای HTTPS معتبر استفاده کنید؛ صفحهٔ HTTPS مرورگر معمولاً API HTTP را به‌عنوان mixed content مسدود می‌کند.

## ۷. پیکربندی Capacitor و تولید پروژه

فایل واحد `capacitor.config.json`:

```json
{
  "appId": "com.bit24.trader",
  "appName": "BIT24 AI TRADER PRO",
  "webDir": "dist/client",
  "server": { "androidScheme": "http", "cleartext": false }
}
```

`dist/client` خروجی واقعی Vite است. `server.url` عمداً وجود ندارد: رابط همراه APK بسته‌بندی می‌شود، نه اینکه سایت از راه دور جایگزین اپ شود.

پوشهٔ `android` در این تحویل موجود است. فرمان اولیهٔ زیر **فقط در صورتی که این پوشه وجود نداشته باشد** اجرا می‌شود:

```sh
npm run build:client
npx cap add android
```

برای پروژهٔ موجود، به‌ترتیب:

```sh
npm run build:client
npx cap sync android
npx cap open android
```

HTTP شبکه فقط در `android/app/src/debug/AndroidManifest.xml` با `usesCleartextTraffic=true` مجاز شده است؛ manifest اصلی آن را false می‌گذارد. Release باید HTTPS باشد؛ فایل debug را به main کپی نکنید. مجوز INTERNET موجود است. بکاپ برنامه در manifest غیرفعال است.

## ۸. دکمه‌های Android Studio برای APK

1. پروژهٔ `android` را باز کنید و منتظر **Gradle Sync** بمانید.
2. اگر نصب SDK، پذیرش License یا نصب وابستگی پیشنهاد شد، انجام دهید.
3. **Build → Select Build Variant**؛ برای ماژول `app` مقدار **debug** را انتخاب کنید.
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   در برخی نسخه‌ها نام این گزینه **Build → Generate App Bundles or APKs → Generate APKs** است.
5. پس از **BUILD SUCCESSFUL**، در اعلان **locate** را بزنید.

خروجی دقیق نسبت به ریشهٔ پروژه:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

این خروجی را با زدن Run جایگزین نکنید؛ APK مسیر بالا برای نصب دستی مناسب است و با کلید debug امضا می‌شود.

### ساخت از ترمینال، جایگزین دکمه‌ها

Linux/macOS/Git Bash با JDK 21 و Android SDK تنظیم‌شده:

```sh
npm run android:apk
```

Windows PowerShell:

```powershell
npm run build:client
npx cap sync android
cd android
.\gradlew.bat assembleDebug
cd ..
```

اگر `SDK location not found` دیدید، پروژه را در Studio باز کنید تا `android/local.properties` با مسیر SDK رایانه ساخته شود؛ یا `ANDROID_HOME` را تنظیم کنید. فایل local.properties را به Git نفرستید. اگر `invalid source release: 21` دیدید، Gradle JDK/JAVA_HOME هنوز روی Java قدیمی است.

## ۹. نصب روی گوشی

- `app-debug.apk` را با USB یا روش انتقال فایل مورد اعتماد روی گوشی کپی کنید.
- فایل را باز کنید و فقط برای همان فایل‌منیجر **Install unknown apps / Allow from this source** را اجازه دهید.
- نصب کنید؛ بعد اجازهٔ نصب ناشناس آن منبع را دوباره خاموش کنید.
- اگر نسخهٔ قبلی همین appId با امضای دیگری نصب باشد، نصبِ جایگزین خطای signature می‌دهد. تنها بعد از پشتیبان‌گیری، نسخهٔ قبلی را حذف و دوباره نصب کنید؛ حذف برنامه داده‌های محلی آن را پاک می‌کند.

گزینهٔ USB debugging با رضایت کاربر و Platform-Tools:

```sh
adb devices
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

روی گوشی درخواست اعتماد به رایانه را تأیید کنید. USB debugging برای نصب فایل از فایل‌منیجر لازم نیست.

## ۱۰. آزمون خرید و فروش و قطع شبکه

1. پس از اتصال، اسکنر و حالت Demo را از پنل فعال کنید.
2. خرید Demo یک نماد واجد شرایط را بزنید؛ ممکن است ریسک‌گیت با دلیل مشخص آن را رد کند، که خطای اتصال نیست.
3. در جدول پوزیشن‌های کریپتو «بستن Demo» را بزنید؛ فروش باقی‌ماندهٔ همان نماد سمت سرور اجرا می‌شود. فروش بدون پوزیشن رد می‌شود.
4. Wi-Fi/سرور را قطع کنید: وضعیت اتصال باید قرمز شود و هیچ موتور معاملاتی محلی جایگزین نشود. اطلاعات قبلی، اگر دیده شوند، آخرین snapshot هستند، نه قیمت تازه.
5. درخواست‌های خواندن با فاصلهٔ عادی ۲ ثانیه پس از پایان پاسخ و عقب‌نشینی تا ۳۰ ثانیه اجرا می‌شوند؛ timeout ده ثانیه است. درخواست معاملاتی خودکار تکرار نمی‌شود.

اگر پاسخ خرید/فروش پس از ارسال گم شود، نتیجه **UNKNOWN** است. قفل احتیاطی localStorage جلوی خرید/فروش دستی بعدی همین پنل/آدرس را می‌گیرد و با بازکردن صفحه خودکار رفع نمی‌شود. وضعیت سرور را بررسی کنید؛ برای بررسی می‌توانید اسکنر/معاملهٔ خودکار را متوقف کنید. این قفل، توقف سراسری موتور، idempotency پایگاه داده یا تطبیق صرافی نیست. تغییر IP، پاک‌کردن داده‌ها یا استفاده از دستگاه دیگر اثبات عدم اجرای سفارش نیست. مسیر آزادسازی خودکار قفل پس از تطبیق در این تحویل وجود ندارد؛ برای پول واقعی از این بسته استفاده نکنید.

## فایل‌ها و قرارداد API

- `src/ui/backendClient.ts`: fetch، timeout، بررسی JSON، توکن، عدم retry خرید/فروش.
- `src/ui/useBit24Controller.ts`: فقط اتصال سرور، بدون ساخت موتور در مرورگر.
- `src/server/mobileAccess.ts`: CORS و احراز هویت HTTP/WS.
- `src/server/index.ts`: `GET /api/coins`، `GET /api/status`، `POST /api/buy` و `POST /api/sell`.
- خرید/فروش: بدنهٔ JSON مثل `{"symbol":"BTC/IRT"}`؛ هدرهای `Content-Type: application/json` و `X-API-Token`.
- status علاوه بر قرارداد کامل رابط، balance، pnl، wins، losses، winRate، openCount، positions و logs دارد؛ ارقام حساب آزمایشی هستند. coins از همان فرصت‌های سرور نگاشت می‌شود.
- `tests/mobile-backend.test.ts`: آزمون دسترسی، CORS، sync، خرید/فروش HTTP، رد LIVE و پاسخ نامعلوم.

### نتایج بررسی در محیط تحویل

`npm ci`، `npm run typecheck`، `npm test` (۲۱ آزمون ریشه)، `npm run build` و `npx cap sync android` موفق شدند. `npm audit` برای وابستگی‌های ریشه صفر آسیب‌پذیری گزارش کرد. پروژه‌های مستقل `enterprise` و `orbit-trader` در این شمارش نیستند؛ تست‌رانر ریشه فقط `tests/` را اجرا می‌کند. Gradle/SDK، نصب روی گوشی و اتصال واقعی Bit24 در این بررسی اجرا نشده‌اند.
